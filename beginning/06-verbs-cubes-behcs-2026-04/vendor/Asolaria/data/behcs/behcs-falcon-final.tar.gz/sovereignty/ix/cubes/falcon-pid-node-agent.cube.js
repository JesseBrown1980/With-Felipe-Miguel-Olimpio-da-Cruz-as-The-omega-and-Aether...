// cube: falcon-pid-node-agent | IX-866 | D16 PID (53) | touches 1,5,13,15,20,44
// gates: hookwall | waves: single | federation: falcon-live-runtime
export const CUBE = {
  id: 'falcon-pid-node-agent',
  primaryCatalog: { D: 16, name: 'PID', prime: 53 },
  touches: [1, 5, 13, 15, 20, 44],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'agent-falcon':          'owner',
    'agent-falcon-state':    'state-sink',
    'falcon-agent-health':   'endpoint-cube',
    'ix-exec-runtime':       'runtime-peer',
    'behcs-heartbeat-lx489': 'sibling-pid'
  },
  payload: {
    kind: 'live-pid', source: '~/asolaria/bin/falcon-agent.js', pid_observed: 5025,
    cmdline: 'node /data/data/com.termux/files/home/asolaria/bin/falcon-agent.js',
    listens_on: 'http://127.0.0.1:4799', surface: 'falcon-gw',
    owner_uid: 'u0_a466 (u0_a466)', compute_class: 'orbital-mobile-node'
  },
  translate: {
    human:  'Falcon Agent Node.js process — Termux API HTTP bridge on port 4799.',
    agent:  '(falcon, lifecycle.process, local.falcon-agent-js, 0, runtime, hookwall, running, [], pulse, FA, log, persistent, falcon-gw, free)',
    device: 'pid=5025 exec=node argv=~/asolaria/bin/falcon-agent.js'
  }
};
