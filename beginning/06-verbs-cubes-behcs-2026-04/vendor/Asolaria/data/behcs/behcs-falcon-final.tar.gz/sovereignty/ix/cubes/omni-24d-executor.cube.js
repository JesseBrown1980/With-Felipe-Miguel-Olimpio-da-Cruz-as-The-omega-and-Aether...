// cube: omni-24d-executor | hilbert: (computed at launch)
// IX-712 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D22 TRANSLATION (prime 79, cube 493039)
// touches: D1 ACTOR, D2 VERB, D3 TARGET, D8 CHAIN
// gates: hookwall → gnn → shannon | waves: omni_6x6x6x12 | federation: gaia

export const CUBE = {
  id: 'omni-24d-executor',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [1, 2, 3, 8],
  gates: ['hookwall', 'gnn', 'shannon'],
  waves: ['omni_6x6x6x12'],
  connectors: {
    'omni-dispatch':      'sibling-14d',
    'crltMerge':          'grammar-merger',
    'omnilanguageHooks':  'hook-library',
    'verb-table':         'verb-source'
  },
  payload: {
    kind: 'dispatch-executor',
    source: '~/beast-deploy/omni-24d-executor.js',
    role: 'real 24D language executor: every dimension, every node, every wave',
    dimensions: 24,
    dim_names: ['actor','verb','target','risk','layer','gate','state','chain','wave','dialect','proof','scope','surface','energy','device','pid','profile','ai_model','location','time','hardware','translation','federation','intent'],
    primes: [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89],
    crlt_log: '~/beast-deploy/state/crlt-24d.ndjson'
  },
  translate: {
    human:  'Omni 24D executor — full 24-dimension Hilbert prime-cube dispatcher with CRLT federation.',
    agent:  '(gaia, translate.24d, lan.colony, 4, civilization, hookwall+gnn+shannon, executing, [proves,feeds], omni_6x6x6x12, IX, hash, operational, falcon-gw, heavy)',
    device: 'node ~/beast-deploy/omni-24d-executor.js <verb> [target]'
  }
};
