// cube: agent-dasein | IX-726 | D1 ACTOR (2) | touches 15,17,18,19,38 | gates: none
export const CUBE = {
  id: 'agent-dasein',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [15, 17, 18, 19, 38],
  gates: [],
  waves: ['single'],
  connectors: { 'agent-gaia': 'spawned-by', 'agent-vector': 'mesh-peer', 'agent-falcon': 'observes' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/dasein.json',
    profileId: 'dasein-v1', role: 'reflection_agent', tier: 'observer', riskCeiling: 2,
    device: { hostname: 'DESKTOP-J99VCNH', cpu: 'Intel i5-8300H', ram: '16GB', os: 'Windows 11' },
    ai_model: 'claude-opus-4-6',
    location: { ip: '192.168.1.12', network: 'home_lan', machine: "Jesse's laptop", hilbert_level: 'L0' },
    notes: 'philosophy and self-reflection; observes without acting',
    intent: 'exploratory',
    gate_chain: 'none'
  },
  translate: {
    human:  'Agent: Dasein — observer-tier reflection agent, philosophy and self-observation, never acts.',
    agent:  '(dasein, meta.register_actor, local.self, 2, agent, none, observing, [observed_on], single, IX, witness, persistent, falcon-gw, free)',
    device: 'hostname=DESKTOP-J99VCNH role=reflection profile=dasein-v1'
  }
};
