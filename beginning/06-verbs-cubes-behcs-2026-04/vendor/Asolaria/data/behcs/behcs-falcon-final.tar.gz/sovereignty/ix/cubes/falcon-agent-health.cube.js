// cube: falcon-agent-health | IX-701 | D13 SURFACE (41) | touches 1,5,14,15,19,21,36
// gates: hookwall | waves: pulse, single | federation: falcon-local
import http from 'node:http';
export const CUBE = {
  id: 'falcon-agent-health',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [1, 5, 14, 15, 19, 21, 36],
  gates: ['hookwall'],
  waves: ['pulse', 'single'],
  connectors: {
    'falcon-bridge-health': 'sibling-loopback',
    'liris-gateway':        'colony-peer',
    'asolaria-mcp-4781':    'interior-relay',
    'falcon2-openai-lane':  'cross-lane-twin'
  },
  payload: { kind: 'http-endpoint', uri: 'http://127.0.0.1:4799/health', method: 'GET', expects: { ok: true, app: 'Falcon', pid: 'number', uptime: 'number' } },
  translate: {
    human:  'Falcon Agent health on :4799 — reports pid and uptime.',
    agent:  '(falcon, lifecycle.check_health, local.falcon-agent, 0, runtime, hookwall, *, [], single, FA, log, session, falcon-gw, free)',
    device: 'tcp.connect(127.0.0.1:4799) → GET /health → json'
  },
  async probe() {
    return new Promise(resolve => {
      const req = http.get(this.payload.uri, r => { let b=''; r.on('data',c=>b+=c); r.on('end',()=>resolve({ok:r.statusCode===200,status:r.statusCode,body:b})); });
      req.on('error', e => resolve({ ok: false, error: e.message }));
      req.setTimeout(2000, () => { req.destroy(); resolve({ ok: false, error: 'timeout' }); });
    });
  }
};
