// cube: ix-verb-firmware-write | IX-737 | D2 VERB (prime 3) | touches 4,6,11,15,21,40,41,43
// gates: hookwall+gnn+shannon+sovereignty (risk 8) | waves: single
export const CUBE = {
  id: 'ix-verb-firmware-write',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [4, 6, 11, 15, 21, 40, 41, 43],
  gates: ['hookwall', 'gnn', 'shannon', 'sovereignty'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':       'parent-runtime',
    'ix-noun-firmware':      'common-subject',
    'ix-verb-firmware-read': 'prerequisite-verb',
    'ix-verb-me-neutralize': 'sibling-verb',
    'ix-verb-shannon':       'gate-peer'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/firmware-write.js',
    role: 'write .rom to SPI via CH341A with verify; REFUSES without pre-existing backup',
    risk: 8,
    linux_only: true,
    owner_only: true,
    requires_backup: true,
    backup_dir_env: 'FIRMWARE_BACKUP_DIR',
    tool: 'flashrom -p ch341a_spi -w ; -v',
    proof_mode: 'chain'
  },
  translate: {
    human:  'IX verb: firmware.write — flash .rom via CH341A, backup-gated, owner-only.',
    agent:  '(jesse, firmware.write, local.hardware, 8, chip, hookwall+gnn+shannon+sovereignty, gated, [supersedes,proves], single, IX, chain, permanent, usb-sovereignty, heavy)',
    device: 'flashrom -p ch341a_spi -w ${rom} ; flashrom -v ${rom}'
  }
};
