// cube: desktop-display-connector | IX-829 | D15 DEVICE (47) | touches 15,19,21,37
// gates: hookwall | waves: pulse | federation: asolaria-mirror-bridge
// archaeology: ~/liris-test/Asolaria/src/connectors/desktopDisplayConnector.js (2.6 KB, Feb 16)
export const CUBE = {
  id: 'desktop-display-connector',
  primaryCatalog: { D: 15, name: 'DEVICE', prime: 47 },
  touches: [15, 19, 21, 37],
  gates: ['hookwall'],
  waves: ['pulse'],
  connectors: {
    'desktop-capture-connector': 'capture-consumer',
    'desktop-control-connector': 'coords-provider',
    'behcs-mirror-bridge':       'bridge-parent',
    'agent-gaia':                'laptop-host'
  },
  payload: {
    kind: 'js-coordinator-archaeology',
    source: '~/liris-test/Asolaria/src/connectors/desktopDisplayConnector.js',
    runtime_host: 'laptop-node',
    role: 'Enumerate connected displays (bounds, primary flag, device name)',
    output_schema: { displays: [{ name: 'string', bounds: 'rect', primary: 'bool' }] }
  },
  translate: {
    human:  'Desktop display connector — enumerates laptop monitors with bounds and primary flag.',
    agent:  '(asolaria, device.enumerate, laptop.displays, 1, runtime, hookwall, *, [gaia], pulse, IX-829, log, session, asolaria-gw, free)',
    device: 'powershell.exe [System.Windows.Forms.Screen]::AllScreens → json'
  }
};
