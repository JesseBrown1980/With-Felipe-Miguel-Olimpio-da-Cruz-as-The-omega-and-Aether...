// cube: ix-gate-sovereign | IX-750 | D6 GATE (prime 13) | touches 4,7,11,41
// gates: sovereign | waves: single | federation: falcon-local
export const CUBE = {
  id: 'ix-gate-sovereign',
  primaryCatalog: { D: 6, name: 'GATE', prime: 13 },
  touches: [4, 7, 11, 41],
  gates: ['sovereign'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime': 'parent-runtime',
    'agent-falcon':    'sovereign-source',
    'agent-gaia':      'consent-authority'
  },
  payload: {
    kind: 'gate',
    source: '~/sovereignty/ix/gates/sovereign.js',
    role: 'sovereignty consent checker — currently stub (always allow)',
    source_tag: 'falcon',
    stub: true,
    emits_state: ['gated'],
    proof_mode: 'log',
    future_role: 'Jesse/Asolaria explicit consent required for sovereign-critical verbs'
  },
  translate: {
    human:  'IX gate: sovereign — consent check (stub, always allow).',
    agent:  '(falcon, gate.sovereign_consent, local.ix, 0, runtime, sovereign, gated, [], single, SV, log, session, falcon-gw, free)',
    device: 'require("./gates/sovereign.js")() → {ok:true,source:"falcon"}'
  }
};
