// cube: desktop-control-connector | IX-827 | D13 SURFACE (41) | touches 2,13,15,19,21
// gates: hookwall+gnn | waves: single | federation: asolaria-mirror-bridge
// archaeology: ~/liris-test/Asolaria/src/connectors/desktopControlConnector.js (9.5 KB, Feb 16)
// THE KEY — types into specific Windows windows via PowerShell.
export const CUBE = {
  id: 'desktop-control-connector',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [2, 13, 15, 19, 21],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'invoke-desktop-input-ps1': 'spawn-target',
    'desktop-input-host-ps1':   'sidecar-target',
    'desktop-capture-connector':'visual-feedback',
    'ix-verb-laptop-type':      'caller-verb',
    'behcs-mirror-bridge':      'bridge-parent',
    'agent-gaia':               'laptop-host'
  },
  payload: {
    kind: 'js-coordinator-archaeology',
    source: '~/liris-test/Asolaria/src/connectors/desktopControlConnector.js',
    runtime_host: 'laptop-node (spawns PowerShell)',
    role: 'Window-specific typer + mouse + window-manager for Jesse\'s laptop',
    actions: ['move','click','double_click','scroll','type','key','window_list','window_active','window_focus','window_minimize','window_maximize','window_restore','window_close'],
    default_timeout_ms: 9000,
    default_window_title: 'Asolaria Terminal',
    risk: 7
  },
  translate: {
    human:  'Desktop control connector — the window-targeted typer. Actions dispatched to PowerShell helper.',
    agent:  '(asolaria, surface.inject, laptop.window, 7, runtime, hookwall+gnn, executing, [gaia], single, IX-827, log, session, asolaria-gw, light)',
    device: 'powershell.exe Invoke-DesktopInput.ps1 -Action <a> -WindowTitle <w> [-Text <t>] [-Key <k>]'
  }
};
