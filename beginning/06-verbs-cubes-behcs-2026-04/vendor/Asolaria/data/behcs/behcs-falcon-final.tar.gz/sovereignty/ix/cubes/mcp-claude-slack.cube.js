// cube: mcp-claude-slack | IX-778 | D22 TRANSLATION (79) | touches 3,10,18,27
// gates: hookwall+gnn | waves: single | federation: falcon-local
export const CUBE = {
  id: 'mcp-claude-slack',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [3, 10, 18, 27],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'mcp-claude-linear':    'sibling-mcp',
    'mcp-claude-gmail':     'sibling-mcp',
    'ix-verb-mcp-slack':    'call-site',
    'ix-gate-hookwall-v2':  'pre-gate',
    'config-claude-settings': 'configured-by'
  },
  payload: {
    source: '~/.claude/settings.json permissions.allow',
    kind: 'cloud-mcp', provider: 'claude.ai', tool_prefix: 'mcp__claude_ai_Slack__',
    capabilities: ['send_message', 'search_public', 'read_channel', 'read_thread', 'create_canvas', 'schedule_message'],
    target_workspace: 'asolaria (C0APKFR4PSA)',
    cipher: 'tls', risk: 3, ai_model: 'claude-opus-4-6'
  },
  translate: {
    human:  'Slack MCP via claude.ai — post/read #asolaria and search public.',
    agent:  '(falcon, mcp.slack_send, cloud.claude_ai, 3, cloud, hookwall+gnn, executing, [sibling-mcp], single, IX, log, session, falcon-gw, medium)',
    device: 'mcp__claude_ai_Slack__slack_send_message(channel, text)'
  }
};
