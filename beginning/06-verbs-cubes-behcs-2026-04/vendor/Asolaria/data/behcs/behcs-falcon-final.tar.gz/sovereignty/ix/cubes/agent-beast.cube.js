// cube: agent-beast | IX-727 | D1 ACTOR (2) | touches 15,17,18,19,21 | gates: hookwall
export const CUBE = {
  id: 'agent-beast',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [15, 17, 18, 19, 21],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: { 'agent-gaia': 'spawned-by', 'agent-falcon': 'mesh-peer', 'agent-felipe-a06': 'mesh-peer' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/beast.json',
    profileId: 'orbital-gpu-v1', role: 'orbital_gpu_sentinel', tier: 'operator', riskCeiling: 5,
    device: { model: 'SM-S908E', name: 'Samsung S22 Ultra', serial: 'RQCT302BXMA', cpu: 'Snapdragon 8 Gen 1', gpu: 'Adreno 730', cores: 8, ram: '8-12GB', os: 'Android', firmware: 'S908EXXU6CWF8', screen: 'broken', tts: true },
    ai_model: 'local-inference',
    location: { ip: '192.168.1.4', network: 'home_wifi', hilbert_level: 'L2' },
    surface: { home: 'beast-orbital', ports: [8080, 34176, 44642], status: 'pending-auth' },
    notes: 'S22 Ultra orbital GPU sentinel; broken screen; TTS sentinel',
    gate_chain: 'hookwall'
  },
  translate: {
    human:  'Agent: Beast — operator-tier orbital GPU sentinel on broken-screen S22 Ultra, Adreno 730, TTS.',
    agent:  '(beast, meta.register_actor, local.self, 5, agent, hookwall, pending-auth, [runs_on,feeds], pulse, IX, log, operational, beast-orbital, heavy)',
    device: 'model=SM-S908E serial=RQCT302BXMA gpu=Adreno730 ip=192.168.1.4'
  }
};
