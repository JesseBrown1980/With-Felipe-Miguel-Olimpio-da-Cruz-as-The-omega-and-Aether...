// cube: doctrine-liris | IX-816 | D35 MEMORY (149) | touches 1,5,10,17,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-liris',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 5, 10, 17, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'agent-liris': 'documents',
    'doctrine-gaia': 'sibling-doctrine',
    'doctrine-full-agent-roster': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_liris.md',
    description: "Liris super-admin on Rayssa's computer — sub-colony lead, works for Jesse + Gaia."
  },
  translate: {
    human:  "Doctrine: Liris — Rayssa sub-colony lead, reports to Jesse and Gaia.",
    agent:  '(falcon, meta.recall, doctrine.liris, 1, colony, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_liris.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_liris.md', 'utf8') → utf8 markdown"
  }
};
