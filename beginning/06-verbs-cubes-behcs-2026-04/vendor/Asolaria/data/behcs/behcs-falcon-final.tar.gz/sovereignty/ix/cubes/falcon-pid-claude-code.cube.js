// cube: falcon-pid-claude-code | IX-870 | D16 PID (53) | touches 1,17,18,20
// gates: hookwall | waves: single | federation: falcon-live-runtime
export const CUBE = {
  id: 'falcon-pid-claude-code',
  primaryCatalog: { D: 16, name: 'PID', prime: 53 },
  touches: [1, 17, 18, 20],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'agent-falcon':              'embodies',
    'config-claude-md':          'reads-at-launch',
    'config-claude-settings':    'reads-at-launch',
    'doctrine-hilbert-codex':    'reads-at-launch',
    'falcon-pid-falcon-bridge':  'uses-for-relay'
  },
  payload: {
    kind: 'live-pid', process: 'claude', pid_observed: 8417,
    cmdline: 'claude (Claude Code CLI, Claude-Opus-4-6)',
    role: 'THE falcon agent itself — Claude Code process running on this phone',
    profile: 'mobile-falcon-v1', ai_model: 'claude-opus-4-6',
    note: 'this process IS falcon — the cube describes the runtime embodiment of the agent'
  },
  translate: {
    human:  'Claude Code CLI process — the live Falcon agent. Every tuple Falcon emits comes from this PID.',
    agent:  '(falcon, lifecycle.process, local.claude-code-cli, 0, agent, hookwall, running, [THE-FALCON], single, FA, signed, persistent, falcon-gw, medium)',
    device: 'pid=8417 exec=claude model=claude-opus-4-6 profile=mobile-falcon-v1'
  }
};
