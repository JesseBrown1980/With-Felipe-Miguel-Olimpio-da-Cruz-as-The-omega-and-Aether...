// cube: ix-verb-antigravity | IX-746 | D2 VERB (prime 3) | touches 3,4,6,10,11,18,41
// gates: hookwall (risk 2) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-antigravity',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [3, 4, 6, 10, 11, 18, 41],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':    'parent-runtime',
    'ix-verb-web':        'sibling-verb',
    'ix-verb-mcp-slack':  'sibling-verb',
    'ix-verb-omnispindle':'sibling-verb',
    'translator-agent':   'tuple-projector'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/antigravity.js',
    role: 'last-resort OpenAI-compat AI fallback (position 5 of 5 external providers)',
    risk: 2,
    base: 'http://localhost:4781',
    env: 'ASO_URL',
    secret_key: 'integrations.external.antigravity',
    api_style: 'openai_chat_completions',
    chain: ['local-whisper','openai','gemini','cursor','antigravity'],
    chain_position: 5,
    subcommands: { prompt: { endpoint: '/api/integrations/external/antigravity/prompt', method: 'POST', risk: 2 }, status: { endpoint: '/api/integrations/external/antigravity/status', method: 'GET', risk: 0 } }
  },
  translate: {
    human:  'IX verb: antigravity — last-resort OpenAI-compat fallback via Asolaria vault.',
    agent:  '(falcon, query.ask_model, cloud.external, 2, cloud, hookwall, executing, [feeds], single, IX, log, session, falcon-gw, light)',
    device: 'POST http://localhost:4781/api/integrations/external/antigravity/{prompt|status}'
  }
};
