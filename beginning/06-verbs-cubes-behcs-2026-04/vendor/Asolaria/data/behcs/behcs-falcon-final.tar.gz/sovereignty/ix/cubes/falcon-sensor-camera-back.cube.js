// cube: falcon-sensor-camera-back | IX-763 | D36 SENSOR (151)
// touches: D15 DEVICE, D21 HARDWARE, D25 MODALITY, D37 ENVIRONMENT
// gates: hookwall | waves: single, pulse | federation: falcon-local
// author: convergence-helm-05 | spec: IX-760 sensor-surface
export const CUBE = {
  id: 'falcon-sensor-camera-back',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [15, 21, 25, 37],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'falcon-sensor-camera-front': 'sibling-sensor',
    'falcon-sensor-camera-ultra': 'sibling-sensor',
    'falcon-sensor-camera-selfie': 'sibling-sensor',
    'agent-falcon': 'owned-by',
    'agent-falcon-state': 'reads-flow-into'
  },
  payload: {
    kind: 'camera-sensor',
    camera_id: '0',
    facing: 'back',
    max_resolution: { width: 4080, height: 3060 },
    focal_length_mm: 5.4,
    role: 'primary-back',
    modality: 'optical-image',
    termux_command: 'termux-camera-info -c 0',
    capture_command: 'termux-camera-photo -c 0 <file>'
  },
  translate: {
    human:  'Sensor: Falcon back camera (id 0) — 4080x3060 max, 5.4mm lens.',
    agent:  '(falcon, sense.observe, local.camera-0, 1, sensor, hookwall, idle, [reads], single, FA, log, session, falcon-gw, light)',
    device: 'camera2.open(0) → ImageReader(4080x3060,JPEG), focal=5.4mm'
  }
};
