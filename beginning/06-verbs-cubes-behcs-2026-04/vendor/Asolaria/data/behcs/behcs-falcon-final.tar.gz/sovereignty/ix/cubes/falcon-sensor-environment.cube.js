// cube: falcon-sensor-environment | IX-770 | D36 SENSOR (151)
// touches: D15 DEVICE, D21 HARDWARE, D25 MODALITY, D37 ENVIRONMENT
// gates: hookwall | waves: single, pulse | federation: falcon-local
// author: convergence-helm-05 | spec: IX-760 sensor-surface
export const CUBE = {
  id: 'falcon-sensor-environment',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [15, 21, 25, 37],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'falcon-sensor-accelerometer': 'sibling-sensor',
    'falcon-sensor-magnetometer': 'sibling-sensor',
    'falcon-sensor-gyroscope': 'sibling-sensor',
    'agent-falcon': 'owned-by',
    'agent-falcon-state': 'reads-flow-into'
  },
  payload: {
    kind: 'environment-sensor',
    hardware: ['TCS3701', 'BMP580'],
    role: 'ambient light (lux) + barometric pressure (hPa)',
    modality: 'environment-ambient',
    units: { light: 'lux', pressure: 'hPa' },
    termux_command: 'termux-sensor -s "TCS3701 Light,BMP580 Barometer" -n 1',
    sample_fields: ['light_lux', 'pressure_hpa']
  },
  translate: {
    human:  'Sensor: Falcon environment — TCS3701 ambient light + BMP580 barometer.',
    agent:  '(falcon, sense.observe, local.environment, 1, sensor, hookwall, idle, [reads], single, FA, log, session, falcon-gw, light)',
    device: 'i2c.read(TCS3701,0x39)→lux; i2c.read(BMP580,0x47)→hPa'
  }
};
