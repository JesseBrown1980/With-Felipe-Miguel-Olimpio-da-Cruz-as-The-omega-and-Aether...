// cube: ix-verb-mcp-linear | IX-741 | D2 VERB (prime 3) | touches 3,4,6,10,11,41
// gates: hookwall (risk 2) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-mcp-linear',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [3, 4, 6, 10, 11, 41],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':   'parent-runtime',
    'ix-verb-mcp-slack': 'sibling-verb',
    'ix-verb-web':       'sibling-verb',
    'ix-verb-swarmdesk': 'sibling-verb',
    'translator-agent':  'tuple-projector'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/mcp-linear.js',
    role: 'router: linear.issue | linear.project | linear.search | linear.doc → MCP tools',
    risk: 2,
    subcommands: {
      issue:   { risk: 3, tools: ['list_issues','get_issue','save_issue'] },
      project: { risk: 4, tools: ['list_projects','get_project','save_project'] },
      search:  { risk: 1, tools: ['search_documentation'] },
      doc:     { risk: 3, tools: ['get_document','create_document','update_document'] }
    }
  },
  translate: {
    human:  'IX verb: mcp-linear — routes linear.{issue,project,search,doc} to MCP Linear tools.',
    agent:  '(falcon, meta.register_actor, cloud.linear, 2, colony, hookwall, executing, [feeds], single, IX, log, session, falcon-gw, light)',
    device: 'route subverb → mcp__claude_ai_Linear__*'
  }
};
