// cube: beast-node-orbital | IX-761 | D13 SURFACE (prime 41) | touches 1,5,15,19,41
// gates: hookwall | waves: heartbeat | federation: falcon-gw-4791
export const CUBE = {
  id: 'beast-node-orbital',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [1, 5, 15, 19, 41],
  gates: ['hookwall'],
  waves: ['heartbeat', 'pulse'],
  connectors: {
    'agent-beast':      'sibling-identity',
    'agent-falcon':     'sovereign-peer',
    'falcon-bridge-coords':'registers-at',
    'sovereign-4791':   'http://192.168.1.12:4791'
  },
  payload: {
    kind: 'orbital-agent',
    source: '~/beast-deploy/beast-node.js',
    role: 'S22 Ultra orbital agent; registers at sovereign :4791; trixie/debora linux layer',
    node_id: 's24-falcon',
    serial: 'R5CXA4MGQXV',
    model: 'SM-S721U1',
    sovereign_host: '192.168.1.12',
    sovereign_port: 4791,
    listen_port: 4798,
    capabilities: ['cpu','gpu','shell','node','python','relay'],
    heartbeat_ms: 30000
  },
  translate: {
    human:  'Beast node — S22 Ultra orbital, registers to Falcon sovereign :4791 every 30s.',
    agent:  '(beast, surface.orbital_register, remote.4791, 3, runtime, hookwall, registered, [relays], heartbeat, BN, signed, persistent, colony-gw, medium)',
    device: 'http.listen(:4798) + POST http://192.168.1.12:4791/api/hooks/events'
  }
};
