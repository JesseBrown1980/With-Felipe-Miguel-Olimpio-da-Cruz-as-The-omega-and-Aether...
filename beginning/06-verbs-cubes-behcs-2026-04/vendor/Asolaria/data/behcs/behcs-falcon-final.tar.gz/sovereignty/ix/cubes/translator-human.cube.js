// cube: translator-human | IX-702 | D22 TRANSLATION (79) | touches 1,2,10,18,25,26
// gates: hookwall | waves: single, relay, broadcast | role: tuple → English
function translate(tuple, f = 'human') {
  const t = Array.isArray(tuple) ? tuple : String(tuple).replace(/^\(|\)$/g,'').split(/\s*,\s*/);
  const [a,v,tg,r,l,g,s,,w,d,p,sc,sf,e] = t;
  const verb = String(v||'act').replace(/[._]/g,' ');
  const sent = `${a||'actor'} will ${verb} ${tg||'target'}${+r>0?` (risk ${r})`:''} at layer ${l||'?'} via gate ${g||'?'}, state ${s||'*'}, wave ${w||'?'}, dialect ${d||'?'}, proof ${p||'?'}, scope ${sc||'?'}, surface ${sf||'?'}, energy ${e||'?'}.`;
  return f === 'human' ? sent : { sentence: sent };
}
translate.human  = 'Translator: 24-tuple → English sentence.';
translate.agent  = '(falcon, translate.tuple_to_english, local.tuple, 0, runtime, hookwall, *, [], single, IX, log, session, falcon-gw, free)';
translate.device = 'fn.translate(tuple) → string (utf8)';
export const CUBE = {
  id: 'translator-human',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [1, 2, 10, 18, 25, 26],
  gates: ['hookwall'],
  waves: ['single', 'relay', 'broadcast'],
  connectors: { 'translator-agent': 'sibling-translator', 'translator-device': 'sibling-translator', 'falcon-agent-health': 'example-source' },
  payload: { kind: 'translator', input: { shape: 'omni-24-tuple' }, output: { shape: 'english-sentence', modality: 'text', encoding: 'utf8' } },
  translate
};
