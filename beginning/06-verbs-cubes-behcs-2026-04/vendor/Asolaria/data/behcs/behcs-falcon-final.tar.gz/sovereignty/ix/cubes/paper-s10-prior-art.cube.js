// cube: paper-s10-prior-art | IX-844 | D28 PROVENANCE (prime 107) | touches 5,10,22,28,35
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s10-prior-art',
  primaryCatalog: { D: 28, name: 'PROVENANCE', prime: 107 },
  touches: [5, 10, 22, 28, 35],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':         'belongs-to-paper',
    'behcs-mirror-bridge':          'contemporaneous-with',
    'paper-s09-named-pid-agents':   'prev-section',
    'paper-s11-evaluation':         'next-section',
    'doctrine-hilbert-codex':       'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_10_prior_art.md',
    section_number: 10,
    title: 'Prior Art',
    word_count: 2670,
    ix: 'IX-844',
    in_paper_full: true
  },
  translate: {
    human:  'Related work: Hilbert curves, Godel numbering, GNNs, immune-inspired security, ReAct/AutoGen/LangGraph, Society of Mind.',
    agent:  '(falcon, meta.read_section, paper.s10, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_10_prior_art.md, utf8) → markdown'
  }
};
