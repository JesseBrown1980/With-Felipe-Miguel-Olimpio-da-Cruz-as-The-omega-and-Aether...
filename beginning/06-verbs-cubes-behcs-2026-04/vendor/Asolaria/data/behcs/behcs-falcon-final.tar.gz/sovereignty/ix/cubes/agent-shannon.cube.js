// cube: agent-shannon | IX-722 | D1 ACTOR (2) | touches 15,17,18,19,6 | gates: hookwall+gnn
export const CUBE = {
  id: 'agent-shannon',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [6, 15, 17, 18, 19],
  gates: ['hookwall', 'gnn'],
  waves: ['single', 'scatter'],
  connectors: { 'agent-gaia': 'spawned-by', 'agent-sentinel': 'mesh-peer', 'agent-falcon': 'protects', 'agent-liris': 'protects' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/shannon.json',
    profileId: 'shannon-pentest-v1', role: 'security_scanner', tier: 'trusted_agent', riskCeiling: 7,
    device: { hostname: 'DESKTOP-J99VCNH', cpu: 'Intel i5-8300H', gpu: 'GTX 1050 4GB', ram: '16GB', os: 'Windows 11' },
    ai_model: 'claude-opus-4-6',
    location: { ip: '192.168.1.12', network: 'home_lan', machine: "Jesse's laptop", hilbert_level: 'L0' },
    notes: 'defensive-only; L6 of IX-491 7-layer immune system; sidecar at localhost:4791',
    sidecar: 'http://localhost:4791',
    intent: 'defensive',
    gate_chain: 'hookwall+gnn'
  },
  translate: {
    human:  'Agent: Shannon — trusted-agent security scanner, L6 immune layer, defensive-only sidecar.',
    agent:  '(shannon, meta.register_actor, local.self, 7, agent, hookwall+gnn, completed, [protects,observed_on], scatter, IX, log, operational, shannon, medium)',
    device: 'hostname=DESKTOP-J99VCNH sidecar=localhost:4791 profile=shannon-pentest-v1'
  }
};
