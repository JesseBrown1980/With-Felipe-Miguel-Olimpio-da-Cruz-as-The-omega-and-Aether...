// cube: paper-s08-omni-wave-dispatch | IX-842 | D9 WAVE (prime 23) | touches 5,9,10,16,22,35
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s08-omni-wave-dispatch',
  primaryCatalog: { D: 9, name: 'WAVE', prime: 23 },
  touches: [5, 9, 10, 16, 22, 35],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':         'belongs-to-paper',
    'behcs-mirror-bridge':          'contemporaneous-with',
    'paper-s07-architecture-map':   'prev-section',
    'paper-s09-named-pid-agents':   'next-section',
    'doctrine-hilbert-codex':       'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_8_omni_wave_dispatch.md',
    section_number: 8,
    title: 'Omni.Wave Dispatch',
    word_count: 2154,
    ix: 'IX-842',
    in_paper_full: true
  },
  translate: {
    human:  'The OmniShannon 6x6x6x12 wave grammar, named subagent operationalisation, and wave-by-wave execution data.',
    agent:  '(falcon, meta.read_section, paper.s08, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_8_omni_wave_dispatch.md, utf8) → markdown'
  }
};
