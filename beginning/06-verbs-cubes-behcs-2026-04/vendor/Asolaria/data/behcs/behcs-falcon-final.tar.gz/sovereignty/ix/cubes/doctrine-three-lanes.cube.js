// cube: doctrine-three-lanes | IX-824 | D35 MEMORY (149) | touches 1,10,18,22,43
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-three-lanes',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 18, 22, 43],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-colony-rules': 'sibling-doctrine',
    'doctrine-falcon2': 'sibling-doctrine',
    'doctrine-full-agent-roster': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_three_lanes.md',
    description: 'Three-lane doctrine — Claude, OpenAI, Gemini coverage for redundancy.'
  },
  translate: {
    human:  'Doctrine: three-lane agent coverage — Claude + OpenAI + Gemini.',
    agent:  '(falcon, meta.recall, doctrine.three-lanes, 1, colony, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, permanent, project_three_lanes.md, none, utf8, plaintext, jesse, 1, none, jesse-implicit, log)',
    device: "fs.readFileSync('.../project_three_lanes.md', 'utf8') → utf8 markdown"
  }
};
