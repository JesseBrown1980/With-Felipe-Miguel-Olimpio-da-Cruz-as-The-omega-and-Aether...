// cube: mcp-asolaria-control | IX-777 | D13 SURFACE (41) | touches 3,10,18,27
// gates: hookwall+gnn | waves: single | federation: falcon-local
export const CUBE = {
  id: 'mcp-asolaria-control',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [3, 10, 18, 27],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'network-tailscale':  'tunneled-through',
    'agent-gaia':         'hosted-on',
    'ix-gate-hookwall-v2': 'pre-gate',
    'config-claude-settings': 'configured-by'
  },
  payload: {
    source: '~/.claude/settings.json mcpServers.asolaria-control',
    kind: 'http-mcp', transport: 'http', url: 'http://100.75.63.31:4781/mcp',
    host: 'gaia@DESKTOP-J99VCNH', port: 4781,
    role: 'Asolaria sovereign control plane via Tailscale reverse bridge',
    cipher: 'tls-over-wireguard', risk: 3, ai_model: 'claude-opus-4-6'
  },
  translate: {
    human:  'MCP asolaria-control — reaches Gaia-hosted Asolaria express on :4781.',
    agent:  '(falcon, mcp.invoke, cloud.mesh, 3, agent, hookwall+gnn, executing, [tunneled-through,hosted-on], single, IX, log, session, falcon-gw, medium)',
    device: 'POST http://100.75.63.31:4781/mcp (via tailscale0)'
  }
};
