// cube: falcon-pid-node-heartbeat | IX-867 | D16 PID (53) | touches 1,5,20,44
// gates: hookwall | waves: pulse | federation: falcon-live-runtime
export const CUBE = {
  id: 'falcon-pid-node-heartbeat',
  primaryCatalog: { D: 16, name: 'PID', prime: 53 },
  touches: [1, 5, 20, 44],
  gates: ['hookwall'],
  waves: ['pulse'],
  connectors: {
    'agent-falcon':              'owner',
    'behcs-heartbeat-lx489':     'conceptual-sibling',
    'falcon-pid-behcs-cron':     'sibling-scheduler',
    'falcon-pid-node-agent':     'sibling-pid',
    'falcon-heartbeat':          'documents'
  },
  payload: {
    kind: 'live-pid', source: '~/asolaria/bin/falcon-heartbeat.js', pid_observed: 5027,
    cmdline: 'node /data/data/com.termux/files/home/asolaria/bin/falcon-heartbeat.js',
    role: 'legacy heartbeat daemon (pre-BEHCS, still running)',
    superseded_by: 'behcs-cron.js (cron pid 21158)',
    compute_class: 'orbital-mobile-node'
  },
  translate: {
    human:  'Legacy Falcon heartbeat Node.js process, pre-BEHCS. Superseded by behcs-cron.',
    agent:  '(falcon, lifecycle.process, local.falcon-heartbeat-js, 0, runtime, hookwall, running, [legacy,superseded], pulse, FA, log, persistent, falcon-gw, free)',
    device: 'pid=5027 exec=node argv=~/asolaria/bin/falcon-heartbeat.js'
  }
};
