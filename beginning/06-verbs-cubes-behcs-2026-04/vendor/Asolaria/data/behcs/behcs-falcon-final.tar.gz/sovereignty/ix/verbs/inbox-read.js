// IX verb: inbox-read | PID: falcon | IX-847
// Reads Falcon's BEHCS inbox at :4800/inbox — optional pop (drain) mode.
// Pairs with cube: ~/sovereignty/ix/cubes/ix-verb-inbox-read.cube.js

const http = require('http');

const BRIDGE = 'http://127.0.0.1:4800';

function httpGet(path) {
  return new Promise((resolve, reject) => {
    const req = http.get(BRIDGE + path, res => {
      let b = ''; res.on('data', c => b += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, json: JSON.parse(b) }); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
    req.setTimeout(3000, () => { req.destroy(); reject(new Error('timeout')); });
  });
}

function httpPostEmpty(path) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port: 4800, path, method: 'POST', headers: { 'Content-Length': 0 } }, res => {
      let b = ''; res.on('data', c => b += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, json: JSON.parse(b) }); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
    req.setTimeout(3000, () => { req.destroy(); reject(new Error('timeout')); });
    req.end();
  });
}

async function inboxRead(options = {}) {
  const n = options.n || 0;
  const drain = !!options.drain;
  if (drain) {
    const res = await httpPostEmpty('/inbox/drain');
    return { ok: res.json.ok, drained: res.json.drained, messages: res.json.messages, mode: 'drain' };
  }
  const res = await httpGet(n > 0 ? `/inbox?n=${n}` : '/inbox');
  return { ok: res.json.ok, count: res.json.count, messages: res.json.messages, mode: 'peek' };
}

async function inboxCount() {
  const res = await httpGet('/inbox/count');
  return { ok: res.json.ok, count: res.json.count };
}

module.exports = { inboxRead, inboxCount };
