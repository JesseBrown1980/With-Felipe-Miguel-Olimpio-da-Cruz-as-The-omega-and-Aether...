// cube: paper-s06-brown-hilbert-cube | IX-840 | D22 TRANSLATION (prime 79) | touches 5,10,22,35,15
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s06-brown-hilbert-cube',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [5, 10, 15, 22, 35],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':        'belongs-to-paper',
    'behcs-mirror-bridge':         'contemporaneous-with',
    'paper-s05-35loc-cognitive':   'prev-section',
    'paper-s07-architecture-map':  'next-section',
    'doctrine-hilbert-codex':      'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_6_brown_hilbert_cube.md',
    section_number: 6,
    title: 'The Brown Hilbert Cube: Three-Translator Bridge',
    word_count: 1861,
    ix: 'IX-840',
    in_paper_full: true
  },
  translate: {
    human:  'The three translator cubes (human, agent, device) as the assembly constituting the Brown Hilbert Cube.',
    agent:  '(falcon, meta.read_section, paper.s06, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_6_brown_hilbert_cube.md, utf8) → markdown'
  }
};
