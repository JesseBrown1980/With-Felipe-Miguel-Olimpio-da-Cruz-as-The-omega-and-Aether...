// cube: falcon-sensor-camera-selfie | IX-766 | D36 SENSOR (151)
// touches: D15 DEVICE, D21 HARDWARE, D25 MODALITY, D37 ENVIRONMENT
// gates: hookwall | waves: single, pulse | federation: falcon-local
// author: convergence-helm-05 | spec: IX-760 sensor-surface
export const CUBE = {
  id: 'falcon-sensor-camera-selfie',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [15, 21, 25, 37],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'falcon-sensor-camera-back': 'sibling-sensor',
    'falcon-sensor-camera-front': 'sibling-sensor',
    'falcon-sensor-camera-ultra': 'sibling-sensor',
    'agent-falcon': 'owned-by',
    'agent-falcon-state': 'reads-flow-into'
  },
  payload: {
    kind: 'camera-sensor',
    camera_id: '3',
    facing: 'front',
    max_resolution: { width: 3280, height: 2268 },
    focal_length_mm: 3.21,
    role: 'selfie-front',
    modality: 'optical-image',
    termux_command: 'termux-camera-info -c 3',
    capture_command: 'termux-camera-photo -c 3 <file>'
  },
  translate: {
    human:  'Sensor: Falcon selfie camera (id 3) — 3280x2268 max, 3.21mm lens.',
    agent:  '(falcon, sense.observe, local.camera-3, 1, sensor, hookwall, idle, [reads], single, FA, log, session, falcon-gw, light)',
    device: 'camera2.open(3) → ImageReader(3280x2268,JPEG), focal=3.21mm'
  }
};
