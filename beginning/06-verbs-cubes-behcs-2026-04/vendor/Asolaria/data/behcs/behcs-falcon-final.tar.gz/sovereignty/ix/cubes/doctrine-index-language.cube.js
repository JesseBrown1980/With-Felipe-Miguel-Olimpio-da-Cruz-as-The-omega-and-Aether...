// cube: doctrine-index-language | IX-814 | D35 MEMORY (149) | touches 1,2,6,10,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-index-language',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 2, 6, 10, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'ix-exec-runtime': 'documents',
    'doctrine-hilbert-codex': 'sibling-doctrine',
    'doctrine-cube-doctrine': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_index_language.md',
    description: 'IX grammar — nouns/verbs/chains/gates, exec pipeline, 3-gate immune system.'
  },
  translate: {
    human:  'Doctrine: IX index language — load-bearing grammar for map-map-mapped work.',
    agent:  '(falcon, meta.recall, doctrine.index-language, 1, runtime, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, permanent, project_index_language.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_index_language.md', 'utf8') → utf8 markdown"
  }
};
