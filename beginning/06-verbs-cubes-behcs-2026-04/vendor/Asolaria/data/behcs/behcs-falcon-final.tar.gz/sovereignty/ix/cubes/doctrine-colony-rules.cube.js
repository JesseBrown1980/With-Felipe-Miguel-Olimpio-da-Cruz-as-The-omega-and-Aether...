// cube: doctrine-colony-rules | IX-803 | D35 MEMORY (149) | touches 1,4,10,22,40
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-colony-rules',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 4, 10, 22, 40],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-three-lanes': 'sibling-doctrine',
    'doctrine-asolaria': 'sibling-doctrine',
    'doctrine-falcon-identity': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_colony_rules.md',
    description: 'Colony rules — Rule #1 Jesse rules all, Rule #2 three-lane doctrine.'
  },
  translate: {
    human:  'Doctrine: colony absolute laws — Jesse supreme, three-lane mandate.',
    agent:  '(falcon, meta.recall, doctrine.colony-rules, 1, civilization, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, permanent, project_colony_rules.md, none, utf8, plaintext, jesse, 1, none, jesse-implicit, log)',
    device: "fs.readFileSync('.../project_colony_rules.md', 'utf8') → utf8 markdown"
  }
};
