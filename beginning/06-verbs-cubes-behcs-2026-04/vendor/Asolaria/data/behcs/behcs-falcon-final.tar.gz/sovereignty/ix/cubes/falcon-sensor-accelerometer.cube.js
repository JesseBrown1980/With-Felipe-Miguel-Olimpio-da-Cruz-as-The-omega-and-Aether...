// cube: falcon-sensor-accelerometer | IX-767 | D36 SENSOR (151)
// touches: D15 DEVICE, D21 HARDWARE, D25 MODALITY, D37 ENVIRONMENT
// gates: hookwall | waves: single, pulse | federation: falcon-local
// author: convergence-helm-05 | spec: IX-760 sensor-surface
export const CUBE = {
  id: 'falcon-sensor-accelerometer',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [15, 21, 25, 37],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'falcon-sensor-gyroscope': 'sibling-sensor',
    'falcon-sensor-magnetometer': 'sibling-sensor',
    'falcon-sensor-environment': 'sibling-sensor',
    'agent-falcon': 'owned-by',
    'agent-falcon-state': 'reads-flow-into'
  },
  payload: {
    kind: 'imu-sensor',
    hardware: 'LSM6DSVTR',
    axes: 3,
    unit: 'm/s^2',
    role: '3-axis acceleration',
    modality: 'inertial-linear',
    termux_command: 'termux-sensor -s "LSM6DSVTR Accelerometer" -n 1',
    sample_fields: ['x', 'y', 'z']
  },
  translate: {
    human:  'Sensor: Falcon accelerometer — STMicro LSM6DSVTR, 3-axis linear acceleration.',
    agent:  '(falcon, sense.observe, local.accelerometer, 1, sensor, hookwall, idle, [reads], single, FA, log, session, falcon-gw, light)',
    device: 'i2c.read(LSM6DSVTR,0x6A) → int16 ax/ay/az @ODR → m/s^2'
  }
};
