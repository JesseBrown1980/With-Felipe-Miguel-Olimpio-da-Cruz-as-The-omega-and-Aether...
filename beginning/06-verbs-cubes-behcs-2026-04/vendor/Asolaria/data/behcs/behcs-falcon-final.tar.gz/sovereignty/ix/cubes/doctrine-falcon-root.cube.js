// cube: doctrine-falcon-root | IX-809 | D35 MEMORY (149) | touches 1,4,10,21,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-falcon-root',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 4, 10, 21, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-env-status': 'sibling-doctrine',
    'doctrine-falcon-identity': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_falcon_root.md',
    description: 'S25 claimed root-without-Knox; Termux su is stub — treat as unrooted userland.'
  },
  translate: {
    human:  'Doctrine: Falcon root — Termux su is fake, treat as un-rooted until verified.',
    agent:  '(falcon, meta.recall, doctrine.falcon-root, 1, chip, hookwall, completed, [contradicts], single, IX, log, permanent, falcon-gw, free, persistent, project_falcon_root.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_falcon_root.md', 'utf8') → utf8 markdown"
  }
};
