// cube: hilbert-language-map | hilbert: (computed at launch)
// IX-713 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D5 LAYER (prime 11, cube 1331)
// touches: D22 TRANSLATION, D23 FEDERATION
// gates: hookwall (risk 0) | waves: single | federation: gaia

export const CUBE = {
  id: 'hilbert-language-map',
  primaryCatalog: { D: 5, name: 'LAYER', prime: 11 },
  touches: [22, 23],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'omni-24d-executor':  'consumer',
    'omni-dispatch':      'consumer',
    'catalogs.json':      'spec-source'
  },
  payload: {
    kind: 'knowledge-data',
    source: '~/beast-deploy/hilbert-language-map.json',
    role: 'maps Hilbert layers (L0..L4) to primes, cubes, and canonical verb/target groupings',
    static: true,
    readable_by: ['falcon', 'gaia', 'liris'],
    file_loc: 110
  },
  translate: {
    human:  'Hilbert language map — static JSON mapping layers to primes, cubes, and canonical tuples.',
    agent:  '(falcon, knowledge.read, local.file, 0, app, hookwall, completed, [observed_on], single, IX, log, persistent, falcon-gw, free)',
    device: 'fs.readFile(~/beast-deploy/hilbert-language-map.json) → JSON.parse'
  }
};
