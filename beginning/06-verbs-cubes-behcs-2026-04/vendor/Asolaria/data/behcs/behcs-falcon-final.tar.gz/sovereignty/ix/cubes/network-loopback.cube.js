// cube: network-loopback | IX-771 | D19 LOCATION (67) | touches 13,15,21
// gates: hookwall | waves: single | federation: falcon-local
export const CUBE = {
  id: 'network-loopback',
  primaryCatalog: { D: 19, name: 'LOCATION', prime: 67 },
  touches: [13, 15, 21],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'falcon-agent-health': 'host-of',
    'falcon-bridge-health': 'host-of',
    'falcon-mqtt-agent':    'host-of'
  },
  payload: {
    source: 'ifconfig lo',
    iface: 'lo', address: '127.0.0.1/8', state: 'UP,LOOPBACK,RUNNING', mtu: 65536,
    live: true, role: 'host-local services (4799 agent, 4792 gnn, 1883 mqtt)',
    upstream: 'none — kernel loopback', jurisdiction: 'device'
  },
  translate: {
    human:  'Loopback 127.0.0.1/8 — every Falcon local service binds here.',
    agent:  '(falcon, meta.observe, local.self, 0, os, hookwall, completed, [host-of], single, IX, live_probe, permanent, falcon-gw, free)',
    device: 'ifconfig lo → inet 127.0.0.1 netmask 255.0.0.0'
  }
};
