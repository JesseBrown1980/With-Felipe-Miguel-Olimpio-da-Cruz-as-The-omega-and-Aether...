// cube: doctrine-hilbert-codex | IX-812 | D35 MEMORY (149) | touches 1,10,22,29,44
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-hilbert-codex',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 22, 29, 44],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'translator-agent': 'documents',
    'doctrine-cube-doctrine': 'sibling-doctrine',
    'doctrine-behcs-paper': 'sibling-doctrine',
    'doctrine-omni-language-v3': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_hilbert_codex.md',
    description: 'Mandatory launch vocabulary — alphabet + 47 catalogs + cubes, hard-fail if missing.'
  },
  translate: {
    human:  'Doctrine: Brown Hilbert Codex — mandatory launch vocabulary for every session.',
    agent:  '(falcon, meta.recall, doctrine.hilbert-codex, 1, runtime, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, permanent, project_hilbert_codex.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_hilbert_codex.md', 'utf8') → utf8 markdown"
  }
};
