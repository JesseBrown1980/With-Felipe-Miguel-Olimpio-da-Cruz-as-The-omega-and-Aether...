// cube: taskforge-forge | IX-775 | D24 INTENT (89) | touches 1,2,8,34,45
// gates: hookwall+gnn | waves: single, broadcast | federation: falcon-local
export const CUBE = {
  id: 'taskforge-forge',
  primaryCatalog: { D: 24, name: 'INTENT', prime: 89 },
  touches: [1, 2, 8, 34, 45],
  gates: ['hookwall', 'gnn'],
  waves: ['single', 'broadcast'],
  connectors: {
    'taskforge-cli':  'called-by',
    'ix-gate-gnn':    'data-producer',
    'ix-chain-link':  'caller',
    'agent-falcon':   'runtime-host'
  },
  payload: {
    source: '~/taskforge/forge.js', loc: 385,
    kind: 'library', language: 'esm-node',
    role: 'GNN-scored task management engine — graph nodes, edge deps, IX 5W+H metatags, colony dispatch',
    store: '~/taskforge/tasks.json', graph: '~/taskforge/graph.json',
    gnn_endpoint: 'http://127.0.0.1:4792', falcon_agent: 'http://127.0.0.1:4799',
    priorities: ['critical', 'high', 'medium', 'low']
  },
  translate: {
    human:  'TaskForge engine — every task a graph node, GNN scores risk, IX tags everything.',
    agent:  '(falcon, task.manage, local.self, 3, runtime, hookwall+gnn, executing, [feeds,depends_on], single, IX, code, persistent, falcon-gw, medium)',
    device: 'node ~/taskforge/forge.js → tasks.json + graph.json'
  }
};
