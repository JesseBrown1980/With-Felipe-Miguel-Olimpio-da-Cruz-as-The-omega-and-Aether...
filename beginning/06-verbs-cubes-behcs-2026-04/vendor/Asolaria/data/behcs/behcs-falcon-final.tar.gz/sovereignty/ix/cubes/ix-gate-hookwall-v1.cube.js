// cube: ix-gate-hookwall-v1 | IX-747 | D6 GATE (prime 13) | touches 4,7,11,41
// gates: hookwall | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-gate-hookwall-v1',
  primaryCatalog: { D: 6, name: 'GATE', prime: 13 },
  touches: [4, 7, 11, 41],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-gate-hookwall-v2': 'successor',
    'ix-exec-runtime':     'parent-runtime',
    'ix-gate-gnn':         'next-in-chain'
  },
  payload: {
    kind: 'gate',
    source: '~/sovereignty/ix/gates/hookwall.js',
    role: 'v1 stub fallback — always-allow hookwall when v2 spec is unavailable',
    risk_ceiling_default: 0,
    emits_state: ['gated'],
    proof_mode: 'log',
    stub: true,
    fallback_for: 'ix-gate-hookwall-v2'
  },
  translate: {
    human:  'IX gate: hookwall-v1 — stub fallback, always allow, zero risk.',
    agent:  '(falcon, gate.hookwall_v1, local.ix, 0, runtime, hookwall, gated, [], single, IX, log, session, falcon-gw, free)',
    device: 'require("./gates/hookwall.js")() → {allow:true,risk:{score:0}}'
  }
};
