// cube: doctrine-cube-doctrine | IX-804 | D35 MEMORY (149) | touches 1,10,22,30,44
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-cube-doctrine',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 22, 30, 44],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-hilbert-codex': 'sibling-doctrine',
    'doctrine-behcs-paper': 'sibling-doctrine',
    'doctrine-index-language': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_cube_doctrine.md',
    description: '35-LOC cap, shadow workflow, cube-language-first mandate (Jesse 2026-04-11).'
  },
  translate: {
    human:  'Doctrine: cube rules — 35-LOC hard cap, shadow edits, speak cube language.',
    agent:  '(falcon, meta.recall, doctrine.cube-doctrine, 1, runtime, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, permanent, project_cube_doctrine.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_cube_doctrine.md', 'utf8') → utf8 markdown"
  }
};
