// cube: doctrine-env-status | IX-806 | D35 MEMORY (149) | touches 1,10,13,22,37
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-env-status',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 13, 22, 37],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'falcon-agent-health': 'documents',
    'doctrine-falcon-root': 'sibling-doctrine',
    'doctrine-local-models': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_env_status.md',
    description: "Falcon runtime state — daemons up, /tmp blocked, rg missing, network path."
  },
  translate: {
    human:  'Doctrine: Falcon env status — what works, what is blocked.',
    agent:  '(falcon, meta.recall, doctrine.env-status, 1, runtime, hookwall, completed, [part_of], single, IX, log, session, falcon-gw, free, session, project_env_status.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_env_status.md', 'utf8') → utf8 markdown"
  }
};
