// cube: translator-agent | IX-703 | D22 TRANSLATION (79) | touches 1,2,10,18,25,26
// gates: hookwall | waves: single, relay, broadcast | role: any → canonical 24-tuple
const KEYS = ['actor','verb','target','risk','layer','gate','state','chain','wave','dialect','proof','scope','surface','energy','device','pid','profile','ai_model','location','time','hardware','translation','federation','intent'];
function translate(t, f = 'agent') {
  let a = Array.isArray(t) ? t.slice() : typeof t === 'string' ? t.replace(/^\(|\)$/g,'').split(/\s*,\s*/) : t && typeof t === 'object' ? KEYS.map(k => t[k] ?? '*') : [];
  while (a.length < 24) a.push('*');
  a = a.slice(0, 24);
  const canonical = '(' + a.map(v => Array.isArray(v) ? '['+v.join(';')+']' : String(v)).join(', ') + ')';
  if (f === 'agent') return canonical;
  if (f === 'object') return Object.fromEntries(KEYS.map((k,i)=>[k,a[i]]));
  return { canonical };
}
translate.human  = 'Translator: any form → canonical 24-tuple string.';
translate.agent  = '(falcon, translate.any_to_tuple, local.any, 0, runtime, hookwall, *, [], single, IX, log, session, falcon-gw, free)';
translate.device = 'fn.translate(any) → "(actor, verb, ...)" utf8';
export const CUBE = {
  id: 'translator-agent',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [1, 2, 10, 18, 25, 26],
  gates: ['hookwall'],
  waves: ['single', 'relay', 'broadcast'],
  connectors: { 'translator-human': 'sibling-translator', 'translator-device': 'sibling-translator', 'falcon-agent-health': 'example-source' },
  payload: { kind: 'translator', input: { shape: 'any' }, output: { shape: 'omni-24-tuple-string', modality: 'code', encoding: 'utf8' } },
  translate
};
