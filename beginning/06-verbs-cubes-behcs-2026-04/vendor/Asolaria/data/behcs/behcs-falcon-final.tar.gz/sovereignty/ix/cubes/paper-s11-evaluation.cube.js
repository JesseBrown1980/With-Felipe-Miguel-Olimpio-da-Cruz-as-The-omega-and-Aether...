// cube: paper-s11-evaluation | IX-845 | D11 PROOF (prime 31) | touches 5,10,11,22,35
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s11-evaluation',
  primaryCatalog: { D: 11, name: 'PROOF', prime: 31 },
  touches: [5, 10, 11, 22, 35],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':       'belongs-to-paper',
    'behcs-mirror-bridge':        'contemporaneous-with',
    'paper-s10-prior-art':        'prev-section',
    'paper-s12-future-work':      'next-section',
    'doctrine-hilbert-codex':     'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_11_evaluation.md',
    section_number: 11,
    title: 'Evaluation and Verification',
    word_count: 2806,
    ix: 'IX-845',
    in_paper_full: true
  },
  translate: {
    human:  'Launch-time verification, connector and LOC-cap audit, round-trip translator verification, six reproducible Falcon tests.',
    agent:  '(falcon, meta.read_section, paper.s11, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_11_evaluation.md, utf8) → markdown'
  }
};
