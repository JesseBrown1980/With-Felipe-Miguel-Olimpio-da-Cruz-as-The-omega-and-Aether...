// cube: doctrine-shannon-agent | IX-821 | D35 MEMORY (149) | touches 1,6,10,22,27,41
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-shannon-agent',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 6, 10, 22, 27, 41],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'agent-shannon': 'documents',
    'ix-gate-shannon': 'documents',
    'ix-verb-shannon': 'documents'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_shannon_agent.md',
    description: 'Shannon is L6 defensive pentest orchestrator — NOT a hacker agent.'
  },
  translate: {
    human:  'Doctrine: Shannon — defensive L6 security scanner, not offensive.',
    agent:  '(falcon, meta.recall, doctrine.shannon-agent, 1, colony, hookwall, completed, [corrects], single, IX, log, permanent, falcon-gw, free, persistent, project_shannon_agent.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_shannon_agent.md', 'utf8') → utf8 markdown"
  }
};
