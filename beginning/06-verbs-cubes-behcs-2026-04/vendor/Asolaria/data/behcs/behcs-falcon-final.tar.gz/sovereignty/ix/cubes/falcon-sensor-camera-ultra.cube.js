// cube: falcon-sensor-camera-ultra | IX-765 | D36 SENSOR (151)
// touches: D15 DEVICE, D21 HARDWARE, D25 MODALITY, D37 ENVIRONMENT
// gates: hookwall | waves: single, pulse | federation: falcon-local
// author: convergence-helm-05 | spec: IX-760 sensor-surface
export const CUBE = {
  id: 'falcon-sensor-camera-ultra',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [15, 21, 25, 37],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'falcon-sensor-camera-back': 'sibling-sensor',
    'falcon-sensor-camera-front': 'sibling-sensor',
    'falcon-sensor-camera-selfie': 'sibling-sensor',
    'agent-falcon': 'owned-by',
    'agent-falcon-state': 'reads-flow-into'
  },
  payload: {
    kind: 'camera-sensor',
    camera_id: '2',
    facing: 'back',
    max_resolution: { width: 4000, height: 3000 },
    focal_length_mm: 1.74,
    role: 'ultra-wide-back',
    modality: 'optical-image-wide',
    termux_command: 'termux-camera-info -c 2',
    capture_command: 'termux-camera-photo -c 2 <file>'
  },
  translate: {
    human:  'Sensor: Falcon ultra-wide back camera (id 2) — 4000x3000 max, 1.74mm lens.',
    agent:  '(falcon, sense.observe, local.camera-2, 1, sensor, hookwall, idle, [reads], single, FA, log, session, falcon-gw, light)',
    device: 'camera2.open(2) → ImageReader(4000x3000,JPEG), focal=1.74mm'
  }
};
