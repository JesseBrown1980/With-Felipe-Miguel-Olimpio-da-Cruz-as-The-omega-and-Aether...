// cube: paper-s01-previous-failures | IX-835 | D5 LAYER (prime 11) | touches 5,10,22,28,35
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s01-previous-failures',
  primaryCatalog: { D: 5, name: 'LAYER', prime: 11 },
  touches: [5, 10, 22, 28, 35],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':   'belongs-to-paper',
    'behcs-mirror-bridge':    'contemporaneous-with',
    'paper-s02-instant-self-spawn': 'next-section',
    'doctrine-hilbert-codex': 'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_1_previous_failures.md',
    section_number: 1,
    title: 'Previous Failures',
    word_count: 2069,
    ix: 'IX-835',
    in_paper_full: true
  },
  translate: {
    human:  'Chronology of architectures that preceded BEHCS on Falcon and diagnosis of why each broke.',
    agent:  '(falcon, meta.read_section, paper.s01, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_1_previous_failures.md, utf8) → markdown'
  }
};
