// cube: ix-chain-review | IX-756 | D8 CHAIN (prime 19) | touches 1,2,20,24
// gates: hookwall+shannon | waves: scout | federation: asolaria-index
export const CUBE = {
  id: 'ix-chain-review',
  primaryCatalog: { D: 8, name: 'CHAIN', prime: 19 },
  touches: [1, 2, 20, 24],
  gates: ['hookwall', 'shannon'],
  waves: ['scout', 'triad'],
  connectors: {
    'ix-chain-fabricate':       'receives-from',
    'ix-chain-link':            'phase-4-review',
    'ix-gate-shannon':          'security-scout',
    'ix-chain-mistake-learn':   'mistake-scout-source',
    'asolaria-index-rule':      'ASOLARIA_INDEX_ROOT/rule'
  },
  payload: {
    kind: 'chain',
    source: '~/sovereignty/ix/chains/review.js',
    role: '3-scout review: security (sentinel) + language (vector) + mistake-avoidance (sentinel)',
    ix_phase: 'IX-487+IX-518',
    pid: 'admin-sentinel-v1',
    scouts: ['security', 'language', 'mistake-avoidance'],
    verdicts: ['APPROVED', 'REVIEW_REQUIRED', 'BLOCKED']
  },
  translate: {
    human:  'IX chain: review — 3 scouts verify: security, language, past-mistake avoidance.',
    agent:  '(sentinel, chain.review, local.index, 5, runtime, hookwall+shannon, executing, [approves,blocks], triad, 3S, signed, session, falcon-gw, low)',
    device: 'require("./chains/review.js")(target) → {verdict,scouts}'
  }
};
