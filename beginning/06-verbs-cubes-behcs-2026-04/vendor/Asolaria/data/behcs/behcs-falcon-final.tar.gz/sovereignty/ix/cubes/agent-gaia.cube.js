// cube: agent-gaia | IX-716 | D1 ACTOR (2) | touches 15,17,19,39 | gates: hookwall+gnn+shannon
export const CUBE = {
  id: 'agent-gaia',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [15, 17, 19, 39],
  gates: ['hookwall', 'gnn', 'shannon'],
  waves: ['omni_6x6x6x12', 'broadcast'],
  connectors: { 'agent-falcon': 'spawns', 'agent-falcon2': 'spawns', 'omni-dispatch': 'driven-by', 'omni-24d-executor': 'driven-by' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/gaia.json',
    profileId: 'gaia-v1', role: 'sovereign_orchestrator', tier: 'owner', riskCeiling: 9,
    device: { hostname: 'DESKTOP-J99VCNH', user: 'acer', cpu: 'Intel i5-8300H', gpu: 'NVIDIA GTX 1050 4GB', ram: '16GB', os: 'Windows 11' },
    jurisdiction: 'US', location: { machine: "Jesse's laptop", network: 'home_wifi' },
    gate_chain: 'hookwall+gnn+shannon'
  },
  translate: {
    human:  'Agent: Gaia — owner-tier capital orchestrator on Jesse laptop.',
    agent:  '(gaia, meta.register_actor, local.self, 9, civilization, hookwall+gnn+shannon, completed, [spawns,blocks], omni_6x6x6x12, IX, signed, permanent, falcon-gw, massive)',
    device: 'hostname=DESKTOP-J99VCNH user=acer jurisdiction=US'
  }
};
