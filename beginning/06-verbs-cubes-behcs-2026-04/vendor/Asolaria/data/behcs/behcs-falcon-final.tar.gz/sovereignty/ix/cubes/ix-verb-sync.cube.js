// cube: ix-verb-sync | IX-735 | D2 VERB (prime 3) | touches 4,6,8,11,23,41
// gates: hookwall (risk 2) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-sync',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [4, 6, 8, 11, 23, 41],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':  'parent-runtime',
    'ix-verb-dispatch': 'sibling-verb',
    'ix-verb-observe':  'sibling-verb',
    'ix-noun-sovereignty':'common-subject'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/sync.js',
    role: 'trigger manifest-sync apply on Asolaria',
    risk: 2,
    target: 'http://localhost:4781/api/manifest-sync/apply',
    env: 'ASO_URL',
    method: 'POST',
    body_schema: { source: 'ix-runtime', ts: 'number' },
    proof_mode: 'log'
  },
  translate: {
    human:  'IX verb: sync — triggers manifest-sync apply on Asolaria.',
    agent:  '(falcon, sync.apply, cloud.asolaria, 2, colony, hookwall, executing, [triggers], single, IX, log, session, falcon-gw, light)',
    device: 'POST /api/manifest-sync/apply {source, ts} → json'
  }
};
