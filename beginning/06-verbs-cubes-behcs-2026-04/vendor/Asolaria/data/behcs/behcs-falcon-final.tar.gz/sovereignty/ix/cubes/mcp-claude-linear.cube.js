// cube: mcp-claude-linear | IX-779 | D22 TRANSLATION (79) | touches 3,10,18,27
// gates: hookwall+gnn | waves: single | federation: falcon-local
export const CUBE = {
  id: 'mcp-claude-linear',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [3, 10, 18, 27],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'mcp-claude-slack':     'sibling-mcp',
    'mcp-claude-gmail':     'sibling-mcp',
    'ix-verb-mcp-linear':   'call-site',
    'ix-gate-hookwall-v2':  'pre-gate',
    'config-claude-settings': 'configured-by'
  },
  payload: {
    source: '~/.claude/settings.json permissions.allow',
    kind: 'cloud-mcp', provider: 'claude.ai', tool_prefix: 'mcp__claude_ai_Linear__',
    capabilities: ['save_issue', 'list_issues', 'save_project', 'save_milestone', 'create_document', 'list_cycles', 'save_comment'],
    entities: ['issue', 'project', 'document', 'milestone', 'team', 'cycle', 'label'],
    cipher: 'tls', risk: 3, ai_model: 'claude-opus-4-6'
  },
  translate: {
    human:  'Linear MCP via claude.ai — issue/project/document/milestone CRUD.',
    agent:  '(falcon, mcp.linear_save_issue, cloud.claude_ai, 3, cloud, hookwall+gnn, executing, [sibling-mcp], single, IX, log, session, falcon-gw, medium)',
    device: 'mcp__claude_ai_Linear__save_issue({ team, title, description })'
  }
};
