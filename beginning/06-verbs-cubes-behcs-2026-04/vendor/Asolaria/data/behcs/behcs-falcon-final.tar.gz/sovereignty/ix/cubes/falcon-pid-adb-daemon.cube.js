// cube: falcon-pid-adb-daemon | IX-871 | D16 PID (53) | touches 1,21,13,19
// gates: hookwall | waves: single | federation: falcon-live-runtime
export const CUBE = {
  id: 'falcon-pid-adb-daemon',
  primaryCatalog: { D: 16, name: 'PID', prime: 53 },
  touches: [1, 21, 13, 19],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'agent-falcon':              'owner',
    'falcon-pid-falcon-bridge':  'tunnels-for',
    'network-loopback':          'listens-on',
    'mcp-asolaria-control':      'enables-tunnel-to-acer'
  },
  payload: {
    kind: 'live-pid', process: 'adb', pid_observed: 6945,
    cmdline: 'adb -L tcp:5037 fork-server server --reply-fd 4',
    listens_on: 'tcp:5037',
    role: 'Android Debug Bridge local daemon — enables USB adb-reverse tunnels to acer (4947 bus, 4913 type, 4781 MCP)',
    tunnels_observed: ['tcp:4947 → acer:4947', 'tcp:4913 → acer:4913', 'tcp:4781 → acer:4781']
  },
  translate: {
    human:  'ADB daemon on Falcon — the USB tunnel infrastructure that carries all three BEHCS channels to Asolaria.',
    agent:  '(falcon, lifecycle.process, local.adb-daemon, 0, chip, hookwall, running, [adb-reverse-tunnels-4947-4913-4781], single, FA, log, persistent, usb-sovereignty, free)',
    device: 'pid=6945 exec=adb listens=tcp:5037 tunnels=[4947,4913,4781]'
  }
};
