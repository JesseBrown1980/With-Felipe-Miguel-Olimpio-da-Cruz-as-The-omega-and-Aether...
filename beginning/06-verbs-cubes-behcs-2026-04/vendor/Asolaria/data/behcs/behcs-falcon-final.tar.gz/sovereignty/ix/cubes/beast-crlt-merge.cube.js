// cube: beast-crlt-merge | IX-758 | D23 FEDERATION (prime 83) | touches 5,10,22,35
// gates: hookwall | waves: merge | federation: colony-wide
export const CUBE = {
  id: 'beast-crlt-merge',
  primaryCatalog: { D: 23, name: 'FEDERATION', prime: 83 },
  touches: [5, 10, 22, 35],
  gates: ['hookwall'],
  waves: ['merge', 'single'],
  connectors: {
    'agent-liris':             'inventor',
    'beast-omnilanguage-hooks':'drift-source',
    'omni-dispatch':           'merge-target',
    'agent-gaia':              'federation-peer'
  },
  payload: {
    kind: 'federation-merge',
    source: '~/beast-deploy/crltMerge.js',
    role: 'CRLT — Conflict-Free Replicated Language Type; merges tuple-addressed language entries across federation nodes',
    inventor: 'liris',
    exports: ['crltMerge', 'crltValidate'],
    properties: ['locally_complete','globally_consistent','monotonic','merge_trivial','partition_tolerant'],
    dimension_count: 14
  },
  translate: {
    human:  'CRLT merge — Liris invention. Conflict-free replicated language type for 14D omnilanguage federation.',
    agent:  '(liris, federation.crlt_merge, colony.all, 2, runtime, hookwall, merged, [federates], merge, CRLT, signed, persistent, colony-gw, low)',
    device: 'require("~/beast-deploy/crltMerge.js").crltMerge(local,remote) → Entry[]'
  }
};
