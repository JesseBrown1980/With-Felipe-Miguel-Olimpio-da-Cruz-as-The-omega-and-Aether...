// cube: phone-pro-mirror-connector | IX-826 | D13 SURFACE (41) | touches 13,14,15,21,25
// gates: hookwall | waves: pulse | federation: asolaria-mirror-bridge
// archaeology: ~/liris-test/Asolaria/src/connectors/phoneProMirrorConnector.js (12 KB, Feb 27)
export const CUBE = {
  id: 'phone-pro-mirror-connector',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [13, 14, 15, 21, 25],
  gates: ['hookwall'],
  waves: ['pulse'],
  connectors: {
    'phone-mirror-connector':    'basic-sibling',
    'desktop-display-connector': 'display-peer',
    'behcs-mirror-bridge':       'bridge-parent',
    'ix-verb-phone-adb':         'underlying-verb',
    'agent-falcon':              'stream-source'
  },
  payload: {
    kind: 'js-coordinator-archaeology',
    source: '~/liris-test/Asolaria/src/connectors/phoneProMirrorConnector.js',
    runtime_host: 'laptop-node — spawns scrcpy.exe on Windows',
    role: 'Advanced scrcpy wrapper for high-bitrate phone stream control',
    primitives: ['scrcpy.exe --serial=<s> --window-title="Phone Mirror - Asolaria" --encoder h264 --bit-rate 4M'],
    energy_profile: 'heavy (h264 encode on phone, decode on laptop)',
    falcon_role: 'passive source — scrcpy USB/TCP client pulls frames'
  },
  translate: {
    human:  'Phone pro-mirror — scrcpy.exe wrapper for advanced low-latency stream from Falcon.',
    agent:  '(asolaria, surface.stream, falcon.screen, 3, runtime, hookwall, *, [scrcpy], pulse, LX-259, log, session, asolaria-gw, heavy)',
    device: 'spawn scrcpy.exe --serial=${FALCON_SERIAL} --bit-rate 4M'
  }
};
