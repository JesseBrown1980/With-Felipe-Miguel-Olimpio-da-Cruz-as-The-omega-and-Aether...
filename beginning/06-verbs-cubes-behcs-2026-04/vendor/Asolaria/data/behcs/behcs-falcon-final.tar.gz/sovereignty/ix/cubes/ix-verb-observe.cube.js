// cube: ix-verb-observe | hilbert: (computed at launch)
// IX-708 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D2 VERB (prime 3, cube 27)
// touches: D11 PROOF, D41 AUDIT
// gates: hookwall (risk 0) | waves: single | federation: ix-runtime

export const CUBE = {
  id: 'ix-verb-observe',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [11, 41],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':  'parent-runtime',
    'ix-noun-health':   'common-subject',
    'audit-ndjson':     'proof-sink'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/observe.js',
    role: 'record an observation into the IX proof chain',
    proof_mode: 'log',
    audit_mode: 'ndjson'
  },
  translate: {
    human:  'IX verb: observe — writes a proof-bearing observation to the NDJSON audit log.',
    agent:  '(falcon, observe.record, local.ix, 0, runtime, hookwall, executing, [proves], single, IX, log, session, falcon-gw, free)',
    device: 'fs.appendFile(state/observe.ndjson, JSON.stringify(obs)+"\\n")'
  }
};
