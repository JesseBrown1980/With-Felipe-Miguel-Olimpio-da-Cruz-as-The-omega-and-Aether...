// cube: falcon-heartbeat | hilbert: (computed at launch)
// IX-704 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D9 WAVE (prime 23, cube 12167)
// touches: D1 ACTOR, D13 SURFACE, D20 TIME, D24 INTENT=scheduled
// gates: hookwall (risk 0) | waves: pulse | federation: falcon-orbital

export const CUBE = {
  id: 'falcon-heartbeat',
  primaryCatalog: { D: 9, name: 'WAVE', prime: 23 },
  touches: [1, 13, 20, 24],
  gates: ['hookwall'],
  waves: ['pulse'],
  connectors: {
    'falcon-bridge-health': 'co-process',
    'asolaria-mcp-4781':    'heartbeat-target',
    'systemd-less-daemon':  'termux-foreground'
  },
  payload: {
    kind: 'long-running-process',
    source: '~/asolaria/bin/falcon-heartbeat.js',
    role: 'emits periodic falcon pulse to mother Asolaria',
    interval_hint: '30s',
    intent: 'scheduled',
    proof: 'ps -ef | grep falcon-heartbeat.js'
  },
  translate: {
    human:  'Falcon heartbeat daemon — periodic pulse to Asolaria mother, scheduled intent.',
    agent:  '(falcon, emit.heartbeat, aso.asolaria, 0, agent, hookwall, executing, [triggers], pulse, FA, log, persistent, falcon-gw, free)',
    device: 'node ~/asolaria/bin/falcon-heartbeat.js (foreground termux process)'
  }
};
