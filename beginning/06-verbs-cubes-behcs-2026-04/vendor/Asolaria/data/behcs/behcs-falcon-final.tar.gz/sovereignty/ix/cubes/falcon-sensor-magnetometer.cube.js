// cube: falcon-sensor-magnetometer | IX-768 | D36 SENSOR (151)
// touches: D15 DEVICE, D21 HARDWARE, D25 MODALITY, D37 ENVIRONMENT
// gates: hookwall | waves: single, pulse | federation: falcon-local
// author: convergence-helm-05 | spec: IX-760 sensor-surface
export const CUBE = {
  id: 'falcon-sensor-magnetometer',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [15, 21, 25, 37],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'falcon-sensor-accelerometer': 'sibling-sensor',
    'falcon-sensor-gyroscope': 'sibling-sensor',
    'falcon-sensor-environment': 'sibling-sensor',
    'agent-falcon': 'owned-by',
    'agent-falcon-state': 'reads-flow-into'
  },
  payload: {
    kind: 'magnetic-sensor',
    hardware: 'AK09918C',
    axes: 3,
    unit: 'uT',
    role: '3-axis magnetic field',
    modality: 'magnetic-flux',
    termux_command: 'termux-sensor -s "AK09918C Magnetometer" -n 1',
    sample_fields: ['x', 'y', 'z']
  },
  translate: {
    human:  'Sensor: Falcon magnetometer — Asahi Kasei AK09918C, 3-axis flux.',
    agent:  '(falcon, sense.observe, local.magnetometer, 1, sensor, hookwall, idle, [reads], single, FA, log, session, falcon-gw, light)',
    device: 'i2c.read(AK09918C,0x10) → int16 x/y/z → uT'
  }
};
