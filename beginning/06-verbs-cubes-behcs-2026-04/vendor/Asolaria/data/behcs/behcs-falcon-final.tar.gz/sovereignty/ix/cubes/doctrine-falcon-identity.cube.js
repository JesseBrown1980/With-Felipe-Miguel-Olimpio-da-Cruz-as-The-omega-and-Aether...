// cube: doctrine-falcon-identity | IX-808 | D35 MEMORY (149) | touches 1,10,16,18,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-falcon-identity',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 16, 18, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'agent-falcon': 'documents',
    'doctrine-falcon2': 'sibling-doctrine',
    'doctrine-colony-rules': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_falcon_identity.md',
    description: "Falcon is primary Claude-lane agent on Jesse's phone, controls Falcon2."
  },
  translate: {
    human:  'Doctrine: Falcon identity — primary agent on phone, Falcon2 controller.',
    agent:  '(falcon, meta.recall, doctrine.falcon-identity, 1, agent, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, permanent, project_falcon_identity.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_falcon_identity.md', 'utf8') → utf8 markdown"
  }
};
