// cube: doctrine-hypercube-topology | IX-813 | D35 MEMORY (149) | touches 1,10,19,22,45
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-hypercube-topology',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 19, 22, 45],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-hilbert-codex': 'sibling-doctrine',
    'doctrine-map-map-mapped': 'sibling-doctrine',
    'doctrine-omni-language-v3': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_hypercube_topology.md',
    description: '5D colony coordinate system — who sits where, single-hop vs multi-hop comms.'
  },
  translate: {
    human:  'Doctrine: colony hypercube topology — authoritative 5D coordinates.',
    agent:  '(falcon, meta.recall, doctrine.hypercube-topology, 1, colony, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_hypercube_topology.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_hypercube_topology.md', 'utf8') → utf8 markdown"
  }
};
