// cube: ix-verb-phone-adb | IX-743 | D2 VERB (prime 3) | touches 3,4,6,11,15,21,41
// gates: hookwall+gnn (risk 5) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-phone-adb',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [3, 4, 6, 11, 15, 21, 41],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime': 'parent-runtime',
    'ix-noun-falcon':  'common-subject',
    'agent-falcon':    'target-device',
    'translator-device':'device-projector'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/phone-adb.js',
    role: 'ADB to Falcon: phone.screen | phone.input | phone.shell (whitelisted)',
    risk: 5,
    device_serial_env: 'FALCON_SERIAL',
    default_serial: 'R5CXA4MGQXV',
    subcommands: {
      screen: { cmd: 'exec-out screencap -p', risk: 2 },
      input:  { cmd: 'shell input',           risk: 6 },
      shell:  { cmd: 'shell',                 risk: 5 }
    },
    shell_allowlist: ['getprop','dumpsys','pm','am','settings','input','screencap','wm','svc','cmd','logcat','ls','cat','id','whoami','uname','date','uptime','df','free','ps','top','ifconfig','ip']
  },
  translate: {
    human:  'IX verb: phone.adb — screen/input/shell against Falcon, shell whitelist enforced.',
    agent:  '(falcon, device.control, local.phone, 5, device, hookwall+gnn, executing, [triggers], single, IX, log, session, falcon-gw, light)',
    device: 'adb -s ${FALCON_SERIAL} <screen|input|shell> <args>'
  }
};
