// cube: invoke-desktop-input-ps1 | IX-831 | D2 VERB (3) | touches 2,4,5,6,21
// gates: hookwall+gnn | waves: single | federation: asolaria-mirror-bridge
// archaeology: ~/liris-test/Asolaria/tools/Invoke-DesktopInput.ps1 (6.6 KB, Feb 16)
export const CUBE = {
  id: 'invoke-desktop-input-ps1',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [2, 4, 5, 6, 21],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'desktop-control-connector': 'parent-coordinator',
    'desktop-input-host-ps1':    'persistent-sibling',
    'ix-verb-laptop-type':       'ultimate-caller',
    'behcs-mirror-bridge':       'bridge-parent',
    'agent-gaia':                'laptop-host'
  },
  payload: {
    kind: 'powershell-helper-archaeology',
    source: '~/liris-test/Asolaria/tools/Invoke-DesktopInput.ps1',
    runtime_host: 'Windows PowerShell (C:\\Users\\acer\\Asolaria\\tools\\)',
    role: 'Per-call PowerShell API — compiles C# Add-Type + P/Invoke user32.dll',
    native_calls: ['SetForegroundWindow', 'SendInput', 'mouse_event', 'PostMessage(WM_CHAR)', 'FindWindow', 'EnumWindows'],
    layer: 'runtime',
    risk: 8,
    model: 'per-call-spawn'
  },
  translate: {
    human:  'Invoke-DesktopInput.ps1 — PowerShell wrapper that P/Invokes user32.dll to inject keystrokes and mouse events.',
    agent:  '(asolaria, verb.ps.inject, windows.runtime, 8, runtime, hookwall+gnn, executing, [gaia], single, IX-831, log, session, asolaria-gw, light)',
    device: 'user32.dll::SendInput / user32.dll::SetForegroundWindow / user32.dll::PostMessage(WM_CHAR)'
  }
};
