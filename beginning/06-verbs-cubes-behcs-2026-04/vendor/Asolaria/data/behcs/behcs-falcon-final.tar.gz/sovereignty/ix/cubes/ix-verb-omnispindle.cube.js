// cube: ix-verb-omnispindle | IX-745 | D2 VERB (prime 3) | touches 1,3,4,6,9,11,41
// gates: hookwall+gnn (risk 4) | waves: broadcast, single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-omnispindle',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [1, 3, 4, 6, 9, 11, 41],
  gates: ['hookwall', 'gnn'],
  waves: ['broadcast', 'single'],
  connectors: {
    'ix-exec-runtime':   'parent-runtime',
    'omni-dispatch':     'peer-dispatcher',
    'ix-verb-swarmdesk': 'sibling-verb',
    'agent-helm':        'lane-peer',
    'agent-vector':      'lane-peer'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/omnispindle.js',
    role: 'dispatch to 5 Omnispindle lanes via Asolaria /api/omnispindle',
    risk: 4,
    base: 'http://localhost:4781/api/omnispindle',
    env: 'ASO_URL',
    lanes: ['helm', 'vector', 'rook', 'forge', 'falcon'],
    auth_env: 'ASO_GATEWAY_TOKEN',
    subcommands: { status: { endpoint: '/status', method: 'GET', risk: 0 }, dispatch: { endpoint: '/dispatch', method: 'POST', risk: 4 }, broadcast: { endpoint: '/broadcast', method: 'POST', risk: 4 } }
  },
  translate: {
    human:  'IX verb: omnispindle — dispatches/broadcasts to 5 lanes (helm,vector,rook,forge,falcon).',
    agent:  '(falcon, deliver.dispatch, cloud.asolaria, 4, colony, hookwall+gnn, executing, [triggers], broadcast, IX, log, session, falcon-gw, medium)',
    device: 'POST http://localhost:4781/api/omnispindle/{status|dispatch|broadcast}'
  }
};
