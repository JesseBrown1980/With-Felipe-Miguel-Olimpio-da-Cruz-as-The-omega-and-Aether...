// cube: beast-pipeline-gates | IX-760 | D6 GATE (prime 13) | touches 4,7,11,41
// gates: hookwall | waves: staged | federation: ci-pipeline
export const CUBE = {
  id: 'beast-pipeline-gates',
  primaryCatalog: { D: 6, name: 'GATE', prime: 13 },
  touches: [4, 7, 11, 41],
  gates: ['hookwall'],
  waves: ['staged', 'pipeline'],
  connectors: {
    'ix-gate-hookwall-v2':  'sibling-gate',
    'ix-chain-security-sweep':'sibling-chain',
    'beast-crlt-merge':     'validates-for',
    'beast-node-orbital':   'runs-on'
  },
  payload: {
    kind: 'pipeline-gates',
    source: '~/beast-deploy/pipelineGates.js',
    role: 'Pipeline gate chain orchestrator — 7-stage CI with pre-dev/pre-staging/pre-prod validation',
    exports: ['validatePreDevGate','validatePreStagingGate','validatePreProdGate'],
    stages: ['pre-dev','pre-staging','pre-prod'],
    checks_per_stage: [4, 4, 5],
    axiom_range: 'AX1-AX7'
  },
  translate: {
    human:  'Pipeline gates — 7-stage CI orchestrator with compact-packet, compile-integrity, and pro-ready checks.',
    agent:  '(beast, gate.pipeline_stage, local.ci, 3, runtime, hookwall, gated, [blocks,advances], staged, PG, signed, session, colony-gw, low)',
    device: 'require("~/beast-deploy/pipelineGates.js").validatePreDevGate(branch) → {ok,checks}'
  }
};
