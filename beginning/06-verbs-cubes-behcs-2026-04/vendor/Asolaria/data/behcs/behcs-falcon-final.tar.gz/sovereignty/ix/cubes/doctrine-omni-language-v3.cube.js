// cube: doctrine-omni-language-v3 | IX-819 | D35 MEMORY (149) | touches 1,2,10,22,29
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-omni-language-v3',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 2, 10, 22, 29],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'omni-language-v3-spec': 'documents',
    'doctrine-hilbert-codex': 'sibling-doctrine',
    'doctrine-index-language': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_omni_language_v3.md',
    description: '24D prime-indexed tuple language with Hilbert Hotel growth — canonical hypercube.'
  },
  translate: {
    human:  'Doctrine: Omni Language V3 / Hilbert Prime Cube — canonical 24D language.',
    agent:  '(falcon, meta.recall, doctrine.omni-language-v3, 1, runtime, hookwall, completed, [supersedes], single, IX, log, permanent, falcon-gw, free, permanent, project_omni_language_v3.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_omni_language_v3.md', 'utf8') → utf8 markdown"
  }
};
