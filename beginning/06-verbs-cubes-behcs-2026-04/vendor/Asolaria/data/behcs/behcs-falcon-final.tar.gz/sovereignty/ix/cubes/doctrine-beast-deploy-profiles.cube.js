// cube: doctrine-beast-deploy-profiles | IX-801 | D35 MEMORY (149) | touches 1,10,16,17,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-beast-deploy-profiles',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 16, 17, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-full-agent-roster': 'sibling-doctrine',
    'agent-gaia': 'documents',
    'agent-liris': 'documents'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_beast_deploy_profiles.md',
    description: '11 canonical agent profiles in ~/beast-deploy/profiles/ — tier/role/device authority.'
  },
  translate: {
    human:  'Doctrine: beast-deploy profiles — authoritative 11-agent roster.',
    agent:  '(falcon, meta.recall, doctrine.beast-deploy-profiles, 1, colony, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_beast_deploy_profiles.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_beast_deploy_profiles.md', 'utf8') → utf8 markdown"
  }
};
