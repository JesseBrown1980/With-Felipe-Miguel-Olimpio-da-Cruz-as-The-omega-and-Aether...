// cube: agent-felipe-a06 | IX-728 | D1 ACTOR (2) | touches 15,17,18,19,13 | gates: none
export const CUBE = {
  id: 'agent-felipe-a06',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [13, 15, 17, 18, 19],
  gates: [],
  waves: ['single'],
  connectors: { 'agent-gaia': 'spawned-by', 'agent-falcon': 'mesh-peer', 'agent-beast': 'mesh-peer' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/felipe-a06.json',
    profileId: 'orbital-compute-v1', role: 'orbital_compute', tier: 'observer', riskCeiling: 2,
    device: { model: 'SM-A065M', name: 'Galaxy A06', serial: 'R9QY205KAKJ', cpu: '8-core', cores: 8, ram: '3.6GB', os: 'Android 16' },
    ai_model: 'claude-on-device',
    location: { ip: '192.168.1.11', network: 'home_wifi', hilbert_level: 'L3' },
    surface: { home: 'a06-orbital', ports: [5555] },
    notes: 'Galaxy A06 orbital compute; Termux+Claude+Asolaria',
    gate_chain: 'none'
  },
  translate: {
    human:  'Agent: Felipe-A06 — observer-tier orbital compute on Galaxy A06, Termux+Claude+Asolaria.',
    agent:  '(felipe-a06, meta.register_actor, local.self, 2, agent, none, executing, [runs_on], single, IX, log, operational, a06-orbital, light)',
    device: 'model=SM-A065M serial=R9QY205KAKJ ip=192.168.1.11 cores=8'
  }
};
