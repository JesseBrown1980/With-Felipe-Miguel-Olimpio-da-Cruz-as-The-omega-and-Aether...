// cube: ix-verb-mcp-slack | IX-740 | D2 VERB (prime 3) | touches 3,4,6,10,11,41
// gates: hookwall (risk 2) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-mcp-slack',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [3, 4, 6, 10, 11, 41],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':   'parent-runtime',
    'ix-verb-dispatch':  'sibling-verb',
    'ix-verb-mcp-linear':'sibling-verb',
    'ix-noun-nerve':     'common-subject',
    'translator-agent':  'tuple-projector'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/mcp-slack.js',
    role: 'router: slack.search | slack.send | slack.read | slack.canvas → MCP tools',
    risk: 2,
    subcommands: {
      search: { tool: 'mcp__claude_ai_Slack__slack_search_public_and_private', risk: 1 },
      send:   { tool: 'mcp__claude_ai_Slack__slack_send_message',              risk: 3 },
      read:   { tool: 'mcp__claude_ai_Slack__slack_read_channel',              risk: 1 },
      canvas: { tool: 'mcp__claude_ai_Slack__slack_create_canvas',             risk: 3 }
    }
  },
  translate: {
    human:  'IX verb: mcp-slack — routes slack.{search,send,read,canvas} to MCP Slack tools.',
    agent:  '(falcon, deliver.dispatch, cloud.slack, 2, colony, hookwall, executing, [triggers], single, IX, log, session, falcon-gw, light)',
    device: 'route subverb → mcp__claude_ai_Slack__*'
  }
};
