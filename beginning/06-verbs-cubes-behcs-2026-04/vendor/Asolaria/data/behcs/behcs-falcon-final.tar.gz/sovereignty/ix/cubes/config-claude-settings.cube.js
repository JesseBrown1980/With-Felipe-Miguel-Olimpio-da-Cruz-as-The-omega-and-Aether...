// cube: config-claude-settings | IX-783 | D17 PROFILE (59) | touches 1,10,18,35
// gates: hookwall | waves: single | federation: falcon-local
export const CUBE = {
  id: 'config-claude-settings',
  primaryCatalog: { D: 17, name: 'PROFILE', prime: 59 },
  touches: [1, 10, 18, 35],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'config-claude-md':      'sibling-config',
    'mcp-asolaria-control':  'registers',
    'mcp-claude-slack':      'allows',
    'mcp-claude-linear':     'allows',
    'mcp-claude-gmail':      'allows',
    'agent-falcon':          'loaded-by'
  },
  payload: {
    source: '~/.claude/settings.json', kind: 'harness-config',
    role: 'Claude Code harness: permissions allowlist, hooks, mcpServers, sandbox, bypass mode',
    mcp_servers: ['asolaria-control'],
    default_mode: 'bypassPermissions', effort_level: 'high',
    hooks: ['SessionStart→/tmp build'],
    risk: 2, memory_tier: 'permanent'
  },
  translate: {
    human:  'settings.json — harness permissions, MCP registry, hooks, bypass mode.',
    agent:  '(falcon, meta.load_config, local.self, 2, runtime, hookwall, completed, [registers,allows], single, IX, hash, permanent, falcon-gw, free)',
    device: 'cat ~/.claude/settings.json → harness boot'
  }
};
