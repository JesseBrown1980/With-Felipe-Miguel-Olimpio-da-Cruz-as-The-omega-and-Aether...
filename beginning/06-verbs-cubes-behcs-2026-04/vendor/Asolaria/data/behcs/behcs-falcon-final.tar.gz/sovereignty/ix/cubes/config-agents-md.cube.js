// cube: config-agents-md | IX-782 | D17 PROFILE (59) | touches 1,10,18,35
// gates: hookwall | waves: single | federation: falcon-local
export const CUBE = {
  id: 'config-agents-md',
  primaryCatalog: { D: 17, name: 'PROFILE', prime: 59 },
  touches: [1, 10, 18, 35],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'config-claude-md':       'twin-lane',
    'config-claude-settings': 'sibling-config',
    'agent-falcon2':          'loaded-by'
  },
  payload: {
    source: '~/AGENTS.md', kind: 'identity-manifest', lane: 'codex',
    role: 'Codex / OpenAI lane twin of CLAUDE.md — mirrors identity and launch protocol for Falcon2',
    twins: '~/CLAUDE.md',
    ai_model: 'codex-o4-mini', memory_tier: 'permanent',
    risk: 2, read_mode: 'codex session auto-inject',
    note: 'Three-lane doctrine requires this parallel to CLAUDE.md'
  },
  translate: {
    human:  'AGENTS.md — Codex lane twin of CLAUDE.md for Falcon2.',
    agent:  '(falcon2, meta.load_profile, local.self, 2, agent, hookwall, completed, [twin-lane], single, IX, hash, permanent, falcon-gw, free)',
    device: 'cat ~/AGENTS.md → codex session context'
  }
};
