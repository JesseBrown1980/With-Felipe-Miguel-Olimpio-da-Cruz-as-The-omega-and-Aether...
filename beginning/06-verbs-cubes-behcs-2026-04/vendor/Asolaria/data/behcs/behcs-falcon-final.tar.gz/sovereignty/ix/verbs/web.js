// IX verb: web | PID: asolaria | Profile: asolaria | IX-506
// Web backend surface — 2 verbs: web.search, web.fetch
// Routes to WebSearch and WebFetch MCP tools

const SUBCOMMANDS = {
  search: { tool: 'WebSearch', risk: 1 },
  fetch:  { tool: 'WebFetch',  risk: 3 },
};

/**
 * @param {string} command — format: "subcommand args..." e.g. "search Intel ME neutralize"
 * @returns {Promise<{ok: boolean, result: any, ts: number}>}
 */
async function web(command) {
  const ts = Date.now();
  if (!command) {
    return { ok: false, result: { error: 'usage: web.search|web.fetch <query|url>', subcommands: Object.keys(SUBCOMMANDS) }, ts };
  }

  const parts = command.trim().split(/\s+/);
  let sub = parts[0].replace(/^web\./, '');
  const args = parts.slice(1).join(' ');

  const entry = SUBCOMMANDS[sub];
  if (!entry) {
    return { ok: false, result: { error: `unknown subcommand "${sub}"`, valid: Object.keys(SUBCOMMANDS) }, ts };
  }

  try {
    return {
      ok: true,
      result: {
        verb: `web.${sub}`,
        mcpTool: entry.tool,
        args,
        risk: entry.risk,
        routed: true
      },
      ts
    };
  } catch (e) {
    return { ok: false, result: { error: e.message, verb: `web.${sub}` }, ts };
  }
}

module.exports = web;
module.exports.subcommands = SUBCOMMANDS;
if (require.main === module) web(process.argv.slice(2).join(' ')).then(r => console.log(JSON.stringify(r, null, 2)));
