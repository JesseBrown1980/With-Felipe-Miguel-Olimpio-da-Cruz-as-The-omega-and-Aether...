// cube: ix-noun-firmware | IX-733 | D15 DEVICE (prime 47) | touches 7,11,21,27,28
// gates: hookwall | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-noun-firmware',
  primaryCatalog: { D: 15, name: 'DEVICE', prime: 47 },
  touches: [7, 11, 21, 27, 28],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':      'parent-runtime',
    'ix-verb-firmware-read':'downstream-verb',
    'ix-verb-firmware-write':'downstream-verb',
    'ix-verb-me-neutralize':'downstream-verb',
    'ix-noun-falcon':       'sibling-state-reader'
  },
  payload: {
    kind: 'noun',
    source: '~/sovereignty/ix/nouns/firmware.js',
    role: 'reads Intel Boot Guard MSR 0x13A, ME /dev/mei0, SPI USB root, EFI Secure Boot',
    linux_only: true,
    probes: {
      boot_guard:  { dev: '/dev/cpu/0/msr', tool: 'rdmsr 0x13A' },
      me:          { dev: '/dev/mei0' },
      spi_usb:     { env: 'ASOLARIA_SOVEREIGNTY_ROOT' },
      secure_boot: { path: '/sys/firmware/efi/efivars' }
    },
    returns: { ok: 'bool', boot_guard: 'obj', me: 'obj', spi: 'obj', secure_boot: 'obj', ts: 'number' }
  },
  translate: {
    human:  'IX noun: firmware — reads Boot Guard, Intel ME, SPI USB, Secure Boot (bare-metal Linux).',
    agent:  '(falcon, lifecycle.read_state, local.hardware, 2, chip, hookwall, executing, [observed_on], single, IX, log, persistent, falcon-gw, light)',
    device: 'rdmsr 0x13A ; stat /dev/mei0 ; readdir $ASOLARIA_SOVEREIGNTY_ROOT ; stat /sys/firmware/efi/efivars'
  }
};
