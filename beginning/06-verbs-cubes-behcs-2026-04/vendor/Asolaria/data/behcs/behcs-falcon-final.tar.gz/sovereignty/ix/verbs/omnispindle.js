// IX verb: omnispindle | PID: asolaria | Profile: asolaria | IX-510
// Omnispindle surface — 3 verbs: omnispindle.status, omnispindle.dispatch, omnispindle.broadcast
// Wraps the 5-lane Omnispindle agent spawner API
// Lanes: helm, vector, rook, forge, falcon (from Asolaria src/omnispindle.js)

const ASO_BASE = process.env.ASO_URL || 'http://localhost:4781';
const OMNISPINDLE_API = `${ASO_BASE}/api/omnispindle`;

const VALID_LANES = ['helm', 'vector', 'rook', 'forge', 'falcon'];

const SUBCOMMANDS = {
  status:    { endpoint: '/status',    method: 'GET',  risk: 0, description: 'Get all lane statuses and health' },
  dispatch:  { endpoint: '/dispatch',  method: 'POST', risk: 4, description: 'Dispatch task to a specific lane' },
  broadcast: { endpoint: '/broadcast', method: 'POST', risk: 4, description: 'Broadcast message to all active lanes' },
};

/**
 * @param {string} command — format: "subcommand [args]"
 *   e.g. "status"
 *   e.g. "dispatch {\"lane\":\"vector\",\"task\":\"analyze repo\"}"
 *   e.g. "broadcast {\"message\":\"heartbeat check\"}"
 * @returns {Promise<{ok: boolean, result: any, ts: number}>}
 */
async function omnispindle(command) {
  const ts = Date.now();
  if (!command) {
    return {
      ok: false,
      result: {
        error: 'usage: omnispindle.status|omnispindle.dispatch|omnispindle.broadcast [payload]',
        subcommands: Object.keys(SUBCOMMANDS),
        lanes: VALID_LANES
      },
      ts
    };
  }

  const parts = command.trim().split(/\s+/);
  let sub = parts[0].replace(/^omnispindle\./, '');
  const rawArgs = parts.slice(1).join(' ');

  const entry = SUBCOMMANDS[sub];
  if (!entry) {
    return { ok: false, result: { error: `unknown subcommand "${sub}"`, valid: Object.keys(SUBCOMMANDS) }, ts };
  }

  let payload = {};
  if (rawArgs) {
    try {
      payload = JSON.parse(rawArgs);
    } catch (_) {
      // For dispatch, treat bare string as task for default lane (vector)
      if (sub === 'dispatch') {
        payload = { lane: 'vector', task: rawArgs };
      } else if (sub === 'broadcast') {
        payload = { message: rawArgs };
      } else {
        payload = { query: rawArgs };
      }
    }
  }

  // Validate lane for dispatch
  if (sub === 'dispatch' && payload.lane && !VALID_LANES.includes(payload.lane)) {
    return { ok: false, result: { error: `invalid lane "${payload.lane}"`, valid: VALID_LANES }, ts };
  }

  try {
    const url = `${OMNISPINDLE_API}${entry.endpoint}`;
    const headers = { 'Content-Type': 'application/json' };

    // Add gateway token if available
    const gatewayTokenPath = process.env.ASO_GATEWAY_TOKEN;
    if (gatewayTokenPath) {
      try {
        const fs = require('fs');
        const token = fs.readFileSync(gatewayTokenPath, 'utf8').trim();
        headers['Authorization'] = `Bearer ${token}`;
      } catch (_) { /* token file missing, proceed without */ }
    }

    const fetchOpts = { method: entry.method, headers };
    if (entry.method === 'POST') {
      fetchOpts.body = JSON.stringify(payload);
    }

    const res = await fetch(url, fetchOpts);
    const data = await res.json();

    return {
      ok: res.ok,
      result: {
        verb: `omnispindle.${sub}`,
        endpoint: url,
        risk: entry.risk,
        lanes: VALID_LANES,
        response: data
      },
      ts
    };
  } catch (e) {
    return { ok: false, result: { error: e.message, verb: `omnispindle.${sub}` }, ts };
  }
}

module.exports = omnispindle;
module.exports.subcommands = SUBCOMMANDS;
module.exports.VALID_LANES = VALID_LANES;
if (require.main === module) omnispindle(process.argv.slice(2).join(' ')).then(r => console.log(JSON.stringify(r, null, 2)));
