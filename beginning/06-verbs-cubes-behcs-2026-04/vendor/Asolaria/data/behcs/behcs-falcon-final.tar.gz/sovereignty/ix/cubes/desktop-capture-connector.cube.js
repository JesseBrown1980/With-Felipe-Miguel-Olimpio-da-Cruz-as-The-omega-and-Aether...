// cube: desktop-capture-connector | IX-828 | D13 SURFACE (41) | touches 13,25,36,37
// gates: hookwall | waves: pulse | federation: asolaria-mirror-bridge
// archaeology: ~/liris-test/Asolaria/src/connectors/desktopCaptureConnector.js (7 KB, Feb 22)
export const CUBE = {
  id: 'desktop-capture-connector',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [13, 25, 36, 37],
  gates: ['hookwall'],
  waves: ['pulse'],
  connectors: {
    'desktop-display-connector': 'display-peer',
    'desktop-control-connector': 'control-peer',
    'phone-mirror-connector':    'cross-surface-peer',
    'behcs-mirror-bridge':       'bridge-parent',
    'agent-gaia':                'laptop-host'
  },
  payload: {
    kind: 'js-coordinator-archaeology',
    source: '~/liris-test/Asolaria/src/connectors/desktopCaptureConnector.js',
    runtime_host: 'laptop-node (spawns PowerShell capture)',
    role: 'Desktop screenshot + window dumps, multi-monitor aware',
    outputs: ['png per monitor', 'window-list json', 'layout descriptor'],
    environment_model: 'windows-desktop-multi-display'
  },
  translate: {
    human:  'Desktop capture connector — grabs screenshots and window dumps across all monitors.',
    agent:  '(asolaria, sensor.capture, laptop.screen, 2, runtime, hookwall, *, [gaia], pulse, IX-828, log, session, asolaria-gw, light)',
    device: 'powershell.exe [System.Drawing.Bitmap]::new(..) + EnumWindows → png+json'
  }
};
