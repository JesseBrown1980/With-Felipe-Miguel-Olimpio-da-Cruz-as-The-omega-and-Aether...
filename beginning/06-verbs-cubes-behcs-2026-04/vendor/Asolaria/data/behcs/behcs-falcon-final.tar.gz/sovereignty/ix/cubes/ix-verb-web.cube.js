// cube: ix-verb-web | IX-742 | D2 VERB (prime 3) | touches 3,4,6,10,11,41
// gates: hookwall+gnn (risk 3) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-web',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [3, 4, 6, 10, 11, 41],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':    'parent-runtime',
    'ix-verb-mcp-slack':  'sibling-verb',
    'ix-verb-mcp-linear': 'sibling-verb',
    'ix-verb-antigravity':'sibling-verb',
    'translator-human':   'tuple-projector'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/web.js',
    role: 'router: web.search | web.fetch → WebSearch / WebFetch MCP tools',
    risk: 3,
    subcommands: {
      search: { tool: 'WebSearch', risk: 1 },
      fetch:  { tool: 'WebFetch',  risk: 3 }
    }
  },
  translate: {
    human:  'IX verb: web — routes web.{search,fetch} to WebSearch / WebFetch.',
    agent:  '(falcon, query.search, cloud.external, 3, cloud, hookwall+gnn, executing, [feeds], single, IX, log, session, falcon-gw, light)',
    device: 'route subverb → WebSearch | WebFetch'
  }
};
