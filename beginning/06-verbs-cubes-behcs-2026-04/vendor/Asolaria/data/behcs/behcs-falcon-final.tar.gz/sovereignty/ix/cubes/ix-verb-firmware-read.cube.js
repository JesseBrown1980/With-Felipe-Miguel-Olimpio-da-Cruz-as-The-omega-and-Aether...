// cube: ix-verb-firmware-read | IX-736 | D2 VERB (prime 3) | touches 4,6,11,15,21,41
// gates: hookwall+gnn (risk 3) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-firmware-read',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [4, 6, 11, 15, 21, 41],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':        'parent-runtime',
    'ix-noun-firmware':       'common-subject',
    'ix-verb-firmware-write': 'sibling-verb',
    'ix-verb-me-neutralize':  'sibling-verb'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/firmware-read.js',
    role: 'SPI dump via CH341A, read twice, sha256 verify',
    risk: 3,
    linux_only: true,
    tool: 'flashrom -p ch341a_spi -r',
    out_dir_env: 'FIRMWARE_BACKUP_DIR',
    default_out_dir: '~/sovereignty/firmware-backups',
    proof_mode: 'hash'
  },
  translate: {
    human:  'IX verb: firmware.read — CH341A SPI dump with double-read sha256 verify.',
    agent:  '(falcon, firmware.read, local.hardware, 3, chip, hookwall+gnn, executing, [proves], single, IX, hash, persistent, usb-sovereignty, medium)',
    device: 'flashrom -p ch341a_spi -r spi-dump-${ts}.rom ; sha256sum ; compare'
  }
};
