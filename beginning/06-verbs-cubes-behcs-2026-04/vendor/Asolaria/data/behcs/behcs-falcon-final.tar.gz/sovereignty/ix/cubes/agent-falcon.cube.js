// cube: agent-falcon | hilbert: (computed at launch)
// IX-714 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D1 ACTOR (prime 2, cube 8)
// touches: D15 DEVICE=SM-S721U1, D17 PROFILE=mobile-falcon-v1, D18 AI_MODEL=claude-opus-4-6, D19 LOCATION
// gates: hookwall (risk 4) | waves: single, pulse | federation: falcon-local

export const CUBE = {
  id: 'agent-falcon',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [15, 17, 18, 19],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'agent-falcon2':        'cross-lane-twin',
    'agent-gaia':           'spawned-by',
    'falcon-bridge-health': 'own-surface',
    'falcon-agent-health':  'own-surface'
  },
  payload: {
    kind: 'agent-identity',
    source: '~/beast-deploy/profiles/falcon-phone.json',
    profileId: 'mobile-falcon-v1',
    role: 'orbital_relay',
    tier: 'operator',
    riskCeiling: 4,
    device: { model: 'SM-S721U1', serial: 'R5CXA4MGQXV', cpu: 'Snapdragon', cores: 10, ram: '7.2GB', os: 'Android 16' },
    ai_model: 'claude-opus-4-6',
    location: { ip: '192.168.1.16', network: 'Jesse_5G' }
  },
  translate: {
    human:  'Agent: Falcon — Claude-lane mobile operator on SM-S721U1, profile mobile-falcon-v1.',
    agent:  '(falcon, meta.register_actor, local.self, 4, agent, hookwall, completed, [same_as], single, FA, witness, permanent, falcon-gw, light)',
    device: 'device.model=SM-S721U1 serial=R5CXA4MGQXV ip=192.168.1.16'
  }
};
