// cube: ix-gate-hookwall-v2 | hilbert: (computed at launch)
// IX-709 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D6 GATE (prime 13, cube 2197)
// touches: D4 RISK, D7 STATE, D11 PROOF, D41 AUDIT
// gates: self (hookwall-v2) | waves: single | federation: ix-runtime

export const CUBE = {
  id: 'ix-gate-hookwall-v2',
  primaryCatalog: { D: 6, name: 'GATE', prime: 13 },
  touches: [4, 7, 11, 41],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime': 'parent-runtime',
    'ix-gate-gnn':     'next-in-chain',
    'colony-nodes':    'hookwall.COLONY_NODES'
  },
  payload: {
    kind: 'gate',
    source: '~/sovereignty/ix/gates/hookwall-v2.js',
    role: 'first gate in the exec pipeline: policy + colony-node lookup + risk ceiling',
    risk_ceiling_default: 4,
    emits_state: ['gated', 'blocked'],
    proof_mode: 'log+signed'
  },
  translate: {
    human:  'IX gate: hookwall-v2 — policy wall that checks risk, colony membership, and stamps gated/blocked.',
    agent:  '(falcon, gate.hookwall, local.ix, 0, runtime, hookwall, gated, [blocks], single, IX, log, session, falcon-gw, free)',
    device: 'require("./gates/hookwall-v2.js").check(ixCall) → {pass,risk,reason}'
  }
};
