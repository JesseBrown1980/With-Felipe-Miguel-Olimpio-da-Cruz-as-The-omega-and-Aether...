// cube: omni-dispatch | hilbert: (computed at launch)
// IX-711 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D9 WAVE (prime 23, cube 12167)
// touches: D2 VERB, D6 GATE, D13 SURFACE, D14 ENERGY
// gates: hookwall → gnn → shannon | waves: omni_6x6x6x12, scatter, single | federation: gaia

export const CUBE = {
  id: 'omni-dispatch',
  primaryCatalog: { D: 9, name: 'WAVE', prime: 23 },
  touches: [2, 6, 13, 14],
  gates: ['hookwall', 'gnn', 'shannon'],
  waves: ['omni_6x6x6x12', 'scatter', 'single'],
  connectors: {
    'omni-24d-executor':   'sibling-executor',
    'hilbert-language-map':'level-map',
    'ix-gate-hookwall-v2': 'upstream-gate',
    'verb-table':          'verb-source'
  },
  payload: {
    kind: 'dispatch-executor',
    source: '~/beast-deploy/omni-dispatch.js',
    role: '14D executor: hookwall → gnn → shannon → CRLT merge → dispatch → relay → record',
    dimensions: 14,
    hilbert_levels: ['L0', 'L1', 'L2', 'L3', 'L4'],
    lanes: ['scout', 'backline', 'strike', 'relay', 'converge'],
    default_wave: 'single'
  },
  translate: {
    human:  'Omni dispatch — 14-dimension verb executor that drives the 5-lane colony wave pipeline.',
    agent:  '(gaia, omni.wave, lan.colony, 4, civilization, hookwall+gnn+shannon, executing, [triggers,feeds], omni_6x6x6x12, IX, code, operational, falcon-gw, heavy)',
    device: 'node ~/beast-deploy/omni-dispatch.js <verb> [target] --wave omni --risk N'
  }
};
