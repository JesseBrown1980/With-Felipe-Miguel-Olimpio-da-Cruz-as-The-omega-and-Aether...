// cube: ix-gate-shannon | IX-749 | D6 GATE (prime 13) | touches 4,7,11,41
// gates: shannon | waves: single | federation: shannon-4791
export const CUBE = {
  id: 'ix-gate-shannon',
  primaryCatalog: { D: 6, name: 'GATE', prime: 13 },
  touches: [4, 7, 11, 41],
  gates: ['shannon'],
  waves: ['single'],
  connectors: {
    'ix-gate-gnn':       'sibling-previous',
    'ix-exec-runtime':   'parent-runtime',
    'agent-shannon':     'driven-by',
    'shannon-pentest':   'http://localhost:4791/security/shannon/scan'
  },
  payload: {
    kind: 'gate',
    source: '~/sovereignty/ix/gates/shannon.js',
    role: 'pen-test gate — fail-closed on cross-domain / high-risk verbs',
    scan_url: 'http://localhost:4791/security/shannon/scan',
    timeout_ms: 5000,
    skip_below_risk: 3,
    full_mode_risk: 7,
    fail_closed_risk: 5,
    emits_state: ['gated', 'blocked', 'degraded'],
    proof_mode: 'scan+flags'
  },
  translate: {
    human:  'IX gate: shannon — pen-test scan, fail-closed above risk 5.',
    agent:  '(shannon, gate.shannon_scan, remote.4791, 7, runtime, shannon, gated, [blocks], single, SH, scan-log, session, falcon-gw, medium)',
    device: 'POST http://localhost:4791/security/shannon/scan → {blocked,flags,score}'
  }
};
