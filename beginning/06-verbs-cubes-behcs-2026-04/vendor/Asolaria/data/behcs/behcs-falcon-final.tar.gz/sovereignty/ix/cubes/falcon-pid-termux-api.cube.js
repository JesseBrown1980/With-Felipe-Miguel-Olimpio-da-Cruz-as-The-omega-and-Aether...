// cube: falcon-pid-termux-api | IX-872 | D16 PID (53) | touches 1,15,21,36
// gates: hookwall | waves: single | federation: falcon-live-runtime
export const CUBE = {
  id: 'falcon-pid-termux-api',
  primaryCatalog: { D: 16, name: 'PID', prime: 53 },
  touches: [1, 15, 21, 36],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'agent-falcon':                'owner',
    'falcon-sensor-camera-back':   'bridges-camera',
    'falcon-sensor-camera-front':  'bridges-camera',
    'falcon-sensor-accelerometer': 'bridges-sensor',
    'falcon-sensor-environment':   'bridges-sensor',
    'falcon-pid-node-agent':       'called-by'
  },
  payload: {
    kind: 'live-pid', process: 'com.termux.api', pid_observed: 5518,
    cmdline: 'com.termux.api (Android service)',
    role: 'Termux:API service — bridges Android APIs (camera, sensors, clipboard, TTS, notification, SMS) to Termux shell commands',
    api_count: 84,
    commands_prefix: 'termux-*'
  },
  translate: {
    human:  'Termux:API Android service — 84 termux-* commands bridging Android sensors and APIs to the shell.',
    agent:  '(falcon, lifecycle.process, local.termux-api-service, 0, os, hookwall, running, [84-termux-apis], single, FA, log, persistent, falcon-gw, free)',
    device: 'pid=5518 exec=com.termux.api android-service bridges=84'
  }
};
