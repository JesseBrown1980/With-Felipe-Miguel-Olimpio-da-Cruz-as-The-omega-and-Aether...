// cube: ix-chain-fabricate | IX-755 | D8 CHAIN (prime 19) | touches 1,2,20,24
// gates: hookwall+gnn | waves: compose | federation: asolaria-index
export const CUBE = {
  id: 'ix-chain-fabricate',
  primaryCatalog: { D: 8, name: 'CHAIN', prime: 19 },
  touches: [1, 2, 20, 24],
  gates: ['hookwall', 'gnn'],
  waves: ['compose'],
  connectors: {
    'ix-chain-skill-extract': 'feeds-from',
    'ix-chain-review':        'feeds-into',
    'ix-chain-link':          'phase-3-compose',
    'ix-gate-gnn':            'construction-predictor'
  },
  payload: {
    kind: 'chain',
    source: '~/sovereignty/ix/chains/fabricate.js',
    role: 'MLC composition: given a goal, compose existing skills/tools/patterns into a new chain proposal',
    ix_phase: 'IX-121+IX-492+IX-518',
    pid: 'build-forge-v1',
    mlc: 'meta-learning-for-compositionality',
    emits: ['proposal', 'chainSteps', 'constraints']
  },
  translate: {
    human:  'IX chain: fabricate — MLC unit that composes skills+tools into new chain proposals.',
    agent:  '(forge, chain.fabricate, local.index, 4, runtime, hookwall+gnn, executing, [composes], compose, MLC, log, session, falcon-gw, low)',
    device: 'require("./chains/fabricate.js")(goal) → {proposal,components,constraints}'
  }
};
