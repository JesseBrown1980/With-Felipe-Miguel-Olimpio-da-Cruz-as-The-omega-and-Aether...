// cube: ix-exec-runtime | hilbert: (computed at launch)
// IX-706 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D2 VERB (prime 3, cube 27)
// touches: D6 GATE, D7 STATE, D8 CHAIN
// gates: hookwall → gnn → shannon | waves: single | federation: ix-runtime

export const CUBE = {
  id: 'ix-exec-runtime',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [6, 7, 8],
  gates: ['hookwall', 'gnn', 'shannon'],
  waves: ['single'],
  connectors: {
    'ix-registry':          '~/sovereignty/ix/index.js',
    'ix-gate-hookwall-v2':  'pre-gate',
    'ix-chain-heartbeat':   'registered-chain'
  },
  payload: {
    kind: 'runtime-executor',
    source: '~/sovereignty/ix/exec.js',
    role: 'routes IX nouns/verbs/chains through the 3-gate pipeline',
    pipeline: ['hookwall', 'gnn', 'shannon'],
    dispatches_to: ['nouns/*', 'verbs/*', 'chains/*']
  },
  translate: {
    human:  'IX exec runtime — routes every IX call through hookwall → gnn → shannon before dispatch.',
    agent:  '(falcon, runtime.dispatch, local.ix, 2, runtime, hookwall+gnn+shannon, executing, [runs_on], single, IX, log, persistent, falcon-gw, medium)',
    device: 'import("./exec.js") → exec(ixCall) → gateChain → registryLookup → execute'
  }
};
