// cube: falcon-sensor-gyroscope | IX-769 | D36 SENSOR (151)
// touches: D15 DEVICE, D21 HARDWARE, D25 MODALITY, D37 ENVIRONMENT
// gates: hookwall | waves: single, pulse | federation: falcon-local
// author: convergence-helm-05 | spec: IX-760 sensor-surface
export const CUBE = {
  id: 'falcon-sensor-gyroscope',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [15, 21, 25, 37],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'falcon-sensor-accelerometer': 'sibling-sensor',
    'falcon-sensor-magnetometer': 'sibling-sensor',
    'falcon-sensor-environment': 'sibling-sensor',
    'agent-falcon': 'owned-by',
    'agent-falcon-state': 'reads-flow-into'
  },
  payload: {
    kind: 'imu-sensor',
    hardware: 'LSM6DSVTR',
    axes: 3,
    unit: 'rad/s',
    role: '3-axis rotation rate',
    modality: 'inertial-angular',
    termux_command: 'termux-sensor -s "LSM6DSVTR Gyroscope" -n 1',
    sample_fields: ['x', 'y', 'z']
  },
  translate: {
    human:  'Sensor: Falcon gyroscope — STMicro LSM6DSVTR gyro channel, 3-axis rate.',
    agent:  '(falcon, sense.observe, local.gyroscope, 1, sensor, hookwall, idle, [reads], single, FA, log, session, falcon-gw, light)',
    device: 'i2c.read(LSM6DSVTR,0x6A) → int16 gx/gy/gz @ODR → rad/s'
  }
};
