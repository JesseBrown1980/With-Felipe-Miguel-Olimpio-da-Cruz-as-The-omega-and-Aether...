// cube: doctrine-local-models | IX-817 | D35 MEMORY (149) | touches 1,10,15,18,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-local-models',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 15, 18, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-env-status': 'sibling-doctrine',
    'doctrine-falcon-root': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_local_models.md',
    description: 'Trixie/Debora is Debian Trixie proot-distro on Falcon — one thing, not two.'
  },
  translate: {
    human:  'Doctrine: local models — Trixie/Debora = Debian proot-distro on Falcon.',
    agent:  '(falcon, meta.recall, doctrine.local-models, 1, os, hookwall, completed, [same_as], single, IX, log, permanent, falcon-gw, free, persistent, project_local_models.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_local_models.md', 'utf8') → utf8 markdown"
  }
};
