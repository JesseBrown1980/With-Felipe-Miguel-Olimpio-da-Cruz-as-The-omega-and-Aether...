// cube: translator-device | IX-704 | D22 TRANSLATION (79) | touches 1,2,10,13,15,18,21,25,26
// gates: hookwall | waves: single, relay, broadcast | role: tuple → syscall/hardware
function translate(tuple, f = 'device') {
  const t = Array.isArray(tuple) ? tuple : String(tuple).replace(/^\(|\)$/g,'').split(/\s*,\s*/);
  const [a,v,tg,,,,,,,,,,sf] = t;
  const V = String(v||'noop').toLowerCase(); const S = String(sf||'falcon-gw').toLowerCase();
  let line;
  if (/check_health|probe/.test(V)) line = `tcp.connect(127.0.0.1:4799) → GET /health → json (${a}@${S})`;
  else if (/read|sense/.test(V))    line = `ioctl(/dev/${tg||'sensor'}, READ) → bytes (surface=${S})`;
  else if (/write|send|dispatch/.test(V)) line = `write(fd.${tg||'out'}, payload) → ack (surface=${S})`;
  else if (/translate/.test(V))     line = `cpu.call(fn.translate, tuple) → utf8 (surface=${S})`;
  else line = `syscall(${V}, ${tg||'-'}) → status (surface=${S}, actor=${a||'-'})`;
  return f === 'device' ? line : { line };
}
translate.human  = 'Translator: 24-tuple → syscall/hardware line.';
translate.agent  = '(falcon, translate.tuple_to_device, local.syscall, 0, runtime, hookwall, *, [], single, IX, log, session, falcon-gw, free)';
translate.device = 'fn.translate(tuple) → "syscall(...) → status" utf8';
export const CUBE = {
  id: 'translator-device',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [1, 2, 10, 13, 15, 18, 21, 25, 26],
  gates: ['hookwall'],
  waves: ['single', 'relay', 'broadcast'],
  connectors: { 'translator-human': 'sibling-translator', 'translator-agent': 'sibling-translator', 'falcon-agent-health': 'example-source' },
  payload: { kind: 'translator', input: { shape: 'omni-24-tuple' }, output: { shape: 'syscall-or-hw-line', modality: 'code', encoding: 'utf8' } },
  translate
};
