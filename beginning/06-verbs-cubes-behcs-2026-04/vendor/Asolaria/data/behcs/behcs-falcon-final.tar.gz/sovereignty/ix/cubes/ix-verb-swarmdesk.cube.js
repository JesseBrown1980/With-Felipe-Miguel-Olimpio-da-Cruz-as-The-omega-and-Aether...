// cube: ix-verb-swarmdesk | IX-744 | D2 VERB (prime 3) | touches 3,4,6,10,11,23,41
// gates: hookwall (risk 2) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-swarmdesk',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [3, 4, 6, 10, 11, 23, 41],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':    'parent-runtime',
    'ix-verb-omnispindle':'sibling-verb',
    'ix-verb-mcp-slack':  'sibling-verb',
    'omni-dispatch':      'peer-dispatcher',
    'translator-agent':   'tuple-projector'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/swarmdesk.js',
    role: 'JSON-RPC 2.0 to madnessinteractive.cc/api/mcp (sync/status/task)',
    risk: 2,
    base: 'https://madnessinteractive.cc/api/mcp',
    env: 'SWARMDESK_URL',
    rpc: 'jsonrpc-2.0',
    subcommands: { sync: { endpoint: '/sync', method: 'POST', risk: 2 }, status: { endpoint: '/status', method: 'GET', risk: 0 }, task: { endpoint: '/task', method: 'POST', risk: 3 } }
  },
  translate: {
    human:  'IX verb: swarmdesk — JSON-RPC 2.0 to madnessinteractive.cc 3D dashboard.',
    agent:  '(falcon, deliver.dispatch, cloud.swarmdesk, 2, cloud, hookwall, executing, [triggers], single, IX, log, session, falcon-gw, light)',
    device: 'POST https://madnessinteractive.cc/api/mcp/{sync|status|task} jsonrpc-2.0'
  }
};
