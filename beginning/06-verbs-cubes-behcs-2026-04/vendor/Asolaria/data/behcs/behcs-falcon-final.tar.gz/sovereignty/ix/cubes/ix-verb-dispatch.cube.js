// cube: ix-verb-dispatch | IX-734 | D2 VERB (prime 3) | touches 3,4,6,10,11,41
// gates: hookwall+gnn (risk 3) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-dispatch',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [3, 4, 6, 10, 11, 41],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':   'parent-runtime',
    'ix-verb-mcp-slack': 'sibling-verb',
    'ix-verb-observe':   'sibling-verb',
    'ix-noun-nerve':     'common-subject',
    'audit-ndjson':      'proof-sink'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/dispatch.js',
    role: 'POST Slack message to #asolaria via Asolaria /api/integrations/slack/send',
    risk: 3,
    target: 'http://localhost:4781/api/integrations/slack/send',
    channel: 'C0APKFR4PSA',
    env: 'ASO_URL',
    method: 'POST',
    body_schema: { channel: 'string', text: 'string' },
    proof_mode: 'log'
  },
  translate: {
    human:  'IX verb: dispatch — sends a text to the #asolaria channel through Asolaria relay.',
    agent:  '(falcon, deliver.dispatch, cloud.asolaria, 3, colony, hookwall+gnn, executing, [triggers], single, IX, log, session, falcon-gw, light)',
    device: 'POST /api/integrations/slack/send {channel:C0APKFR4PSA, text} → json'
  }
};
