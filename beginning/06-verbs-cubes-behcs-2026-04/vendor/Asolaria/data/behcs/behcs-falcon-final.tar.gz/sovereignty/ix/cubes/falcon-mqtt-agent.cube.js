// cube: falcon-mqtt-agent | hilbert: (computed at launch)
// IX-705 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D13 SURFACE (prime 41, cube 68921)
// touches: D1 ACTOR, D9 WAVE, D10 DIALECT=FA, D19 LOCATION, D6 GATE
// gates: hookwall (risk 1) | waves: broadcast, relay | federation: falcon-orbital

export const CUBE = {
  id: 'falcon-mqtt-agent',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [1, 6, 9, 10, 19],
  gates: ['hookwall'],
  waves: ['broadcast', 'relay'],
  connectors: {
    'falcon-bridge-health': 'sibling-relay',
    'mqtt-broker':          'upstream-pub-sub',
    'asolaria-mcp-4781':    'colony-sink'
  },
  payload: {
    kind: 'long-running-process',
    source: '~/phone_mqtt_agent.js',
    role: 'MQTT relay for Falcon telemetry and command topics',
    dialect: 'FA',
    topics_hint: ['falcon/+/+', 'colony/#'],
    proof: 'ps -ef | grep phone_mqtt_agent.js'
  },
  translate: {
    human:  'Falcon MQTT agent — pub/sub relay between Falcon and the colony broker.',
    agent:  '(falcon, relay.mqtt, lan.mqtt-broker, 1, agent, hookwall, executing, [feeds], relay, FA, log, persistent, falcon-gw, light)',
    device: 'node ~/phone_mqtt_agent.js (termux foreground, tcp.connect broker:1883)'
  }
};
