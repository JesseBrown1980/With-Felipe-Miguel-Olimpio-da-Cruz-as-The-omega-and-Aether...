// cube: falcon-pid-behcs-cron | IX-868 | D16 PID (53) | touches 1,5,20,44,45
// gates: hookwall | waves: pulse | federation: falcon-live-runtime
export const CUBE = {
  id: 'falcon-pid-behcs-cron',
  primaryCatalog: { D: 16, name: 'PID', prime: 53 },
  touches: [1, 5, 20, 44, 45],
  gates: ['hookwall'],
  waves: ['pulse'],
  connectors: {
    'agent-falcon':              'owner',
    'behcs-heartbeat-lx489':     'implements',
    'falcon-pid-falcon-bridge':  'uses-relay',
    'falcon-pid-node-agent':     'sibling',
    'falcon-bridge-health':      'targets'
  },
  payload: {
    kind: 'live-pid', source: '~/asolaria/bin/behcs-cron.js', pid_observed: 21158,
    cmdline: 'node /data/data/com.termux/files/home/asolaria/bin/behcs-cron.js',
    schedules: { heartbeat_ms: 30000, health_ms: 60000, gc_ms: 300000 },
    lx_node: 'LX-489',
    emits_tuples_to: 'http://127.0.0.1:4800/relay (forwards to acer:4947/behcs/send)',
    logs_to: '~/sovereignty/ix/state/behcs-cron.log', health_ndjson: '~/sovereignty/ix/state/acer-bus-health.ndjson'
  },
  translate: {
    human:  'BEHCS cron scheduler daemon — 30s LX-489 heartbeat, 60s acer-bus health, 300s GC rotation.',
    agent:  '(falcon, lifecycle.process, local.behcs-cron, 0, runtime, hookwall, running, [LX-489,triad-mesh-active], pulse, FA, log, persistent, falcon-gw, free)',
    device: 'pid=21158 exec=node argv=~/asolaria/bin/behcs-cron.js setInterval([30s,60s,300s])'
  }
};
