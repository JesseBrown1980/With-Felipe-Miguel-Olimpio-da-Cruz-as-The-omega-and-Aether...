// cube: ix-noun-nerve | IX-731 | D36 SENSOR (prime 151) | touches 7,11,20,36,41
// gates: hookwall | waves: pulse, single | federation: ix-runtime
export const CUBE = {
  id: 'ix-noun-nerve',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [7, 11, 20, 36, 41],
  gates: ['hookwall'],
  waves: ['pulse', 'single'],
  connectors: {
    'ix-exec-runtime':       'parent-runtime',
    'ix-noun-sovereignty':   'sibling-state-reader',
    'ix-noun-health':        'sibling-state-reader',
    'ix-verb-mcp-slack':     'downstream-verb',
    'ix-chain-heartbeat':    'periodic-pulse-peer'
  },
  payload: {
    kind: 'noun',
    source: '~/sovereignty/ix/nouns/nerve.js',
    role: 'reads Slack event listener status + poll count from Asolaria',
    remote_target: 'http://localhost:4781/api/integrations/slack/events/status',
    env: 'ASO_URL',
    returns: { ok: 'bool', running: 'bool', pollCount: 'number', ts: 'number' }
  },
  translate: {
    human:  'IX noun: nerve — reads Asolaria Slack-event listener running/pollCount.',
    agent:  '(falcon, lifecycle.read_state, cloud.asolaria, 1, colony, hookwall, executing, [observed_on], pulse, IX, log, session, falcon-gw, light)',
    device: 'tcp.connect(127.0.0.1:4781) [adb-reverse] → GET /api/integrations/slack/events/status → json'
  }
};
