// IX verb: me.neutralize | PID: asolaria | Profile: asolaria
// Applies me_cleaner HAP bit to SPI dump — RISK 9 (owner-only)
// Does NOT flash. Produces modified .rom for firmware.write
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

async function meNeutralize(dumpPath) {
  if (!dumpPath || !fs.existsSync(dumpPath)) {
    return { ok: false, reason: 'me.neutralize requires path to original SPI dump .rom', ts: Date.now() };
  }

  if (process.platform !== 'linux') {
    return { ok: false, reason: 'me.neutralize requires Linux with Python3', ts: Date.now() };
  }

  const outFile = dumpPath.replace('.rom', '-me-neutralized.rom');

  try {
    // Copy original (never modify the backup)
    fs.copyFileSync(dumpPath, outFile);

    // Check me_cleaner available
    execSync('which me_cleaner || python3 -c "import me_cleaner"', { timeout: 5000 });

    // Apply HAP bit + code removal (-S = soft disable + strip)
    const result = execSync(`me_cleaner -S "${outFile}" 2>&1`, { encoding: 'utf8', timeout: 60000 });

    const success = result.includes('Done') || result.includes('HAP');

    return {
      ok: success,
      original: dumpPath,
      modified: outFile,
      output: result.slice(0, 500),
      next_step: success ? `Run: node ix/exec.js firmware.write ${outFile}` : 'me_cleaner failed — check output',
      ts: Date.now()
    };
  } catch (e) {
    return { ok: false, reason: e.message, ts: Date.now() };
  }
}

module.exports = meNeutralize;
if (require.main === module) meNeutralize(process.argv[2]).then(r => console.log(JSON.stringify(r, null, 2)));
