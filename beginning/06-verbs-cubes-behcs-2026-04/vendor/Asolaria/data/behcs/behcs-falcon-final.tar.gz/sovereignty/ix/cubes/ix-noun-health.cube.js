// cube: ix-noun-health | hilbert: (computed at launch)
// IX-707 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D7 STATE (prime 17, cube 4913)
// touches: D13 SURFACE, D14 ENERGY
// gates: hookwall (risk 0) | waves: single | federation: ix-runtime

export const CUBE = {
  id: 'ix-noun-health',
  primaryCatalog: { D: 7, name: 'STATE', prime: 17 },
  touches: [13, 14],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':    'parent-runtime',
    'gaia-4781':          'remote-health-source',
    'falcon-agent-health':'local-counterpart'
  },
  payload: {
    kind: 'noun',
    source: '~/sovereignty/ix/nouns/health.js',
    role: 'GET colony health by querying remote fast-health endpoint',
    remote_target: 'http://<gaia>:4781/api/health/fast',
    note: 'NOTE: 4781 is Gaia-side. From Falcon this reverses via ADB tcp:4781.',
    returns: { ok: 'bool', ts: 'iso', nodes: 'array' }
  },
  translate: {
    human:  'IX noun: health — reads colony fast-health from Gaia (reversed via ADB on Falcon).',
    agent:  '(falcon, lifecycle.check_health, cloud.gaia, 1, colony, hookwall, executing, [observed_on], single, IX, log, session, falcon-gw, light)',
    device: 'tcp.connect(127.0.0.1:4781) [adb-reverse] → GET /api/health/fast → json'
  }
};
