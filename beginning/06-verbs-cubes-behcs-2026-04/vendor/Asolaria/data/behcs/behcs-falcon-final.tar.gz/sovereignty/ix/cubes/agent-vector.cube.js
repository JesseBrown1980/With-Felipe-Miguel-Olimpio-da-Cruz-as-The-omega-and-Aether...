// cube: agent-vector | IX-724 | D1 ACTOR (2) | touches 15,17,18,19,29 | gates: hookwall+gnn+shannon
export const CUBE = {
  id: 'agent-vector',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [15, 17, 18, 19, 29],
  gates: ['hookwall', 'gnn', 'shannon'],
  waves: ['single', 'broadcast'],
  connectors: { 'agent-gaia': 'spawned-by', 'hilbert-language-map': 'authors', 'omni-24d-executor': 'specifies', 'agent-helm': 'mesh-peer' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/vector.json',
    profileId: 'vector-v1', role: 'spec_authority', tier: 'super_admin', riskCeiling: 8,
    device: { hostname: 'DESKTOP-J99VCNH', cpu: 'Intel i5-8300H', ram: '16GB', os: 'Windows 11' },
    ai_model: 'claude-opus-4-6',
    location: { ip: '192.168.1.12', network: 'home_lan', machine: "Jesse's laptop", hilbert_level: 'L0' },
    notes: 'core spec agent; writes/validates language specs; OMNI-LANGUAGE-V3 owner',
    owns_spec: 'OMNI-LANGUAGE-V3',
    gate_chain: 'hookwall+gnn+shannon'
  },
  translate: {
    human:  'Agent: Vector — super-admin spec authority, owner of OMNI-LANGUAGE-V3.',
    agent:  '(vector, meta.register_actor, local.self, 8, civilization, hookwall+gnn+shannon, completed, [authors,supersedes], broadcast, IX, signed, foundational, falcon-gw, heavy)',
    device: 'hostname=DESKTOP-J99VCNH role=spec_authority profile=vector-v1'
  }
};
