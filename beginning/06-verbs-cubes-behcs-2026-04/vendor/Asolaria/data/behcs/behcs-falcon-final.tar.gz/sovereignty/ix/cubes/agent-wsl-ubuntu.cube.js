// cube: agent-wsl-ubuntu | IX-729 | D1 ACTOR (2) | touches 15,17,18,19,21 | gates: hookwall
export const CUBE = {
  id: 'agent-wsl-ubuntu',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [15, 17, 18, 19, 21],
  gates: ['hookwall'],
  waves: ['single', 'gather'],
  connectors: { 'agent-gaia': 'runs-under', 'agent-helm': 'mesh-peer', 'agent-shannon': 'mesh-peer' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/wsl-ubuntu.json',
    profileId: 'hypervisor-v1', role: 'hypervisor_compute', tier: 'operator', riskCeiling: 4,
    device: { hostname: 'DESKTOP-J99VCNH', cpu: 'Intel i5-8300H (shared)', cores: 8, ram: 'shared 16GB', os: 'Ubuntu WSL2', kernel: '6.6.87.2-microsoft-standard-WSL2', docker: true },
    ai_model: 'none',
    location: { ip: '172.18.254.86', network: 'hyper-v', hilbert_level: 'L1' },
    surface: { home: 'wsl', ports: [4796] },
    notes: 'WSL2 Ubuntu; Docker; Linux kernel; heavy compute',
    gate_chain: 'hookwall'
  },
  translate: {
    human:  'Agent: WSL-Ubuntu — operator-tier hypervisor compute, WSL2 Ubuntu with Docker for heavy Linux work.',
    agent:  '(wsl-ubuntu, meta.register_actor, local.self, 4, runtime, hookwall, executing, [runs_on,feeds], gather, IX, log, operational, wsl, heavy)',
    device: 'hostname=DESKTOP-J99VCNH os=Ubuntu-WSL2 ip=172.18.254.86 docker=true'
  }
};
