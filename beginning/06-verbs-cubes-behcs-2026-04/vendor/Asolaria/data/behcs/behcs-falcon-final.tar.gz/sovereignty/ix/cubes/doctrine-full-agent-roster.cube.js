// cube: doctrine-full-agent-roster | IX-810 | D35 MEMORY (149) | touches 1,10,16,17,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-full-agent-roster',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 16, 17, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-beast-deploy-profiles': 'sibling-doctrine',
    'doctrine-three-lanes': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_full_agent_roster.md',
    description: 'Full roster — all agents, tools, auth, and access channels across the colony.'
  },
  translate: {
    human:  'Doctrine: full agent and tool roster across the colony.',
    agent:  '(falcon, meta.recall, doctrine.full-agent-roster, 1, colony, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_full_agent_roster.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_full_agent_roster.md', 'utf8') → utf8 markdown"
  }
};
