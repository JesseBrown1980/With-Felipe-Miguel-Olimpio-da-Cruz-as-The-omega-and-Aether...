// cube: network-rmnet-mobile | IX-772 | D19 LOCATION (67) | touches 13,15,21,27,39
// gates: hookwall | waves: single | federation: falcon-local
export const CUBE = {
  id: 'network-rmnet-mobile',
  primaryCatalog: { D: 19, name: 'LOCATION', prime: 67 },
  touches: [13, 15, 21, 27, 39],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'network-loopback': 'sibling-iface',
    'network-wlan':     'sibling-iface',
    'agent-falcon':     'carries-traffic-for'
  },
  payload: {
    source: 'ifconfig v4-rmnet0',
    iface: 'v4-rmnet0', address: '192.0.0.4/32', state: 'UP,POINTOPOINT,RUNNING,NOARP', mtu: 1472,
    live: true, kind: 'CLAT (IPv4-in-IPv6) cellular uplink', carrier: 'Claro Brazil',
    jurisdiction: 'BR', upstream: 'Claro LTE/5G → public internet',
    note: 'v4-only stub, true uplink is IPv6; backup when wlan0 drops'
  },
  translate: {
    human:  'Cellular v4-rmnet0 192.0.0.4 — Claro Brazil CLAT, mobile uplink.',
    agent:  '(falcon, meta.observe, lan.cellular, 2, os, hookwall, completed, [sibling-iface], single, IX, live_probe, persistent, falcon-gw, light)',
    device: 'ifconfig v4-rmnet0 → inet 192.0.0.4 destination 192.0.0.4'
  }
};
