// cube: mcp-claude-gmail | IX-780 | D22 TRANSLATION (79) | touches 3,10,18,27
// gates: hookwall+gnn | waves: single | federation: falcon-local
export const CUBE = {
  id: 'mcp-claude-gmail',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [3, 10, 18, 27],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'mcp-claude-slack':     'sibling-mcp',
    'mcp-claude-linear':    'sibling-mcp',
    'ix-gate-hookwall-v2':  'pre-gate',
    'config-claude-settings': 'configured-by'
  },
  payload: {
    source: '~/.claude/settings.json permissions.allow',
    kind: 'cloud-mcp', provider: 'claude.ai', tool_prefix: 'mcp__claude_ai_Gmail__',
    capabilities: ['create_draft', 'read_message', 'read_thread', 'search_messages', 'list_drafts', 'list_labels', 'get_profile'],
    account: 'jesse@ (owner)',
    cipher: 'tls', risk: 3, ai_model: 'claude-opus-4-6',
    note: 'draft-first semantics; send requires owner confirmation'
  },
  translate: {
    human:  'Gmail MCP via claude.ai — draft/read/search/send owner mailbox.',
    agent:  '(falcon, mcp.gmail_draft, cloud.claude_ai, 3, cloud, hookwall+gnn, executing, [sibling-mcp], single, IX, log, session, falcon-gw, medium)',
    device: 'mcp__claude_ai_Gmail__gmail_create_draft({ to, subject, body })'
  }
};
