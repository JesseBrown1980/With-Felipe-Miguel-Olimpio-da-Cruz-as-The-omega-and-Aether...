// cube: ix-verb-me-neutralize | IX-738 | D2 VERB (prime 3) | touches 4,6,11,15,21,40,41,43
// gates: hookwall+gnn+shannon+sovereignty (risk 9) | waves: single | owner-only
export const CUBE = {
  id: 'ix-verb-me-neutralize',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [4, 6, 11, 15, 21, 40, 41, 43],
  gates: ['hookwall', 'gnn', 'shannon', 'sovereignty'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':        'parent-runtime',
    'ix-noun-firmware':       'common-subject',
    'ix-verb-firmware-read':  'prerequisite-verb',
    'ix-verb-firmware-write': 'downstream-verb',
    'ix-verb-shannon':        'gate-peer'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/me-neutralize.js',
    role: 'apply me_cleaner HAP bit + strip to SPI dump; emits -me-neutralized.rom',
    risk: 9,
    linux_only: true,
    owner_only: true,
    modifies_flash: false,
    tool: 'me_cleaner -S',
    input: 'spi-dump-*.rom',
    output_suffix: '-me-neutralized.rom',
    proof_mode: 'chain'
  },
  translate: {
    human:  'IX verb: me.neutralize — me_cleaner HAP strip on SPI dump, no flashing.',
    agent:  '(jesse, firmware.neutralize_me, local.hardware, 9, chip, hookwall+gnn+shannon+sovereignty, gated, [corrects,feeds], single, IX, chain, permanent, usb-sovereignty, medium)',
    device: 'cp ${dump} ${dump%.rom}-me-neutralized.rom ; me_cleaner -S ${out}'
  }
};
