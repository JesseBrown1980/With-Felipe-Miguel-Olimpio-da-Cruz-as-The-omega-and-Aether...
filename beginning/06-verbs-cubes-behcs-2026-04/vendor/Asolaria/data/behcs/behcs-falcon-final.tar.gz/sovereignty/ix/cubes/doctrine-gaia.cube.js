// cube: doctrine-gaia | IX-811 | D35 MEMORY (149) | touches 1,5,10,17,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-gaia',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 5, 10, 17, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'agent-gaia': 'documents',
    'doctrine-dasein': 'sibling-doctrine',
    'doctrine-liris': 'sibling-doctrine',
    'doctrine-laptop-acer': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_gaia.md',
    description: "Gaia super-admin on Jesse's laptop — runs outside world, commands Liris and Dasein."
  },
  translate: {
    human:  'Doctrine: Gaia — sovereign orchestrator on Jesse laptop.',
    agent:  '(falcon, meta.recall, doctrine.gaia, 1, civilization, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_gaia.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_gaia.md', 'utf8') → utf8 markdown"
  }
};
