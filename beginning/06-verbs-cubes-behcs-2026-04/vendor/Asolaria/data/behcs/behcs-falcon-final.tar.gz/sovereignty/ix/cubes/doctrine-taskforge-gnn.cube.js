// cube: doctrine-taskforge-gnn | IX-823 | D35 MEMORY (149) | touches 1,10,22,34,45
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-taskforge-gnn',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 22, 34, 45],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'taskforge-forge': 'documents',
    'doctrine-taskforge': 'sibling-doctrine',
    'doctrine-shannon-agent': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_taskforge_gnn.md',
    description: '~/taskforge Node module — candidate GNN to feed Shannon. Flagged for review.'
  },
  translate: {
    human:  'Doctrine: TaskForge GNN — candidate graph scorer for Shannon feed.',
    agent:  '(falcon, meta.recall, doctrine.taskforge-gnn, 1, app, hookwall, proposed, [feeds], single, IX, log, persistent, falcon-gw, free, persistent, project_taskforge_gnn.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_taskforge_gnn.md', 'utf8') → utf8 markdown"
  }
};
