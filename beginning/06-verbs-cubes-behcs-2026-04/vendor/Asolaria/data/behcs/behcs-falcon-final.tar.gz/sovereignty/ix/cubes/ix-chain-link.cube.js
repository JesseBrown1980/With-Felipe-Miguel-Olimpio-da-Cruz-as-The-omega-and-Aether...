// cube: ix-chain-link | IX-757 | D8 CHAIN (prime 19) | touches 1,2,20,22,23,24,35,44
// gates: hookwall+gnn+shannon | waves: master | federation: ix-runtime | MASTER CHAIN
export const CUBE = {
  id: 'ix-chain-link',
  primaryCatalog: { D: 8, name: 'CHAIN', prime: 19 },
  touches: [1, 2, 20, 22, 23, 24, 35, 44],
  gates: ['hookwall', 'gnn', 'shannon'],
  waves: ['master', 'cascade'],
  connectors: {
    'ix-chain-heartbeat':      'phase-1-sense',
    'ix-chain-mistake-learn':  'phase-2-learn',
    'ix-chain-skill-extract':  'phase-2-learn',
    'ix-chain-fabricate':      'phase-3-compose',
    'ix-chain-review':         'phase-4-review',
    'ix-chain-report':         'phase-5-report',
    'ix-chain-security-sweep': 'cross-link-immune',
    'ix-exec-runtime':         'parent-runtime'
  },
  payload: {
    kind: 'chain',
    source: '~/sovereignty/ix/chains/link.js',
    role: 'MASTER chain — sense→learn→compose→review→report nervous system',
    ix_phase: 'IX-060+IX-321+IX-491+IX-492+IX-518',
    pid: 'asolaria-core-v1',
    phases: ['sense','learn','compose','review','report'],
    flywheel: true
  },
  translate: {
    human:  'IX chain: link — the nervous system, runs all chains in sequence with cross-links.',
    agent:  '(asolaria, chain.link_master, local.ix, 6, runtime, hookwall+gnn+shannon, executing, [orchestrates], master, IX, signed, persistent, falcon-gw, massive)',
    device: 'require("./chains/link.js")(goal) → {phases,links,timeline}'
  }
};
