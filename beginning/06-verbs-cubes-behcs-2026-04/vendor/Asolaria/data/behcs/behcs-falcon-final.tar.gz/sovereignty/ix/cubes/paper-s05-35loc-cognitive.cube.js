// cube: paper-s05-35loc-cognitive | IX-839 | D35 MEMORY (prime 149) | touches 5,10,22,35,44
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s05-35loc-cognitive',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [5, 10, 22, 35, 44],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':        'belongs-to-paper',
    'behcs-mirror-bridge':         'contemporaneous-with',
    'paper-s04-47d-figurative':    'prev-section',
    'paper-s06-brown-hilbert-cube':'next-section',
    'doctrine-hilbert-codex':      'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_5_35loc_cognitive_architecture.md',
    section_number: 5,
    title: 'Thirty-Five Lines as Cognitive Architecture',
    word_count: 1953,
    ix: 'IX-839',
    in_paper_full: true
  },
  translate: {
    human:  'The 35-LOC cap per cube as cognitive rather than aesthetic, eight required fields, shadow workflow for safe edits.',
    agent:  '(falcon, meta.read_section, paper.s05, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_5_35loc_cognitive_architecture.md, utf8) → markdown'
  }
};
