// generate-cubes-manifest.js — build ~/sovereignty/ix/codex/cubes-manifest.json
// Reads every *.cube.js, dynamic-imports, extracts CUBE, writes to manifest.
// Run: node ~/sovereignty/ix/codex/generate-cubes-manifest.js
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { hilbertAddress } from './launch.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const CUBES_DIR = path.join(HERE, '..', 'cubes');
const MANIFEST = path.join(HERE, 'cubes-manifest.json');

const files = fs.readdirSync(CUBES_DIR).filter(f => f.endsWith('.cube.js'));
const cubes = {};
for (const f of files) {
  try {
    const mod = await import(path.join(CUBES_DIR, f));
    if (mod.CUBE) {
      cubes[mod.CUBE.id] = {
        ...mod.CUBE,
        _file: f,
        _hilbert: hilbertAddress(mod.CUBE.id),
        _loc: fs.readFileSync(path.join(CUBES_DIR, f), 'utf8').split('\n').length
      };
    }
  } catch (e) {
    console.error(`[manifest] ${f} failed: ${e.message}`);
  }
}

const manifest = {
  generated_at: new Date().toISOString(),
  spec: 'IX-851',
  cube_count: Object.keys(cubes).length,
  mesh_edges: Object.keys(cubes).length * (Object.keys(cubes).length - 1),
  alphabet_base: 256,
  canonical_width: 8,
  catalogs: 47,
  cubes
};

fs.writeFileSync(MANIFEST, JSON.stringify(manifest, null, 2));
console.log(`[manifest] ${manifest.cube_count} cubes → ${MANIFEST}`);
console.log(`[manifest] mesh edges: ${manifest.mesh_edges}`);
console.log(`[manifest] file size: ${Math.round(fs.statSync(MANIFEST).size / 1024)}KB`);
