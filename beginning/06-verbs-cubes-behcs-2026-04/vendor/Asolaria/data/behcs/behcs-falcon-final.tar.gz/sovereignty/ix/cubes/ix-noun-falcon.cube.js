// cube: ix-noun-falcon | IX-732 | D13 SURFACE (prime 41) | touches 7,11,15,19,21
// gates: hookwall | waves: pulse, single | federation: ix-runtime
export const CUBE = {
  id: 'ix-noun-falcon',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [7, 11, 15, 19, 21],
  gates: ['hookwall'],
  waves: ['pulse', 'single'],
  connectors: {
    'ix-exec-runtime':     'parent-runtime',
    'falcon-agent-health': 'local-counterpart',
    'ix-noun-health':      'sibling-state-reader',
    'agent-falcon':        'identity-peer',
    'translator-device':   'device-projector'
  },
  payload: {
    kind: 'noun',
    source: '~/sovereignty/ix/nouns/falcon.js',
    role: 'reads Falcon Agent pid+uptime, localhost then LAN fallback',
    targets: ['http://127.0.0.1:4799/health', 'http://192.168.1.16:4799/health'],
    env: 'FALCON_URL',
    timeout_ms: 3000,
    returns: { ok: 'bool', source: 'string', pid: 'number', uptime: 'number', ts: 'number' }
  },
  translate: {
    human:  'IX noun: falcon — reads Falcon Agent pid/uptime on :4799 (loopback then LAN).',
    agent:  '(falcon, lifecycle.check_health, local.falcon-agent, 0, runtime, hookwall, executing, [observed_on], pulse, IX, log, session, falcon-gw, free)',
    device: 'tcp.connect(127.0.0.1:4799) → GET /health → json ; fallback tcp.connect(192.168.1.16:4799)'
  }
};
