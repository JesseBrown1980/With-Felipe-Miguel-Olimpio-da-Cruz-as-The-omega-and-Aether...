// cube: phone-developer-options-connector | IX-830 | D21 HARDWARE (73) | touches 6,15,21,27
// gates: hookwall+gnn | waves: single | federation: asolaria-mirror-bridge
// archaeology: ~/liris-test/Asolaria/src/connectors/phoneDeveloperOptionsConnector.js (40 KB, Mar 10)
export const CUBE = {
  id: 'phone-developer-options-connector',
  primaryCatalog: { D: 21, name: 'HARDWARE', prime: 73 },
  touches: [6, 15, 21, 27],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'phone-mirror-connector': 'sibling-coordinator',
    'ix-verb-phone-adb':      'underlying-verb',
    'doctrine-falcon-root':   'root-doctrine',
    'behcs-mirror-bridge':    'bridge-parent',
    'agent-falcon':           'target-device'
  },
  payload: {
    kind: 'js-coordinator-archaeology',
    source: '~/liris-test/Asolaria/src/connectors/phoneDeveloperOptionsConnector.js',
    runtime_host: 'laptop-node (adb to Falcon)',
    role: 'Control 23+ Android developer settings via ADB settings put',
    setting_count: 23,
    cipher_class: 'developer-mode-toggles',
    risk: 6
  },
  translate: {
    human:  'Phone developer-options connector — toggles 23+ Android dev settings on Falcon via ADB.',
    agent:  '(asolaria, device.configure, falcon.settings, 6, runtime, hookwall+gnn, executing, [adb], single, LX-259, log, session, asolaria-gw, light)',
    device: 'adb -s ${FALCON_SERIAL} shell settings put global/secure/system <key> <val>'
  }
};
