// cube: agent-liris-state | hilbert: (computed at launch)
// IX-720 | author: backline-sentinel-02 | spec: IX-700 state-companion
// primary catalog: D7 STATE (prime 17, cube 4913)
// touches: D1 ACTOR, D15 DEVICE, D16 PID, D17 PROFILE, D19 LOCATION, D20 TIME, D24 INTENT, D34 PRIORITY, D35 MEMORY, D44 LINEAGE
// gates: hookwall | waves: single, pulse | federation: falcon-local
import fs from 'node:fs';
import path from 'node:path';
const LOG = path.join(path.dirname(new URL(import.meta.url).pathname), '..', 'state', 'agent-liris-state.ndjson');
let _seq = 0;
async function refresh() {
  const raw = fs.existsSync(LOG) ? fs.readFileSync(LOG, 'utf8').trim() : '';
  const lines = raw ? raw.split('\n') : [];
  const events = lines.map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  _seq = events.length ? events[events.length - 1].seq : 0;
  return { agent: 'liris', seq: _seq, count: events.length, latest: events[events.length - 1] || null, events };
}
async function record(event) {
  await refresh();
  const row = { seq: ++_seq, timestamp: new Date().toISOString(), ...event };
  fs.appendFileSync(LOG, JSON.stringify(row) + '\n');
  return row;
}
export const CUBE = {
  id: 'agent-liris-state',
  primaryCatalog: { D: 7, name: 'STATE', prime: 17 },
  touches: [1, 15, 16, 17, 19, 20, 24, 34, 35, 44],
  gates: ['hookwall'], waves: ['single', 'pulse'],
  connectors: { 'agent-liris': 'state-of', 'ix-chain-heartbeat': 'time-peer' },
  payload: { kind: 'agent-state', agent: 'liris', logPath: LOG, schema: ['seq','timestamp','intent','verb','target','scope','proof'], refresh, record },
  translate: {
    human:  'State: liris — append-only NDJSON log, latest seq via refresh().',
    agent:  '(liris, state.track, local.self, 2, agent, hookwall, executing, [feeds], single, FA, log, persistent, falcon-gw, light)',
    device: 'state.log=' + LOG
  }
};
