// cube: network-tailscale | IX-774 | D19 LOCATION (67) | touches 13,15,21,27
// gates: hookwall | waves: single | federation: falcon-local
export const CUBE = {
  id: 'network-tailscale',
  primaryCatalog: { D: 19, name: 'LOCATION', prime: 67 },
  touches: [13, 15, 21, 27],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'network-wlan':         'underlay',
    'network-rmnet-mobile': 'underlay',
    'agent-gaia':           'mesh-peer',
    'mcp-asolaria-control': 'tunneled-through'
  },
  payload: {
    source: 'pm list packages | grep tailscale',
    package: 'com.tailscale.ipn', iface: 'tailscale0 (when up)', live: false, state: 'installed, disconnected',
    gaia_mesh_ip: '100.75.63.31', falcon_mesh_ip: 'unassigned',
    cipher: 'wireguard+noise', role: 'overlay mesh to Gaia / Asolaria',
    note: 'MCP asolaria-control depends on this being up'
  },
  translate: {
    human:  'Tailscale mesh — installed but offline; Gaia lives at 100.75.63.31.',
    agent:  '(falcon, meta.observe, cloud.mesh, 3, runtime, hookwall, blocked, [underlay,mesh-peer], single, IX, log, operational, falcon-gw, light)',
    device: 'pm list packages → com.tailscale.ipn ; tailscale0 DOWN'
  }
};
