// cube: ix-verb-inbox-read | IX-847 | D2 VERB (3) | touches 3,7,11,20,22,35,41
// gates: hookwall | waves: single, pulse | federation: falcon-inbox
export const CUBE = {
  id: 'ix-verb-inbox-read',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [3, 7, 11, 20, 22, 35, 41],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'ix-exec-runtime':       'parent-runtime',
    'falcon-bridge-health':  'local-bridge',
    'ix-verb-laptop-type':   'sibling-egress',
    'behcs-mirror-bridge':   'bridge-parent',
    'translator-agent':      'tuple-emitter',
    'agent-falcon':          'owner',
    'agent-falcon-state':    'state-sink'
  },
  payload: {
    kind: 'verb', source: '~/sovereignty/ix/verbs/inbox-read.js', risk: 0,
    role: 'Read or drain Falcon BEHCS inbox — ingress counterpart to laptop-type egress',
    endpoints: {
      post: 'http://127.0.0.1:4800/inbox',
      get: 'http://127.0.0.1:4800/inbox',
      count: 'http://127.0.0.1:4800/inbox/count',
      drain: 'http://127.0.0.1:4800/inbox/drain (POST)'
    },
    storage: '~/sovereignty/ix/state/falcon-inbox.ndjson',
    exports: ['inboxRead', 'inboxCount']
  },
  translate: {
    human:  'IX verb: inbox-read — Falcon reads BEHCS messages that Asolaria POSTed to :4800/inbox.',
    agent:  '(falcon, inbox.read, local.inbox, 0, runtime, hookwall, completed, [persistent], pulse, FA, log, session, falcon-gw, free)',
    device: 'GET http://127.0.0.1:4800/inbox → json; POST /inbox/drain to pop'
  }
};
