// IX verb: laptop-type / behcs-send | PID: falcon | IX-833
// Falcon → Asolaria BEHCS message bus. POST JSON to :4947/behcs/send
// with 3-endpoint failover (adb-tunnel → lan → tailscale).
// Endpoint canonical: http://192.168.15.189:4947/behcs/send (per Asolaria 2026-04-11)

const http = require('http');
const { URL } = require('url');

const ENDPOINTS = [
  { kind: 'adb-tunnel', url: 'http://127.0.0.1:4947/behcs/send' },
  { kind: 'lan',        url: 'http://192.168.15.189:4947/behcs/send' },
  { kind: 'tailscale',  url: 'http://100.75.63.31:4947/behcs/send' },
];

const DEFAULT_SENDER = 'falcon';
const REQUEST_TIMEOUT_MS = 3000;

function buildTuple({ sender, verb, target, state, endpoint, risk, ix }) {
  return [sender, verb, target, risk, 'civilization', 'hookwall+gnn', state,
    ['asolaria'], 'relay', 'FA', 'log', 'session',
    endpoint || 'none', 'light', 'SM-S721U1', 'mobile-falcon-v1', 'falcon',
    'claude-opus-4-6', { ip: '192.168.1.7', network: 'Jesse_5G' }, new Date().toISOString(),
    { protocol: 'http-behcs-bus' }, 'tuple_to_english', { origin_node: 'falcon' }, ix || 'IX-833'];
}

function postJson(endpoint, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(endpoint.url);
    const data = Buffer.from(JSON.stringify(body));
    const req = http.request({
      host: u.hostname, port: u.port || 80, path: u.pathname, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': data.length,
                 'X-Falcon-Sender': body.from || DEFAULT_SENDER, 'X-BEHCS-Version': 'v1' }
    }, (res) => {
      let b = '';
      res.on('data', c => b += c);
      res.on('end', () => resolve({ ok: res.statusCode >= 200 && res.statusCode < 300,
        status: res.statusCode, body: b, endpoint }));
    });
    req.on('error', e => reject({ endpoint, error: e.message }));
    req.setTimeout(REQUEST_TIMEOUT_MS, () => { req.destroy(); reject({ endpoint, error: 'timeout' }); });
    req.write(data); req.end();
  });
}

async function sendToBehcsBus(payload = {}) {
  const envelope = {
    from: payload.from || DEFAULT_SENDER,
    to: payload.to || 'asolaria',
    timestamp: payload.timestamp || new Date().toISOString(),
    tuple: payload.tuple || null,
    text: payload.text || null,
    data: payload.data || null,
    ix: payload.ix || 'IX-833',
    version: 'behcs-v1',
    spec: 'IX-700'
  };
  const verb = payload.verb || 'message.send';
  const target = payload.target || 'asolaria';
  const risk = payload.risk ?? 2;
  const attempts = [];
  for (const ep of ENDPOINTS) {
    try {
      const res = await postJson(ep, envelope);
      if (res.ok) {
        const tuple = buildTuple({ sender: envelope.from, verb, target, state: 'delivered', endpoint: ep.kind, risk, ix: envelope.ix });
        return { ok: true, tuple, endpoint: ep, status: res.status, body: res.body, attempts, envelope };
      }
      attempts.push({ endpoint: ep, status: res.status, body: res.body });
    } catch (err) {
      attempts.push(err);
    }
  }
  const tuple = buildTuple({ sender: envelope.from, verb, target, state: 'failed', endpoint: null, risk, ix: envelope.ix });
  const e = new Error(`behcs-send: all 3 endpoints failed (${attempts.map(a => (a.endpoint?.kind || '?') + ':' + (a.error || a.status)).join(', ')})`);
  e.tuple = tuple; e.attempts = attempts; e.ok = false; e.envelope = envelope;
  throw e;
}

// Backwards-compat alias — old name maps to same function with keystroke-style payload
async function invokeKeyboardInject(options = {}) {
  return sendToBehcsBus({
    verb: 'keyboard.inject',
    data: { windowTitle: options.windowTitle || 'Asolaria Terminal',
            text: options.text || null, keys: options.keys || null },
    sender: options.sender || DEFAULT_SENDER
  });
}

module.exports = { sendToBehcsBus, invokeKeyboardInject, ENDPOINTS, DEFAULT_SENDER };
