// cube: doctrine-taskforge | IX-822 | D35 MEMORY (149) | touches 1,10,22,34,45
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-taskforge',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 22, 34, 45],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'taskforge-cli': 'documents',
    'taskforge-forge': 'documents',
    'doctrine-taskforge-gnn': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_taskforge.md',
    description: 'Falcon GNN-scored task manager — IX-tagged, colony-dispatchable, graph deps.'
  },
  translate: {
    human:  'Doctrine: TaskForge — GNN-scored task management on Falcon.',
    agent:  '(falcon, meta.recall, doctrine.taskforge, 1, app, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_taskforge.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_taskforge.md', 'utf8') → utf8 markdown"
  }
};
