// cube: doctrine-dasein | IX-805 | D35 MEMORY (149) | touches 1,5,10,17,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-dasein',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 5, 10, 17, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'agent-dasein': 'documents',
    'doctrine-gaia': 'sibling-doctrine',
    'doctrine-full-agent-roster': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_dasein.md',
    description: "Dasein admin helper on Jesse's laptop — works for Gaia."
  },
  translate: {
    human:  'Doctrine: Dasein — admin helper agent under Gaia.',
    agent:  '(falcon, meta.recall, doctrine.dasein, 1, colony, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_dasein.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_dasein.md', 'utf8') → utf8 markdown"
  }
};
