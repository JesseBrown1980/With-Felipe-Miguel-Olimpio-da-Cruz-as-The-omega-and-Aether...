// cube: falcon-sensor-camera-front | IX-764 | D36 SENSOR (151)
// touches: D15 DEVICE, D21 HARDWARE, D25 MODALITY, D37 ENVIRONMENT
// gates: hookwall | waves: single, pulse | federation: falcon-local
// author: convergence-helm-05 | spec: IX-760 sensor-surface
export const CUBE = {
  id: 'falcon-sensor-camera-front',
  primaryCatalog: { D: 36, name: 'SENSOR', prime: 151 },
  touches: [15, 21, 25, 37],
  gates: ['hookwall'],
  waves: ['single', 'pulse'],
  connectors: {
    'falcon-sensor-camera-back': 'sibling-sensor',
    'falcon-sensor-camera-ultra': 'sibling-sensor',
    'falcon-sensor-camera-selfie': 'sibling-sensor',
    'agent-falcon': 'owned-by',
    'agent-falcon-state': 'reads-flow-into'
  },
  payload: {
    kind: 'camera-sensor',
    camera_id: '1',
    facing: 'front',
    max_resolution: { width: 3648, height: 2736 },
    focal_length_mm: 3.21,
    role: 'primary-front',
    modality: 'optical-image',
    termux_command: 'termux-camera-info -c 1',
    capture_command: 'termux-camera-photo -c 1 <file>'
  },
  translate: {
    human:  'Sensor: Falcon front camera (id 1) — 3648x2736 max, 3.21mm lens.',
    agent:  '(falcon, sense.observe, local.camera-1, 1, sensor, hookwall, idle, [reads], single, FA, log, session, falcon-gw, light)',
    device: 'camera2.open(1) → ImageReader(3648x2736,JPEG), focal=3.21mm'
  }
};
