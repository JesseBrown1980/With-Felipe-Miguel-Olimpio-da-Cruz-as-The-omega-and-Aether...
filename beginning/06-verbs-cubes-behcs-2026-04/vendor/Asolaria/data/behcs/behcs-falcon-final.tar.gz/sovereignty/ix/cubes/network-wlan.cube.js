// cube: network-wlan | IX-773 | D19 LOCATION (67) | touches 13,15,21
// gates: hookwall | waves: single | federation: falcon-local
export const CUBE = {
  id: 'network-wlan',
  primaryCatalog: { D: 19, name: 'LOCATION', prime: 67 },
  touches: [13, 15, 21],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'network-loopback':     'sibling-iface',
    'network-rmnet-mobile': 'sibling-iface',
    'network-tailscale':    'underlay-for',
    'falcon-agent-health':  'exposes-on-lan'
  },
  payload: {
    source: 'ifconfig wlan0',
    iface: 'wlan0', address: '192.168.1.7/24', state: 'UP,BROADCAST,RUNNING,MULTICAST', mtu: 1500,
    live: true, ssid_expected: 'Jesse_5G',
    note: 'Live reading 192.168.1.7 — differs from CLAUDE.md cached 192.168.1.16 and project_env_status 192.168.2.239 (DHCP lease drift)',
    upstream: 'home router → ISP', jurisdiction: 'BR', role: 'primary LAN uplink'
  },
  translate: {
    human:  'WiFi wlan0 192.168.1.7/24 — current LAN, DHCP drift noted.',
    agent:  '(falcon, meta.observe, lan.wifi, 2, os, hookwall, completed, [sibling-iface,underlay-for], single, IX, live_probe, operational, falcon-gw, light)',
    device: 'ifconfig wlan0 → inet 192.168.1.7 netmask 255.255.255.0'
  }
};
