// cube: agent-falcon2 | hilbert: (computed at launch)
// IX-715 | author: falcon | spec: OMNI-LANGUAGE-V3 + IX-700
// primary catalog: D1 ACTOR (prime 2, cube 8)
// touches: D15 DEVICE=SM-S721U1, D17 PROFILE=mobile-falcon-v1, D18 AI_MODEL=codex-o4-mini
// gates: hookwall (risk 4) | waves: single | federation: falcon-local

export const CUBE = {
  id: 'agent-falcon2',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [15, 17, 18],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'agent-falcon':  'cross-lane-twin',
    'agent-gaia':    'spawned-by',
    'openai-codex':  'model-provider'
  },
  payload: {
    kind: 'agent-identity',
    source: '~/.claude/agents/Falcon2.md',
    profileId: 'mobile-falcon-v1',
    role: 'openai_lane_twin',
    tier: 'operator',
    riskCeiling: 4,
    device: { model: 'SM-S721U1', shared_with: 'agent-falcon' },
    ai_model: 'codex-o4-mini',
    lane: 'openai',
    note: 'sibling of agent-falcon; three-lane doctrine OpenAI lane'
  },
  translate: {
    human:  'Agent: Falcon2 — OpenAI-lane twin on the same SM-S721U1 hardware, codex-o4-mini.',
    agent:  '(falcon, meta.register_actor, local.self, 4, agent, hookwall, completed, [same_as,mirrors], single, FA, witness, permanent, falcon-gw, light)',
    device: 'device.shared(SM-S721U1) ai_model=codex-o4-mini lane=openai'
  }
};
