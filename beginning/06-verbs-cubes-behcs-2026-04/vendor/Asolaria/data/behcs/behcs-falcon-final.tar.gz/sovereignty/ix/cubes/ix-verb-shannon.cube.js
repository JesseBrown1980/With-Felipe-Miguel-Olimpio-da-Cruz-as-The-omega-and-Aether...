// cube: ix-verb-shannon | IX-739 | D2 VERB (prime 3) | touches 4,6,11,24,41
// gates: hookwall+gnn+shannon (risk 7) | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-verb-shannon',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [4, 6, 11, 24, 41],
  gates: ['hookwall', 'gnn', 'shannon'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':    'parent-runtime',
    'agent-shannon':      'identity-peer',
    'ix-gate-hookwall-v2':'gate-peer',
    'ix-verb-firmware-write':'gated-subject',
    'ix-verb-me-neutralize':'gated-subject'
  },
  payload: {
    kind: 'verb',
    source: '~/sovereignty/ix/verbs/shannon.js',
    role: 'defensive 5-phase pentest: pre-recon → recon → vuln-scan → exploit-check → report',
    risk: 7,
    sidecar: 'http://localhost:4791',
    env: 'SHANNON_URL',
    subverbs: ['scan', 'audit'],
    vuln_types: ['injection', 'xss', 'auth', 'ssrf', 'authz'],
    fail_closed_at_risk: 5,
    proof_mode: 'witness'
  },
  translate: {
    human:  'IX verb: shannon — defensive pentest scan/audit, fail-closed on sidecar loss.',
    agent:  '(shannon, security.audit, local.runtime, 7, runtime, hookwall+gnn+shannon, executing, [observed_on,blocks], single, IX, witness, session, shannon, medium)',
    device: 'POST http://localhost:4791/security/shannon/{vuln-check|audit}'
  }
};
