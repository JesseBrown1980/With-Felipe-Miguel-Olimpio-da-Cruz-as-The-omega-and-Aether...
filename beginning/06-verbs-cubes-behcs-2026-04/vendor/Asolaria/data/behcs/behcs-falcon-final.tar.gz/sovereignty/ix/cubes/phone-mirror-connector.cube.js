// cube: phone-mirror-connector | IX-825 | D13 SURFACE (41) | touches 13,15,21,25,36
// gates: hookwall | waves: pulse | federation: asolaria-mirror-bridge
// archaeology: ~/liris-test/Asolaria/src/connectors/phoneMirrorConnector.js (36 KB, Mar 1)
// FLAG: runs on laptop Node, not Falcon — Falcon documents only.
export const CUBE = {
  id: 'phone-mirror-connector',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [13, 15, 21, 25, 36],
  gates: ['hookwall'],
  waves: ['pulse'],
  connectors: {
    'phone-pro-mirror-connector':        'scrcpy-sibling',
    'phone-developer-options-connector': 'adb-sibling',
    'desktop-capture-connector':         'capture-peer',
    'behcs-mirror-bridge':               'bridge-parent',
    'ix-verb-phone-adb':                 'underlying-verb',
    'agent-falcon':                      'target-device'
  },
  payload: {
    kind: 'js-coordinator-archaeology',
    source: '~/liris-test/Asolaria/src/connectors/phoneMirrorConnector.js',
    runtime_host: 'laptop-node (C:\\Users\\acer\\Asolaria\\)',
    role: 'Real-time phone screen mirror + input (tap/swipe/type/key/WhatsApp voice) via ADB',
    primitives: ['adb exec-out screencap -p', 'adb shell input tap', 'adb shell input swipe', 'adb shell input text', 'adb shell input keyevent'],
    defaults: { screencap_fallback: 'phone-screen-latest.png', voice_fallback: 'phone-whatsapp-voice-latest.wav' },
    falcon_role: 'client: adb target (serial R5CXA4MGQXV)'
  },
  translate: {
    human:  'Phone mirror connector — laptop Node side streams Falcon screen and injects ADB input.',
    agent:  '(asolaria, surface.mirror, falcon.screen, 3, runtime, hookwall, *, [adb], pulse, LX-259, log, session, asolaria-gw, light)',
    device: 'adb -s <serial> exec-out screencap -p | adb shell input <tap|swipe|text|keyevent>'
  }
};
