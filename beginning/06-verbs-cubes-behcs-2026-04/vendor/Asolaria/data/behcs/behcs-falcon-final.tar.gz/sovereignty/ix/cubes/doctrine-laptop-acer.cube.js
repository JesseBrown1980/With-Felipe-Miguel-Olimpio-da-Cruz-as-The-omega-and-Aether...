// cube: doctrine-laptop-acer | IX-815 | D35 MEMORY (149) | touches 1,10,15,19,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-laptop-acer',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 15, 19, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-gaia': 'sibling-doctrine',
    'doctrine-asolaria': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_laptop_acer.md',
    description: "'acer' is Jesse's Windows user on laptop where Gaia lives and Asolaria runs."
  },
  translate: {
    human:  'Doctrine: Jesse Windows laptop user "acer" — host for Gaia and Asolaria.',
    agent:  '(falcon, meta.recall, doctrine.laptop-acer, 1, os, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_laptop_acer.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_laptop_acer.md', 'utf8') → utf8 markdown"
  }
};
