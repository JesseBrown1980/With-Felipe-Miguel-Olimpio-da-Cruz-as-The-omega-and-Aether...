// cube: omni-language-v3-spec | IX-762 | D5 LAYER (prime 11) | touches 10,22
// gates: hookwall | waves: doc | federation: colony-wide | knowledge-cube
export const CUBE = {
  id: 'omni-language-v3-spec',
  primaryCatalog: { D: 5, name: 'LAYER', prime: 11 },
  touches: [10, 22],
  gates: ['hookwall'],
  waves: ['doc', 'single'],
  connectors: {
    'beast-omnilanguage-hooks':'implemented-by',
    'beast-crlt-merge':        'federation-model',
    'hilbert-language-map':    'addressing',
    'omni-24d-executor':       'runtime',
    'translator-human':        'translates',
    'translator-agent':        'translates',
    'translator-device':       'translates'
  },
  payload: {
    kind: 'knowledge-cube',
    source: '~/beast-deploy/OMNI-LANGUAGE-V3.md',
    role: 'Canonical 24D omnilanguage v3 specification (knowledge-cube)',
    ix_phase: 'IX-650',
    dimension_count: 24,
    spec_version: 'v3',
    doc_format: 'markdown',
    supersedes: 'omni-language-v2'
  },
  translate: {
    human:  'Omni-language v3 spec — canonical 24D language definition (IX-650 knowledge cube).',
    agent:  '(asolaria, layer.spec_omni_v3, local.doc, 0, runtime, hookwall, doc, [defines], single, OL3, signed, permanent, colony-gw, free)',
    device: 'cat ~/beast-deploy/OMNI-LANGUAGE-V3.md'
  }
};
