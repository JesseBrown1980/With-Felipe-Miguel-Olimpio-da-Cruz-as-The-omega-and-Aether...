// cube: desktop-input-host-ps1 | IX-832 | D13 SURFACE (41) | touches 7,13,14,20
// gates: hookwall+gnn | waves: single, pulse | federation: asolaria-mirror-bridge
// archaeology: ~/liris-test/Asolaria/tools/DesktopInputHost.ps1 (20 KB, Feb 22) — LX-225 Desktop Sidecar
export const CUBE = {
  id: 'desktop-input-host-ps1',
  primaryCatalog: { D: 13, name: 'SURFACE', prime: 41 },
  touches: [7, 13, 14, 20],
  gates: ['hookwall', 'gnn'],
  waves: ['single', 'pulse'],
  connectors: {
    'invoke-desktop-input-ps1':  'per-call-sibling',
    'desktop-control-connector': 'parent-coordinator',
    'ix-verb-laptop-type':       'ultimate-caller',
    'behcs-mirror-bridge':       'bridge-parent',
    'agent-gaia':                'laptop-host'
  },
  payload: {
    kind: 'powershell-sidecar-archaeology',
    source: '~/liris-test/Asolaria/tools/DesktopInputHost.ps1',
    runtime_host: 'Windows PowerShell persistent process',
    role: 'LX-225 Desktop Sidecar — long-lived PowerShell, JSON-line RPC over stdin/stdout',
    state_model: 'persistent-stateful (avoids per-call PowerShell startup cost)',
    time_profile: 'long-lived (host lifetime ≥ session)',
    energy_profile: 'low-amortized',
    rpc_schema: { id: 'desktop_<ts>_<rand>', action: 'type|click|key|…', text: 'string', windowTitle: 'string' }
  },
  translate: {
    human:  'DesktopInputHost.ps1 — persistent PowerShell sidecar taking batched JSON-line input commands via stdin.',
    agent:  '(asolaria, surface.sidecar, windows.ps-host, 7, runtime, hookwall+gnn, listening, [gaia], single+pulse, LX-225, log, session, asolaria-gw, low)',
    device: 'powershell.exe -File DesktopInputHost.ps1 → stdin JSONL loop → user32.dll dispatch'
  }
};
