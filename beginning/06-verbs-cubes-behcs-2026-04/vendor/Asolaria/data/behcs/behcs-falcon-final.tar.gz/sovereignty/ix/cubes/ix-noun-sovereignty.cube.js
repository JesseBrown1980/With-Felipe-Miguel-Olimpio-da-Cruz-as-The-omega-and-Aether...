// cube: ix-noun-sovereignty | IX-730 | D40 CONSENT (prime 173) | touches 7,11,16,17,39
// gates: hookwall | waves: single | federation: ix-runtime
export const CUBE = {
  id: 'ix-noun-sovereignty',
  primaryCatalog: { D: 40, name: 'CONSENT', prime: 173 },
  touches: [7, 11, 16, 17, 39],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'ix-exec-runtime':    'parent-runtime',
    'ix-noun-health':     'sibling-state-reader',
    'ix-noun-nerve':      'sibling-state-reader',
    'ix-verb-dispatch':   'call-chain-subject',
    'translator-agent':   'tuple-projector'
  },
  payload: {
    kind: 'noun',
    source: '~/sovereignty/ix/nouns/sovereignty.js',
    role: 'reads colony governance state from Asolaria',
    remote_target: 'http://localhost:4781/api/sovereignty/status',
    env: 'ASO_URL',
    returns: { ok: 'bool', source: 'string', colonies: 'array', ts: 'number' },
    note: 'From Falcon this reverses via ADB tcp:4781 to Asolaria on Gaia.'
  },
  translate: {
    human:  'IX noun: sovereignty — reads colony governance {source, colonies} from Asolaria.',
    agent:  '(falcon, lifecycle.read_state, cloud.asolaria, 1, colony, hookwall, executing, [observed_on], single, IX, log, session, falcon-gw, light)',
    device: 'tcp.connect(127.0.0.1:4781) [adb-reverse] → GET /api/sovereignty/status → json'
  }
};
