// cube: beast-omnilanguage-hooks | IX-759 | D22 TRANSLATION (prime 79) | touches 5,9,10,35
// gates: hookwall | waves: event-driven | federation: colony-wide
export const CUBE = {
  id: 'beast-omnilanguage-hooks',
  primaryCatalog: { D: 22, name: 'TRANSLATION', prime: 79 },
  touches: [5, 9, 10, 35],
  gates: ['hookwall'],
  waves: ['event', 'pulse'],
  connectors: {
    'beast-crlt-merge':    'feeds',
    'omni-dispatch':       'triggers',
    'hilbert-language-map':'uses',
    'omni-language-v3-spec':'implements'
  },
  payload: {
    kind: 'hooks',
    source: '~/beast-deploy/omnilanguageHooks.js',
    role: 'IX-506 translation hooks — Hilbert expansion points for omni-language',
    ix_phase: 'IX-506',
    hooks: ['onDrift','onDeviceConnect','onDeviceDisconnect','onSpawn','onDespawn'],
    rule: 'RU11 — drift creates LX entry on 2+ source confirmation',
    emits: ['create_lx_entry','create_device_dashboard','create_pid_dashboard','archive_pid_dashboard']
  },
  translate: {
    human:  'Omnilanguage hooks — IX-506 Hilbert expansion points that create language entries at the point of need.',
    agent:  '(beast, translate.omni_hook, local.language, 2, runtime, hookwall, triggered, [creates], event, OH, log, persistent, colony-gw, low)',
    device: 'require("~/beast-deploy/omnilanguageHooks.js") → {onDrift,onDeviceConnect,...}'
  }
};
