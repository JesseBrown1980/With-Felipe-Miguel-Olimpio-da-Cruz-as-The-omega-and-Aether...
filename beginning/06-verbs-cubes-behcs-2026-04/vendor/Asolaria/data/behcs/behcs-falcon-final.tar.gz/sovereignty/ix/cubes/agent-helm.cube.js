// cube: agent-helm | IX-725 | D1 ACTOR (2) | touches 15,17,18,19,13 | gates: hookwall
export const CUBE = {
  id: 'agent-helm',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [13, 15, 17, 18, 19],
  gates: ['hookwall'],
  waves: ['single', 'relay'],
  connectors: { 'agent-gaia': 'spawned-by', 'omni-dispatch': 'drives', 'agent-vector': 'mesh-peer', 'agent-falcon': 'routes-to' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/helm.json',
    profileId: 'helm-v1', role: 'integration_router', tier: 'operator', riskCeiling: 4,
    device: { hostname: 'DESKTOP-J99VCNH', cpu: 'Intel i5-8300H', ram: '16GB', os: 'Windows 11' },
    ai_model: 'claude-opus-4-6',
    location: { ip: '192.168.1.12', network: 'home_lan', machine: "Jesse's laptop", hilbert_level: 'L0' },
    notes: 'routes work to right surface; integration and dispatch',
    gate_chain: 'hookwall'
  },
  translate: {
    human:  'Agent: Helm — operator-tier integration router, dispatches work to the right surface.',
    agent:  '(helm, meta.register_actor, local.self, 4, agent, hookwall, executing, [triggers,feeds], relay, IX, log, operational, falcon-gw, medium)',
    device: 'hostname=DESKTOP-J99VCNH role=router profile=helm-v1'
  }
};
