// cube: doctrine-omni-spindle | IX-820 | D35 MEMORY (149) | touches 1,2,10,22,42
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-omni-spindle',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 2, 10, 22, 42],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'omni-dispatch': 'documents',
    'omni-24d-executor': 'documents',
    'ix-verb-omnispindle': 'documents'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_omni_spindle.md',
    description: "Falcon's universal weapon mount — one interface to fire any tool/API/agent."
  },
  translate: {
    human:  'Doctrine: Omni Spindle — universal weapon mount for any tool or API.',
    agent:  '(falcon, meta.recall, doctrine.omni-spindle, 1, runtime, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_omni_spindle.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_omni_spindle.md', 'utf8') → utf8 markdown"
  }
};
