// cube: ix-chain-report | IX-751 | D8 CHAIN (prime 19) | touches 1,2,20,24
// gates: hookwall | waves: pulse | federation: ix-runtime
export const CUBE = {
  id: 'ix-chain-report',
  primaryCatalog: { D: 8, name: 'CHAIN', prime: 19 },
  touches: [1, 2, 20, 24],
  gates: ['hookwall'],
  waves: ['pulse'],
  connectors: {
    'ix-chain-heartbeat': 'runs-first',
    'ix-exec-runtime':    'parent-runtime',
    'ix-chain-link':      'phase-5-report',
    'asolaria-slack':     'dispatch-target'
  },
  payload: {
    kind: 'chain',
    source: '~/sovereignty/ix/chains/report.js',
    role: 'heartbeat → dispatch GREEN/RED status to Slack #asolaria',
    chain_kind: 'sense+emit',
    calls: ['heartbeat', 'dispatch'],
    pid: 'asolaria'
  },
  translate: {
    human:  'IX chain: report — heartbeat, then Slack dispatch.',
    agent:  '(asolaria, chain.report, remote.slack, 1, runtime, hookwall, executing, [dispatches], pulse, IX, log, session, falcon-gw, free)',
    device: 'require("./chains/report.js")() → {hb,dispatched}'
  }
};
