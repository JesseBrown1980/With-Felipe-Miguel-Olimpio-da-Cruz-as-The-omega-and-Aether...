// cube: doctrine-falcon2 | IX-807 | D35 MEMORY (149) | touches 1,10,17,18,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-falcon2',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 17, 18, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'agent-falcon2': 'documents',
    'doctrine-three-lanes': 'sibling-doctrine',
    'doctrine-falcon-identity': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_falcon2.md',
    description: 'Falcon2 — OpenAI-built custom agent on phone, sibling to Falcon.'
  },
  translate: {
    human:  'Doctrine: Falcon2 — OpenAI lane agent on Falcon device.',
    agent:  '(falcon, meta.recall, doctrine.falcon2, 1, agent, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_falcon2.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_falcon2.md', 'utf8') → utf8 markdown"
  }
};
