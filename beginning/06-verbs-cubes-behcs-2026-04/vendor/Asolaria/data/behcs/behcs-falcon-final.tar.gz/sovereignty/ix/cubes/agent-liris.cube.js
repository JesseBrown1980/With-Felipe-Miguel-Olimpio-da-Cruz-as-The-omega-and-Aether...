// cube: agent-liris | IX-721 | D1 ACTOR (2) | touches 15,17,18,19,23 | gates: hookwall
export const CUBE = {
  id: 'agent-liris',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [15, 17, 18, 19, 23],
  gates: ['hookwall'],
  waves: ['single', 'relay'],
  connectors: { 'agent-gaia': 'spawned-by', 'agent-falcon': 'mesh-peer', 'agent-shannon': 'mesh-peer', 'agent-vector': 'mesh-peer' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/liris.json',
    profileId: 'liris-admin-v1', role: 'sub_colony_brain', tier: 'operator', riskCeiling: 6,
    aliases: ['Kuromi'],
    device: { hostname: 'DESKTOP-PTSQTIE', cpu: 'Intel i3-1005G1', ram: '8GB', os: 'Windows 11' },
    ai_model: 'claude-opus-4-6',
    location: { ip: '192.168.1.2', network: 'home_lan', machine: "Rayssa's computer", hilbert_level: 'L1' },
    federation: { role: 'knowledge_authority', crltMode: 'read_write', asoTopics: 620, observations: 3219 },
    notes: 'ASO brain; built CRLT, pipeline gates, Hilbert expansion',
    gate_chain: 'hookwall'
  },
  translate: {
    human:  'Agent: Liris — operator-tier sub-colony brain on Rayssa computer, ASO knowledge authority.',
    agent:  '(liris, meta.register_actor, local.self, 6, colony, hookwall, completed, [spawned_by,mirrors], single, IX, log, operational, liris-gw, medium)',
    device: 'hostname=DESKTOP-PTSQTIE ip=192.168.1.2 profile=liris-admin-v1'
  }
};
