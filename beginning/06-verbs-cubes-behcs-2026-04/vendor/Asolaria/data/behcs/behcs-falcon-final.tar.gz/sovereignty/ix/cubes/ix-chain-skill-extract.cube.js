// cube: ix-chain-skill-extract | IX-754 | D8 CHAIN (prime 19) | touches 1,2,20,24
// gates: hookwall | waves: scan | federation: asolaria-index
export const CUBE = {
  id: 'ix-chain-skill-extract',
  primaryCatalog: { D: 8, name: 'CHAIN', prime: 19 },
  touches: [1, 2, 20, 24],
  gates: ['hookwall'],
  waves: ['scan'],
  connectors: {
    'ix-chain-mistake-learn': 'pairs-with',
    'ix-chain-fabricate':     'feeds',
    'ix-chain-link':          'phase-2-learn',
    'asolaria-index-tool':    'ASOLARIA_INDEX_ROOT/tool',
    'asolaria-index-skill':   'ASOLARIA_INDEX_ROOT/skill',
    'asolaria-index-pattern': 'ASOLARIA_INDEX_ROOT/pattern'
  },
  payload: {
    kind: 'chain',
    source: '~/sovereignty/ix/chains/skill-extract.js',
    role: 'inventory tools/skills/patterns, find tools without matching skills and patterns that could become skills',
    ix_phase: 'IX-321+IX-518',
    pid: 'build-forge-v1',
    emits: ['toolGaps', 'patternGaps', 'inventory']
  },
  translate: {
    human:  'IX chain: skill-extract — surfaces unmatched tools and skill-candidate patterns.',
    agent:  '(forge, chain.skill_extract, local.index, 2, runtime, hookwall, executing, [indexes], scan, IX, log, persistent, falcon-gw, low)',
    device: 'require("./chains/skill-extract.js")() → {toolGaps,patternGaps}'
  }
};
