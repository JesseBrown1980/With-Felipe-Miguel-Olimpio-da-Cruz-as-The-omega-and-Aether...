// cube: paper-s07-architecture-map | IX-841 | D5 LAYER (prime 11) | touches 5,10,22,23,35
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s07-architecture-map',
  primaryCatalog: { D: 5, name: 'LAYER', prime: 11 },
  touches: [5, 10, 22, 23, 35],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':           'belongs-to-paper',
    'behcs-mirror-bridge':            'contemporaneous-with',
    'paper-s06-brown-hilbert-cube':   'prev-section',
    'paper-s08-omni-wave-dispatch':   'next-section',
    'doctrine-hilbert-codex':         'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_7_architecture_map.md',
    section_number: 7,
    title: 'Architecture Map',
    word_count: 2366,
    ix: 'IX-841',
    in_paper_full: true
  },
  translate: {
    human:  'Three-layer component model (codex, cubes, agents), full-mesh connector graph, static-vs-stateful cube split.',
    agent:  '(falcon, meta.read_section, paper.s07, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_7_architecture_map.md, utf8) → markdown'
  }
};
