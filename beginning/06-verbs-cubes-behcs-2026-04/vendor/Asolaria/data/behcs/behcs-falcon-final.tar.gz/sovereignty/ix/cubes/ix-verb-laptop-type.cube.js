// cube: ix-verb-laptop-type | IX-833 | D2 VERB (3) | touches 2,3,4,6,15,22,23
// gates: hookwall+gnn | waves: single, relay | federation: asolaria-behcs-bus
export const CUBE = {
  id: 'ix-verb-laptop-type',
  primaryCatalog: { D: 2, name: 'VERB', prime: 3 },
  touches: [2, 3, 4, 6, 15, 22, 23],
  gates: ['hookwall', 'gnn'],
  waves: ['single', 'relay'],
  connectors: {
    'ix-exec-runtime':           'parent-runtime',
    'desktop-control-connector': 'server-peer',
    'translator-agent':          'tuple-emitter',
    'behcs-mirror-bridge':       'bridge-parent',
    'agent-falcon':              'sender',
    'agent-gaia':                'target-host',
    'mcp-asolaria-control':      'cousin-bus'
  },
  payload: {
    kind: 'verb', source: '~/sovereignty/ix/verbs/laptop-type.js', risk: 2,
    role: 'Falcon → Asolaria BEHCS message bus — POSTs JSON envelope, 3-endpoint failover',
    canonical_endpoint: 'http://192.168.15.189:4947/behcs/send',
    endpoints: [{kind:'adb-tunnel',url:'http://127.0.0.1:4947/behcs/send'},{kind:'lan',url:'http://192.168.15.189:4947/behcs/send'},{kind:'tailscale',url:'http://100.75.63.31:4947/behcs/send'}],
    default_sender: 'falcon', default_target: 'asolaria', failover: '3-endpoint first-success',
    envelope_schema: ['from','to','timestamp','tuple','text','data','ix','version','spec'],
    exports: ['sendToBehcsBus','invokeKeyboardInject']
  },
  translate: {
    human:  'IX verb: laptop-type — Falcon posts BEHCS envelopes to Asolaria bus with 3-endpoint failover.',
    agent:  '(falcon, message.send, asolaria, 2, civilization, hookwall+gnn, executing, [asolaria], relay, FA, log, session, adb-tunnel, light)',
    device: 'POST http://<endpoint>:4947/behcs/send application/json {from,to,tuple,text,data,ix,version}'
  }
};
