// cube: config-claude-md | IX-781 | D17 PROFILE (59) | touches 1,10,18,35
// gates: hookwall | waves: single | federation: falcon-local
export const CUBE = {
  id: 'config-claude-md',
  primaryCatalog: { D: 17, name: 'PROFILE', prime: 59 },
  touches: [1, 10, 18, 35],
  gates: ['hookwall'],
  waves: ['single'],
  connectors: {
    'config-agents-md':      'twin-lane',
    'config-claude-settings': 'sibling-config',
    'agent-falcon':          'loaded-by',
    'mcp-asolaria-control':  'referenced-by'
  },
  payload: {
    source: '~/CLAUDE.md', kind: 'identity-manifest', lane: 'claude',
    role: 'Falcon Claude lane identity, launch protocol, network state, chain of command, cube rules',
    sections: ['Identity', 'Network', 'Asolaria Access', 'Chain of Command', 'Capabilities', 'Rules'],
    ai_model: 'claude-opus-4-6', memory_tier: 'permanent',
    risk: 2, read_mode: 'session-start auto-inject'
  },
  translate: {
    human:  'CLAUDE.md — Falcon Claude lane manifest, injected every session.',
    agent:  '(falcon, meta.load_profile, local.self, 2, agent, hookwall, completed, [loaded-by], single, IX, hash, permanent, falcon-gw, free)',
    device: 'cat ~/CLAUDE.md → session context'
  }
};
