// cube: ix-chain-mistake-learn | IX-753 | D8 CHAIN (prime 19) | touches 1,2,20,24
// gates: hookwall | waves: scan | federation: asolaria-index
export const CUBE = {
  id: 'ix-chain-mistake-learn',
  primaryCatalog: { D: 8, name: 'CHAIN', prime: 19 },
  touches: [1, 2, 20, 24],
  gates: ['hookwall'],
  waves: ['scan'],
  connectors: {
    'ix-chain-skill-extract': 'pairs-with',
    'ix-chain-link':          'phase-2-learn',
    'ix-gate-gnn':            'edge-feeder',
    'asolaria-index-mistake': 'ASOLARIA_INDEX_ROOT/mistake',
    'asolaria-index-skill':   'ASOLARIA_INDEX_ROOT/skill'
  },
  payload: {
    kind: 'chain',
    source: '~/sovereignty/ix/chains/mistake-learn.js',
    role: 'scan mistake-ledger.ndjson, find recurring patterns ≥3, match existing skills, emit gaps',
    ix_phase: 'IX-321+IX-491-L3',
    pid: 'admin-sentinel-v1',
    threshold_recurring: 3,
    ledger_path: '~/sovereignty/ix/data/mistake-ledger.ndjson'
  },
  translate: {
    human:  'IX chain: mistake-learn — find recurring mistakes and map to skill cures.',
    agent:  '(sentinel, chain.mistake_learn, local.index, 3, runtime, hookwall, executing, [indexes], scan, IX, log, persistent, falcon-gw, low)',
    device: 'require("./chains/mistake-learn.js")() → {gaps,covered,gnnEdges}'
  }
};
