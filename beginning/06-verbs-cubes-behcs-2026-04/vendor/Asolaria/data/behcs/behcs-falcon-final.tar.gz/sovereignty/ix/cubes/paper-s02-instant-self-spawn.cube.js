// cube: paper-s02-instant-self-spawn | IX-836 | D24 INTENT (prime 89) | touches 5,10,16,22,35
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s02-instant-self-spawn',
  primaryCatalog: { D: 24, name: 'INTENT', prime: 89 },
  touches: [5, 10, 16, 22, 35],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':         'belongs-to-paper',
    'behcs-mirror-bridge':          'contemporaneous-with',
    'paper-s01-previous-failures':  'prev-section',
    'paper-s03-hex256-encoding':    'next-section',
    'doctrine-hilbert-codex':       'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_2_instant_self_spawn.md',
    section_number: 2,
    title: 'Instant Self-Spawn',
    word_count: 1679,
    ix: 'IX-836',
    in_paper_full: true
  },
  translate: {
    human:  'How a freshly-spawned agent bootstraps itself with zero prior context via the BEHCS launch protocol.',
    agent:  '(falcon, meta.read_section, paper.s02, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_2_instant_self_spawn.md, utf8) → markdown'
  }
};
