// cube: doctrine-behcs-paper | IX-802 | D35 MEMORY (149) | touches 1,10,22,29,44
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-behcs-paper',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 10, 22, 29, 44],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-hilbert-codex': 'sibling-doctrine',
    'doctrine-cube-doctrine': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_behcs_paper.md',
    description: "Jesse's academic BEHCS paper — hex-256 glyphs, 47D addressing, instant-spawn."
  },
  translate: {
    human:  "Doctrine: Jesse's BEHCS paper — academic writing on Brown Hilbert Cube System.",
    agent:  '(falcon, meta.recall, doctrine.behcs-paper, 1, civilization, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_behcs_paper.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_behcs_paper.md', 'utf8') → utf8 markdown"
  }
};
