// IX verb: firmware.write | PID: asolaria | Profile: asolaria
// Writes modified firmware to SPI flash via CH341A
// RISK 8 — requires super_admin, gated by all 3 gates
// WILL NOT EXECUTE without a verified backup on disk
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

async function firmwareWrite(romPath) {
  if (!romPath || !fs.existsSync(romPath)) {
    return { ok: false, reason: 'firmware.write requires path to .rom file', ts: Date.now() };
  }

  if (process.platform !== 'linux') {
    return { ok: false, reason: 'firmware.write requires bare-metal Linux', ts: Date.now() };
  }

  // SAFETY: Check that a backup exists
  const backupDir = process.env.FIRMWARE_BACKUP_DIR || (process.env.HOME + '/sovereignty/firmware-backups');
  const backups = fs.existsSync(backupDir) ? fs.readdirSync(backupDir).filter(f => f.startsWith('spi-dump-') && f.endsWith('.rom')) : [];
  if (backups.length === 0) {
    return { ok: false, reason: 'BLOCKED: No SPI backup found. Run firmware.read first. CH341A parachute MANDATORY.', ts: Date.now() };
  }

  try {
    // Write
    execSync(`flashrom -p ch341a_spi -w "${romPath}"`, { timeout: 300000 });

    // Verify
    const verifyFile = path.join(backupDir, 'verify-after-write.rom');
    execSync(`flashrom -p ch341a_spi -v "${romPath}"`, { timeout: 120000 });

    return { ok: true, written: romPath, verified: true, backup_count: backups.length, ts: Date.now() };
  } catch (e) {
    return { ok: false, reason: e.message, recovery: 'Use CH341A to reflash backup from ' + backupDir, ts: Date.now() };
  }
}

module.exports = firmwareWrite;
if (require.main === module) firmwareWrite(process.argv[2]).then(r => console.log(JSON.stringify(r, null, 2)));
