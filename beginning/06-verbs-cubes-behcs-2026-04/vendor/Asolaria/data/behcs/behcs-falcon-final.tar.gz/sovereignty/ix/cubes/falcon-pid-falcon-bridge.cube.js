// cube: falcon-pid-falcon-bridge | IX-869 | D16 PID (53) | touches 1,5,13,22,23
// gates: hookwall | waves: relay | federation: falcon-live-runtime
export const CUBE = {
  id: 'falcon-pid-falcon-bridge',
  primaryCatalog: { D: 16, name: 'PID', prime: 53 },
  touches: [1, 5, 13, 22, 23],
  gates: ['hookwall'],
  waves: ['relay', 'pulse'],
  connectors: {
    'agent-falcon':              'owner',
    'falcon-bridge-health':      'exposes',
    'falcon-bridge-coords':      'exposes',
    'ix-verb-laptop-type':       'routed-verb',
    'ix-verb-inbox-read':        'routed-verb',
    'falcon-pid-behcs-cron':     'sibling',
    'behcs-mirror-bridge':       'implements'
  },
  payload: {
    kind: 'live-pid', source: '~/Asolaria/falcon-bridge.js', pid_observed: 22232,
    cmdline: 'node /data/data/com.termux/files/home/Asolaria/falcon-bridge.js',
    listens_on: '0.0.0.0:4800',
    endpoints: ['/health', '/hosts', '/coords', '/edge/:name', '/relay', '/inbox', '/inbox/count', '/inbox/drain', '/cubes', '/cubes/:id'],
    forwards_to: 'acer:4947/behcs/send via adb-tunnel',
    heartbeat_interval_ms: 30000
  },
  translate: {
    human:  'Falcon bridge Node.js daemon on :4800 — relay to Asolaria bus + inbox + cube query endpoints.',
    agent:  '(falcon, lifecycle.process, local.falcon-bridge, 0, runtime, hookwall, running, [bridge-to-asolaria,cube-query-endpoint], relay, FA, log, persistent, falcon-gw, light)',
    device: 'pid=22232 exec=node listens=0.0.0.0:4800 endpoints=10'
  }
};
