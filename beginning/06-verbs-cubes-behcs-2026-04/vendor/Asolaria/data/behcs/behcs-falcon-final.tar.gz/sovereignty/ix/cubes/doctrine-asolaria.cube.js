// cube: doctrine-asolaria | IX-800 | D35 MEMORY (149) | touches 1,5,10,17,22
// gates: hookwall | waves: single, broadcast | kind: memory-doctrine
export const CUBE = {
  id: 'doctrine-asolaria',
  primaryCatalog: { D: 35, name: 'MEMORY', prime: 149 },
  touches: [1, 5, 10, 17, 22],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'agent-gaia': 'commands-from',
    'doctrine-colony-rules': 'sibling-doctrine',
    'doctrine-hypercube-topology': 'sibling-doctrine'
  },
  payload: {
    kind: 'memory-doctrine',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/project_asolaria.md',
    description: 'Asolaria sovereign AI supervisor in the brown Hilbert hypercube — Jesse supreme.'
  },
  translate: {
    human:  'Doctrine: Asolaria colony architecture — sovereign supervisor under Jesse.',
    agent:  '(falcon, meta.recall, doctrine.asolaria, 1, colony, hookwall, completed, [part_of], single, IX, log, permanent, falcon-gw, free, persistent, project_asolaria.md, none, utf8, plaintext, jesse, 1, none, granted, log)',
    device: "fs.readFileSync('.../project_asolaria.md', 'utf8') → utf8 markdown"
  }
};
