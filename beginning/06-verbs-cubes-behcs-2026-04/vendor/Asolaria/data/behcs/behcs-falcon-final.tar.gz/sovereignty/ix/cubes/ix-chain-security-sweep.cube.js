// cube: ix-chain-security-sweep | IX-752 | D8 CHAIN (prime 19) | touches 1,2,20,24
// gates: hookwall+gnn+shannon | waves: cascade | federation: ix-runtime
export const CUBE = {
  id: 'ix-chain-security-sweep',
  primaryCatalog: { D: 8, name: 'CHAIN', prime: 19 },
  touches: [1, 2, 20, 24],
  gates: ['hookwall', 'gnn', 'shannon'],
  waves: ['cascade', 'single'],
  connectors: {
    'ix-gate-hookwall-v2':  'L0-L2',
    'ix-gate-gnn':          'L3-L4',
    'ix-gate-shannon':      'L5-L6',
    'ix-exec-runtime':      'parent-runtime',
    'ix-chain-link':        'review-source'
  },
  payload: {
    kind: 'chain',
    source: '~/sovereignty/ix/chains/security-sweep.js',
    role: 'IX-491 7-layer immune system L0-L6: hookwall → gnn → shannon audit',
    chain_kind: 'gate-cascade',
    ix_phase: 'IX-491+IX-506+IX-513',
    immune_layers: ['L0_reflex','L1_pattern','L2_context','L3_history','L4_prediction','L5_coordination','L6_shannon'],
    fail_closed_risk: 5
  },
  translate: {
    human:  'IX chain: security-sweep — IX-491 full 7-layer immune sweep.',
    agent:  '(asolaria, chain.security_sweep, local.ix, 7, runtime, hookwall+gnn+shannon, executing, [blocks,audits], cascade, IM, signed, session, falcon-gw, medium)',
    device: 'require("./chains/security-sweep.js")(verb,args,env) → {blocked,gates,immune}'
  }
};
