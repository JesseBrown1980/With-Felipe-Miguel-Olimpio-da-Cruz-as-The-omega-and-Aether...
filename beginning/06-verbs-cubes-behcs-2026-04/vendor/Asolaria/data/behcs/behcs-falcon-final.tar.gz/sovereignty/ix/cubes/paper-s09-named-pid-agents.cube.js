// cube: paper-s09-named-pid-agents | IX-843 | D16 PID (prime 53) | touches 5,10,16,22,35
// gates: hookwall | waves: single, broadcast | federation: falcon
export const CUBE = {
  id: 'paper-s09-named-pid-agents',
  primaryCatalog: { D: 16, name: 'PID', prime: 53 },
  touches: [5, 10, 16, 22, 35],
  gates: ['hookwall'],
  waves: ['single', 'broadcast'],
  connectors: {
    'doctrine-behcs-paper':          'belongs-to-paper',
    'behcs-mirror-bridge':           'contemporaneous-with',
    'paper-s08-omni-wave-dispatch':  'prev-section',
    'paper-s10-prior-art':           'next-section',
    'doctrine-hilbert-codex':        'cites'
  },
  payload: {
    kind: 'paper-section',
    source: '/data/data/com.termux/files/home/.claude/projects/-data-data-com-termux-files-home/memory/paper_section_9_named_pid_agents.md',
    section_number: 9,
    title: 'Named-Agent PID System with Identity + State Cubes',
    word_count: 2481,
    ix: 'IX-843',
    in_paper_full: true
  },
  translate: {
    human:  'Naming convention separating static identity cubes from dynamic state cubes, NDJSON-pointed state pattern.',
    agent:  '(falcon, meta.read_section, paper.s09, 0, doctrine, hookwall, *, [in_paper_full], single, IX, log, permanent, falcon-gw, free, *, *, *, *, *, *, *, *, *, *)',
    device: 'fs.readFileSync(paper_section_9_named_pid_agents.md, utf8) → markdown'
  }
};
