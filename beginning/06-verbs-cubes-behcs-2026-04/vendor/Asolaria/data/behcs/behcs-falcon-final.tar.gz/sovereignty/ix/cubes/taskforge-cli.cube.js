// cube: taskforge-cli | IX-776 | D24 INTENT (89) | touches 1,2,8,34
// gates: hookwall+gnn | waves: single | federation: falcon-local
export const CUBE = {
  id: 'taskforge-cli',
  primaryCatalog: { D: 24, name: 'INTENT', prime: 89 },
  touches: [1, 2, 8, 34],
  gates: ['hookwall', 'gnn'],
  waves: ['single'],
  connectors: {
    'taskforge-forge': 'calls',
    'ix-chain-link':   'invoked-by',
    'agent-falcon':    'runtime-host'
  },
  payload: {
    source: '~/taskforge/cli.js', loc: 224,
    kind: 'cli-binary', bin_name: 'forge', shebang: '#!/usr/bin/env node',
    role: 'command-line frontend to TaskForge engine',
    commands: ['new', 'ls', 'done', 'kill', 'delegate', 'show', 'graph', 'score'],
    flags: ['--pri', '--to', '--dep', '--tag', '--why', '--how', '--state']
  },
  translate: {
    human:  'forge CLI — `forge new|ls|done|delegate` drives TaskForge from shell.',
    agent:  '(jesse, task.invoke, local.self, 2, app, hookwall+gnn, completed, [calls], single, IX, code, session, falcon-gw, free)',
    device: 'exec ~/taskforge/cli.js <cmd> [args]'
  }
};
