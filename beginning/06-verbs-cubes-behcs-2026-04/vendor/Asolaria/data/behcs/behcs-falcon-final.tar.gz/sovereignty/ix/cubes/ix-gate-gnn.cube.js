// cube: ix-gate-gnn | IX-748 | D6 GATE (prime 13) | touches 4,7,11,41
// gates: gnn | waves: single | federation: cascade-4layer
export const CUBE = {
  id: 'ix-gate-gnn',
  primaryCatalog: { D: 6, name: 'GATE', prime: 13 },
  touches: [4, 7, 11, 41],
  gates: ['gnn'],
  waves: ['single'],
  connectors: {
    'ix-gate-hookwall-v2':  'sibling-previous',
    'ix-gate-shannon':      'sibling-next',
    'ix-exec-runtime':      'parent-runtime',
    'cascade-infer-server': 'http://localhost:4792/infer'
  },
  payload: {
    kind: 'gate',
    source: '~/sovereignty/ix/gates/gnn.js',
    role: '4-layer cascade: local edgeRisk score + GNN inference + construction watcher',
    cascade_url: 'http://localhost:4792/infer',
    layers: ['local', 'gnn', 'cascade', 'construction-watcher'],
    timeout_ms: 1500,
    emits_state: ['gated', 'blocked'],
    proof_mode: 'edge-log+predict',
    ix_phase: 'IX-484-phase-0'
  },
  translate: {
    human:  'IX gate: gnn — 4-layer cascade risk scoring via localhost:4792/infer with construction prediction.',
    agent:  '(asolaria, gate.gnn_cascade, remote.cascade, 5, runtime, gnn, gated, [predicts], single, GNN, edge-log, session, falcon-gw, medium)',
    device: 'POST http://localhost:4792/infer → {score,level,prediction}'
  }
};
