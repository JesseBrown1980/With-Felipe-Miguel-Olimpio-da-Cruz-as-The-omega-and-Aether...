// cube: agent-sentinel | IX-723 | D1 ACTOR (2) | touches 15,17,18,19,6 | gates: hookwall+gnn
export const CUBE = {
  id: 'agent-sentinel',
  primaryCatalog: { D: 1, name: 'ACTOR', prime: 2 },
  touches: [6, 15, 17, 18, 19],
  gates: ['hookwall', 'gnn'],
  waves: ['single', 'broadcast'],
  connectors: { 'agent-gaia': 'spawned-by', 'agent-shannon': 'mesh-peer', 'ix-gate-hookwall-v2': 'observes', 'agent-falcon': 'observes' },
  payload: {
    kind: 'agent-identity', source: '~/beast-deploy/profiles/sentinel.json',
    profileId: 'sentinel-v1', role: 'security_watchdog', tier: 'trusted_agent', riskCeiling: 6,
    device: { hostname: 'DESKTOP-J99VCNH', cpu: 'Intel i5-8300H', ram: '16GB', os: 'Windows 11' },
    ai_model: 'claude-opus-4-6',
    location: { ip: '192.168.1.12', network: 'home_lan', machine: "Jesse's laptop", hilbert_level: 'L0' },
    notes: 'watches all gates; flags anomalies; reviews high-risk dispatches',
    intent: 'defensive',
    gate_chain: 'hookwall+gnn'
  },
  translate: {
    human:  'Agent: Sentinel — trusted-agent watchdog over all gates, flags anomalies and reviews high-risk dispatches.',
    agent:  '(sentinel, meta.register_actor, local.self, 6, agent, hookwall+gnn, executing, [observed_on,blocks], broadcast, IX, log, operational, hookwall, medium)',
    device: 'hostname=DESKTOP-J99VCNH role=watchdog profile=sentinel-v1'
  }
};
