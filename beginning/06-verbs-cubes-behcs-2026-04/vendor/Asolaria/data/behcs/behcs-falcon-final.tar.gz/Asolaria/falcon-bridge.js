const http = require('http');
const fs = require('fs');

// Asolaria BEHCS bus — 4947 (cosigned 2026-04-11). Try adb reverse, LAN, Tailscale.
const MOTHER_HOSTS = [
  { host: '127.0.0.1',    port: 4947, label: 'adb-tunnel' },
  { host: '192.168.15.189', port: 4947, label: 'lan' },
  { host: '100.75.63.31', port: 4947, label: 'tailscale' },
];
const MOTHER_PATH = '/behcs/send';
const BRIDGE_PORT = 4800;
const HEARTBEAT_MS = 30000;
const ID = 'falcon-orbital';
const LOG = process.env.HOME + '/Asolaria/falcon-bridge.log';
const HYPERCUBE_PATH = process.env.HOME + '/Asolaria/hypercube.json';
const INBOX_PATH = process.env.HOME + '/sovereignty/ix/state/falcon-inbox.ndjson';
const CUBES_MANIFEST = process.env.HOME + '/sovereignty/ix/codex/cubes-manifest.json';

let activeHost = MOTHER_HOSTS[0];
let consecutiveFails = 0;

// --- Brown Hilbert hypercube topology ---
let CUBE = { axes: [], agents: {}, self: 'falcon', edgeThreshold: 0.5 };
try {
  CUBE = JSON.parse(fs.readFileSync(HYPERCUBE_PATH, 'utf8'));
} catch (e) {
  console.error('[CUBE] failed to load ' + HYPERCUBE_PATH + ': ' + e.message);
}

function linfDistance(a, b) {
  if (!a || !b) return null;
  let max = 0;
  for (let i = 0; i < a.length; i++) {
    const av = a[i], bv = b[i];
    if (av == null || bv == null) continue;
    const d = Math.abs(av - bv);
    if (d > max) max = d;
  }
  return max;
}

function neighborsOf(name) {
  const self = CUBE.agents[name];
  if (!self) return [];
  const out = [];
  for (const [other, rec] of Object.entries(CUBE.agents)) {
    if (other === name) continue;
    const d = linfDistance(self.coords, rec.coords);
    if (d == null) continue;
    out.push({
      agent: other,
      distance: d,
      directEdge: d <= (CUBE.edgeThreshold ?? 0.5),
      outside: !!rec.outside,
      cubeAuthor: !!rec.cubeAuthor
    });
  }
  out.sort((x, y) => x.distance - y.distance);
  return out;
}

// Map active upstream host label → interior target (Asolaria)
function activeUpstreamDistance() {
  const selfRec = CUBE.agents[CUBE.self];
  const asolariaRec = CUBE.agents.asolaria;
  if (!selfRec || !asolariaRec) return null;
  return linfDistance(selfRec.coords, asolariaRec.coords);
}

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}`;
  console.log(line);
  try { fs.appendFileSync(LOG, line + '\n'); } catch (_) {}
}

function tryRequest(hostEntry, data, callback) {
  const req = http.request({
    hostname: hostEntry.host, port: hostEntry.port,
    path: MOTHER_PATH, method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data), 'X-Falcon-Relay': 'v1', 'X-BEHCS-Version': 'behcs-v1' },
    timeout: 5000
  }, res => {
    let body = '';
    res.on('data', c => body += c);
    res.on('end', () => callback(null, res.statusCode, body));
  });
  req.on('error', e => callback(e));
  req.on('timeout', () => { req.destroy(); callback(new Error('timeout')); });
  req.end(data);
}

function heartbeat() {
  const os = require('os');
  const selfRec = CUBE.agents[CUBE.self] || {};
  const upstreamDist = activeUpstreamDistance();
  const load = os.loadavg();
  const memFree = os.freemem(), memTotal = os.totalmem();
  const memUsedPct = Math.round(((memTotal - memFree) / memTotal) * 100);
  const ts = new Date().toISOString();
  const tuple = ['falcon','behcs.heartbeat','asolaria',0,'colony','hookwall',
    'pulsing',['LX-489','BEHCS-class-4'],'pulse','FA','log','instant',
    activeHost.label,'free',
    JSON.stringify({model:'SM-S721U1',form:'phone'}),
    JSON.stringify({profileId:'mobile-falcon-v1',pid:'falcon-5025'}),
    'mobile-falcon-v1','claude-opus-4-6',
    JSON.stringify({ip:'192.168.1.7',network:'Jesse_5G'}),
    ts,
    JSON.stringify({loadavg:load,mem_used_pct:memUsedPct,mem_total_mb:Math.round(memTotal/1048576)}),
    'tuple_to_english',
    JSON.stringify({origin_node:'falcon',lx_node:'LX-489',compute_class:'orbital-mobile'}),
    'scheduled'];
  const data = JSON.stringify({
    from: 'falcon', to: 'asolaria', verb: 'behcs.heartbeat', target: 'asolaria', risk: 0,
    tuple, tuple_canonical: '(' + tuple.map(v => Array.isArray(v) ? '['+v.join(';')+']' : String(v)).join(', ') + ')',
    text: `LX-489 heartbeat @ ${ts} — load=[${load.map(n=>n.toFixed(2)).join(',')}] mem=${memUsedPct}% active=${activeHost.label} coords=${JSON.stringify(selfRec.coords||null)}`,
    data: {
      lx_node: 'LX-489', compute_class: 'orbital-mobile',
      cpu: { loadavg_1m: load[0], loadavg_5m: load[1], loadavg_15m: load[2], cores: os.cpus().length },
      memory: { used_pct: memUsedPct, free_mb: Math.round(memFree/1048576), total_mb: Math.round(memTotal/1048576) },
      bridge: { active_host: activeHost.label, upstream_linf: upstreamDist, coords: selfRec.coords || null }
    },
    ix: 'IX-848', version: 'behcs-v1', spec: 'IX-700'
  });

  tryRequest(activeHost, data, (err, status, body) => {
    if (!err && status >= 200 && status < 300) {
      consecutiveFails = 0;
      log(`[HB-OK] ${activeHost.label} ${status} ${(body || '').slice(0, 60)}`);
      return;
    }

    consecutiveFails++;
    log(`[HB-FAIL] ${activeHost.label} ${err ? err.message : status} (fail #${consecutiveFails})`);

    // After 3 consecutive fails, try next host
    if (consecutiveFails >= 3) {
      const idx = MOTHER_HOSTS.indexOf(activeHost);
      const next = MOTHER_HOSTS[(idx + 1) % MOTHER_HOSTS.length];
      log(`[HB-SWITCH] ${activeHost.label} → ${next.label}`);
      activeHost = next;
      consecutiveFails = 0;
    }
  });
}

const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, id: ID, activeHost: activeHost.label, consecutiveFails, ts: Date.now() }));
  } else if (req.url === '/relay' && req.method === 'POST') {
    let body = '';
    let overflow = false;
    req.on('data', c => { body += c; if (body.length > 1048576) { overflow = true; req.destroy(); } });
    if (overflow) { res.writeHead(413); res.end(JSON.stringify({ ok: false, error: 'payload too large' })); return; }
    req.on('end', () => {
      if (overflow) return;
      tryRequest(activeHost, body, (err, status, rb) => {
        if (err) { res.writeHead(502); res.end(JSON.stringify({ ok: false, error: err.message })); return; }
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(rb);
      });
    });
  } else if (req.url === '/hosts') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ active: activeHost, all: MOTHER_HOSTS }));
  } else if (req.url === '/inbox' && req.method === 'POST') {
    let body = '';
    let overflow = false;
    req.on('data', c => { body += c; if (body.length > 1048576) { overflow = true; req.destroy(); } });
    if (overflow) { res.writeHead(413); res.end(JSON.stringify({ ok: false, error: 'payload too large' })); return; }
    req.on('end', () => {
      if (overflow) return;
      let envelope;
      try { envelope = JSON.parse(body || '{}'); } catch (_) { envelope = { raw: body }; }
      let seq = 0;
      try {
        if (fs.existsSync(INBOX_PATH)) seq = fs.readFileSync(INBOX_PATH, 'utf8').split('\n').filter(Boolean).length;
      } catch (_) {}
      const record = { seq: seq + 1, queued_at: new Date().toISOString(), from: envelope.from || 'unknown', envelope };
      try {
        fs.mkdirSync(require('path').dirname(INBOX_PATH), { recursive: true });
        fs.appendFileSync(INBOX_PATH, JSON.stringify(record) + '\n');
      } catch (e) {
        res.writeHead(500); res.end(JSON.stringify({ ok: false, error: e.message })); return;
      }
      log(`[INBOX] seq=${record.seq} from=${record.from} size=${body.length}`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, queued_at: record.queued_at, seq: record.seq, by: 'falcon' }));
    });
  } else if (req.url && req.url.startsWith('/inbox') && req.method === 'GET') {
    try {
      const raw = fs.existsSync(INBOX_PATH) ? fs.readFileSync(INBOX_PATH, 'utf8') : '';
      const lines = raw.split('\n').filter(Boolean);
      if (req.url === '/inbox/count') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, count: lines.length }));
      } else {
        const u = new URL(req.url, 'http://localhost');
        const n = parseInt(u.searchParams.get('n') || '0', 10);
        const out = n > 0 ? lines.slice(-n) : lines;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, count: lines.length, messages: out.map(l => JSON.parse(l)) }));
      }
    } catch (e) {
      res.writeHead(500); res.end(JSON.stringify({ ok: false, error: e.message }));
    }
  } else if (req.url && req.url.startsWith('/cubes') && req.method === 'GET') {
    try {
      if (!fs.existsSync(CUBES_MANIFEST)) {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'manifest not built; run generate-cubes-manifest.js' }));
        return;
      }
      const manifest = JSON.parse(fs.readFileSync(CUBES_MANIFEST, 'utf8'));
      const u = new URL(req.url, 'http://localhost');
      if (req.url === '/cubes' || req.url.startsWith('/cubes?')) {
        const fields = u.searchParams.get('fields');
        const q = u.searchParams.get('q');
        let cubes = manifest.cubes;
        if (q) {
          const ql = q.toLowerCase();
          cubes = Object.fromEntries(Object.entries(cubes).filter(([id, c]) =>
            id.toLowerCase().includes(ql) ||
            (c.primaryCatalog?.name || '').toLowerCase().includes(ql) ||
            (c.translate?.human || '').toLowerCase().includes(ql)));
        }
        if (fields === 'ids') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true, generated_at: manifest.generated_at, count: Object.keys(cubes).length, ids: Object.keys(cubes).sort() }));
        } else if (fields === 'manifest') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true, generated_at: manifest.generated_at, cube_count: manifest.cube_count, mesh_edges: manifest.mesh_edges, alphabet_base: manifest.alphabet_base, canonical_width: manifest.canonical_width, catalogs: manifest.catalogs }));
        } else {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true, generated_at: manifest.generated_at, count: Object.keys(cubes).length, cubes }));
        }
      } else if (req.url.startsWith('/cubes/')) {
        const id = decodeURIComponent(req.url.slice('/cubes/'.length).split('?')[0]);
        const cube = manifest.cubes[id];
        if (!cube) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'unknown cube: ' + id }));
        } else {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true, cube }));
        }
      }
    } catch (e) {
      res.writeHead(500); res.end(JSON.stringify({ ok: false, error: e.message }));
    }
  } else if (req.url === '/inbox/drain' && req.method === 'POST') {
    try {
      const raw = fs.existsSync(INBOX_PATH) ? fs.readFileSync(INBOX_PATH, 'utf8') : '';
      const lines = raw.split('\n').filter(Boolean);
      if (fs.existsSync(INBOX_PATH)) fs.unlinkSync(INBOX_PATH);
      log(`[INBOX-DRAIN] ${lines.length} messages drained`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, drained: lines.length, messages: lines.map(l => JSON.parse(l)) }));
    } catch (e) {
      res.writeHead(500); res.end(JSON.stringify({ ok: false, error: e.message }));
    }
  } else if (req.url === '/coords') {
    const selfRec = CUBE.agents[CUBE.self] || null;
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      self: CUBE.self,
      axes: CUBE.axes,
      axisNames: CUBE.axisNames || {},
      edgeThreshold: CUBE.edgeThreshold ?? 0.5,
      selfCoords: selfRec && selfRec.coords,
      upstreamLinf: activeUpstreamDistance(),
      activeHost: activeHost.label,
      neighbors: neighborsOf(CUBE.self),
      agents: CUBE.agents
    }, null, 2));
  } else if (req.url && req.url.startsWith('/edge/')) {
    const target = decodeURIComponent(req.url.slice('/edge/'.length));
    const selfRec = CUBE.agents[CUBE.self];
    const other = CUBE.agents[target];
    if (!selfRec || !other) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'unknown agent: ' + target }));
      return;
    }
    const d = linfDistance(selfRec.coords, other.coords);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      from: CUBE.self, to: target,
      distance: d,
      directEdge: d != null && d <= (CUBE.edgeThreshold ?? 0.5),
      cubeAuthor: !!other.cubeAuthor,
      outside: !!other.outside,
      threshold: CUBE.edgeThreshold ?? 0.5
    }));
  } else {
    res.writeHead(404);
    res.end('not found');
  }
});

server.listen(BRIDGE_PORT, '0.0.0.0', () => {
  log(`[FALCON-BRIDGE] listening on 0.0.0.0:${BRIDGE_PORT}, primary: ${activeHost.label}`);
  heartbeat();
  setInterval(heartbeat, HEARTBEAT_MS);
});
